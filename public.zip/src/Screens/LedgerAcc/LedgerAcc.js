import React, { useState, useEffect, useRef } from "react";
import { Button } from "react-bootstrap";
import { ButtonGroup } from "@mui/material";
import "./LedgerAcc.css";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useFilePicker } from "use-file-picker";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import Slide from "@mui/material/Slide";
import axios from "axios";
import { useEditMode } from "../../EditModeContext";
import AnexureModal from "../Modals/AnexureModal ";
import { Modal, Box, Autocomplete, TextField,  Typography } from "@mui/material";
import { CompanyContext } from "../Context/CompanyContext";
import { useContext } from "react";


const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="down" ref={ref} {...props} />;
});
const LedgerAcc = () => {

  const { company } = useContext(CompanyContext);
  const tenant = company?.databaseName;

  if (!tenant) {
    // you may want to guard here or show an error state,
    // since without a tenant you can’t hit the right API
    console.error("No tenant selected!");
  }

  const [showModal, setShowModal] = useState(false);
  const inputRefs = useRef([]); // Array to hold references for input fields
  const [toastOpen, setToastOpen] = useState(false); // Track if toast is open
  const [formData, setFormData] = useState({
    Bsgroup: "",
    acode: "",
    gstNo: "",
    ahead: "",
    add1: "",
    city: "",
    state: "",
    distance:"",
    pinCode: "",
    distt: "",
    opening_dr: "",
    opening_cr: "",
    msmed: "",
    phone: "",
    email: "",
    area: "",
    agent: "",
    group: "",
    pan: "",
    tcs206: "",
    tds194q:"",
    tdsno: "",
    wahead: "",
    wadd1: "",
    wadd2: "",
    Rc: "",
    Ecc: "",
    erange: "",
    collc: "",
    srvno: "",
    cperson: "",
    irate: "",
    tds_rate: "",
    tcs_rate: "",
    sur_rate: "",
    weight: "",
    bank_ac: "",
    narration: "",
    subname: "",
    subaddress: "",
    subcity: "",
    subgstNo: "",
  });

 // Search options
 const [openSearch, setOpenSearch] = useState(false); // Modal Visibility
 const [selectedOption, setSelectedOption] = useState(null); // Selected Item
 const autoCompleteRef = useRef(null); // Reference for AutoComplete Input

 // Fetch data from API when component mounts
 useEffect(() => {
   axios
     .get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/ledgerAccount`)
     .then((response) => setData2(response.data))
     .catch((error) => console.error("Error fetching data:", error));
 }, []);

 // Open Modal and Set Focus to Autocomplete
 const handleOpen = () => {
   setOpenSearch(true);
   setTimeout(() => {
     if (autoCompleteRef.current) {
       autoCompleteRef.current.focus(); // Focus Autocomplete
     }
   }, 100); // Delay to ensure modal opens first
 };

 // Close Modal & Clear Selection
 const handleCloseSearch = () => {
   setSelectedOption(null); // Reset selection
   setOpenSearch(false);
 };

 // Handle ComboBox Selection & Close Modal on Enter
 const handleSelect = (event, newValue) => {
   if (newValue) {
     setFormData(newValue.formData); // Set Selected Data
     handleCloseSearch(); // Close Modal
   }
 };

  const handleSelectBsgroup = (selectedName) => {
    setFormData((prevData) => ({ ...prevData, Bsgroup: selectedName }));
  
    // Ensure modal closes first, then focus on GSTNO field
    setTimeout(() => {
      if (inputRefs.current[0]) {
        inputRefs.current[0].focus();
      }
    }, 200); // Delay to allow modal transition to complete
  };

  // Api Response
  const [data, setData] = useState([]);
  const [data1, setData1] = useState([]);
  const [data2, setData2] = useState([]);
  const [index, setIndex] = useState(0);
  const [isAddEnabled, setIsAddEnabled] = useState(true);
  const [isSubmitEnabled, setIsSubmitEnabled] = useState(false);
  const [isFetchEnabled, setIsFetchEnabled] = useState(false);
  const [isSubMasterEnabled, setIsSubMasterEnabled] = useState(false);
  const { isEditMode, setIsEditMode } = useEditMode(); // Access the context
  const [isAbcmode, setIsAbcmode] = useState(false);
  const [isDisabled, setIsDisabled] = useState(false); // State to track field disablement
  const [firstTimeCheckData, setFirstTimeCheckData] = useState("");

  const fetchData = async () => {
      try {
          const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/ledgerAccount/last`);
          if (response.status === 200 && response.data.data) {
            const lastEntry = response.data.data;
              // Set flags and update form data
              setFirstTimeCheckData("DataAvailable");
              setFormData(lastEntry.formData);
              // Set data and index
              setData1(lastEntry); // Assuming setData1 holds the current entry data
              setIndex(lastEntry.Acodes); // Set index to the voucher number or another identifier
          } else {
              setFirstTimeCheckData("DataNotAvailable");
              console.log("No data available");
              // Create an empty data object with voucher number 0
              const emptyFormData = {
                  Bsgroup: "",
                  acode: "",
                  gstNo: "",
                  ahead: "",
                  add1: "",
                  city: "",
                  state: "",
                  distance:"",
                  pinCode: "",
                  distt: "",
                  opening_dr: "",
                  opening_cr: "",
                  msmed: "",
                  phone: "",
                  email: "",
                  area: "",
                  agent: "",
                  group: "",
                  pan: "",
                  tcs206: "",
                  tds194q: "",
                  tdsno: "",
                  wahead: "",
                  wadd1: "",
                  wadd2: "",
                  Rc: "",
                  Ecc: "",
                  erange: "",
                  collc: "",
                  srvno: "",
                  cperson: "",
                  irate: "",
                  tds_rate: "",
                  tcs_rate: "",
                  sur_rate: "",
                  weight: "",
                  bank_ac: "",
                  narration: "",
                  subname: "",
                  subaddress: "",
                  subcity: "",
                  subgstNo: "",
              };
              // Set the empty data
              setFormData(emptyFormData);
              setData1({ formData: emptyFormData}); // Store empty data
              setIndex(0); // Set index to 0 for the empty voucher
          }
      } catch (error) {
          console.error("Error fetching data", error);
          // In case of error, you can also initialize empty data if needed
          const emptyFormData = {
              Bsgroup: "",
              acode: "",
              gstNo: "",
              ahead: "",
              add1: "",
              city: "",
              state: "",
              distance: "",
              pinCode: "",
              distt: "",
              opening_dr: "",
              opening_cr: "",
              msmed: "",
              phone: "",
              email: "",
              area: "",
              agent: "",
              group: "",
              pan: "",
              tcs206: "",
              tds194q: "",
              tdsno: "",
              wahead: "",
              wadd1: "",
              wadd2: "",
              Rc: "",
              Ecc: "",
              erange: "",
              collc: "",
              srvno: "",
              cperson: "",
              irate: "",
              tds_rate: "",
              tcs_rate: "",
              sur_rate: "",
              weight: "",
              bank_ac: "",
              narration: "",
              subname: "",
              subaddress: "",
              subcity: "",
              subgstNo: "",
          };
              // Set the empty data
          setFormData(emptyFormData);
          setData1({ formData: emptyFormData}); // Store empty data
          setIndex(0);
      }
  };

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    if (data.length > 0) {
      setFormData(data[data.length - 1]); // Set currentData to the last record
      setIndex(data.length - 1);
    }
  }, [data]);

  const handleFetchData = async () => {
    if (!formData.gstNo) {
      alert("Please enter GST Number!");
      return;
    }
    try {
      // Simulating an API call
      const response = await axios.get("/data.json"); // Replace with actual API endpoint
      const data = response.data;
      // Filtering data by GST number
      if (data.gstin === formData.gstNo) {
        setFormData({
          ...formData,
          gstNo: data.gstin || "",
          ahead: data.lgnm || "",
          add1: data.pradr?.addr?.st+"," + data.pradr?.addr?.bno  || "",
          city: data.pradr?.addr?.loc || "",
          state: data.pradr?.addr?.stcd || "",
          pinCode: data.pradr?.addr?.pncd || "",
          distt: data.pradr?.addr?.dst || "",
          cperson: data.tradeNam || "",
        });
      } else {
        alert("No data found for the entered GST Number!");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      alert("An error occurred while fetching data.");
    }
  };

  const handleNext = async () => {
    document.body.style.backgroundColor = "white";
    console.log(data1._id);
    try {
      if (data1) {
        const response = await axios.get(
          `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/ledgerAccount/next/${data1._id}`
        );
        if (response.status === 200 && response.data) {
          const nextData = response.data.data;
          setData1(response.data.data);
          setIndex(index + 1);
          setFormData(nextData.formData);
          setIsDisabled(true);
        }
      }
    } catch (error) {
      console.error("Error fetching next record:", error);
    }
  };

  const handlePrevious = async () => {
    document.body.style.backgroundColor = "white";
    try {
      if (data1) {
        const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/ledgerAccount/previous/${data1._id}`);
        if (response.status === 200 && response.data) {
          console.log(response);
          setData1(response.data.data);
          const prevData = response.data.data;
          setIndex(index - 1);
          setFormData(prevData.formData);
          setIsDisabled(true);
        }
      }
    } catch (error) {
      console.error("Error fetching previous record:", error);
    }
  };

  const handleFirst = async () => {
    document.body.style.backgroundColor = "white";
    try {
      const response = await axios.get(
        `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/ledgerAccount/first`
      );
      if (response.status === 200 && response.data) {
        const firstData = response.data.data;
        setIndex(0);
        setFormData(firstData.formData);
        setData1(response.data.data);
        setIsDisabled(true);
      }
    } catch (error) {
      console.error("Error fetching first record:", error);
    }
  };

  const handleLast = async () => {
    document.body.style.backgroundColor = "white";
    try {
      const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/ledgerAccount/last`);
      if (response.status === 200 && response.data) {
        const lastData = response.data.data;
        const lastIndex = response.data.length - 1;
        setIndex(lastIndex);
        setFormData(lastData.formData);
        setData1(response.data.data);
        setIsDisabled(true);
      }
    } catch (error) {
      console.error("Error fetching last record:", error);
    }
  };
  
  const handleAdd = async () => {
    setShowModal(true);
    try {
        await fetchData();
        let lastvoucherno = 0;
        console.log(data);
        if (formData.acode === '') {
            lastvoucherno = 1;
        } else {
            const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/ledgerAccount/last`);
            if (response.status === 200 && response.data) {
                // console.log(response.data.data,"helloooooosss");
                lastvoucherno = parseInt(response.data.data.formData.acode) + 1;
                // console.log("LastVoucher::",lastvoucherno);
            }
        }
        const newData = {
          Bsgroup: "",
          acode: lastvoucherno,
          gstNo: "",
          ahead: "",
          add1: "",
          city: "",
          state: "",
          distance: "",
          pinCode: "",
          distt: "",
          opening_dr: "",
          opening_cr: "",
          msmed: "",
          phone: "",
          email: "",
          area: "",
          agent: "",
          group: "",
          pan: "",
          tcs206: "",
          tds194q: "",
          tdsno: "",
          wahead: "",
          wadd1: "",
          wadd2: "",
          Rc: "",
          Ecc: "",
          erange: "",
          collc: "",
          srvno: "",
          cperson: "",
          irate: "",
          tds_rate: "",
          tcs_rate: "",
          sur_rate: "",
          weight: "",
          bank_ac: "",
          narration: "",
          subname: "",
          subaddress: "",
          subcity: "",
          subgstNo: "",
        };
        setData([...data, newData]);
        setFormData(newData);
        setIndex(data.length);
        setIsAddEnabled(false);
        setIsSubmitEnabled(true);
        setIsFetchEnabled(true);
        setIsSubMasterEnabled(true);
        setIsDisabled(false);
        setIsEditMode(true);
    } catch (error) {
        console.error("Error adding new entry:", error);
    }
  };

  const handleChangevalues = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  const handleAlphabetOnly = (e) => {
    const { name, value } = e.target;
    // Allow only alphabets (A-Z, a-z) and spaces
    const alphabetRegex = /^[A-Za-z\s]*$/;
    if (alphabetRegex.test(value)) {
      setFormData({ ...formData, [name]: value });
    }
  };

  const initialColors = [
    "#E9967A",
    "#F0E68C",
    "#FFDEAD",
    "#ADD8E6",
    "#87CEFA",
    "#FFF0F5",
    "#FFC0CB",
    "#D8BFD8",
    "#DC143C",
    "#DCDCDC",
    "#8FBC8F",
    "575a65",
  ];
  const [buttonColors, setButtonColors] = useState(initialColors); // Initial colors

  const [formDataDialog, setFormDataDialog] = useState({
    subname: "",
    subaddress: "",
    subcity: "",
    subgstNo: "",

    // Add more fields as needed
  });
 
  const handlechangeStatus = (event) => {
    const { value } = event.target; // Get the selected value from the event
    setFormData((prevState) => ({
      ...prevState,
      msmed: value, // Update the ratecalculate field in FormData
    }));
  };
  const handleTurnover = (event) => {
    const { value } = event.target; // Get the selected value from the event
    setFormData((prevState) => ({
      ...prevState,
      tcs206: value, // Update the ratecalculate field in FormData
    }));
  };
  const handleApproved = (event) => {
    const { value } = event.target; // Get the selected value from the event
    setFormData((prevState) => ({
      ...prevState,
      tds194q: value, // Update the ratecalculate field in FormData
    }));
  };
  const handlePosition = (event) => {
    const { value } = event.target; // Get the selected value from the event
    setFormData((prevState) => ({
      ...prevState,
      narration: value, // Update the ratecalculate field in FormData
    }));
  };

  const handleFormSubmit = async () => {
    const jsonData2 = await JSON.stringify(formDataDialog);
    await console.log(jsonData2);
    // Close the dialog after submitting the form
    handleClose();
  };

 const [existingGstList, setExistingGstList] = useState([]);

  useEffect(() => {
    axios
      .get("http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/ledgerAccount")
      .then((res) => {
        const gstNumbers = res.data
          .map((entry) => entry.formData?.gstNo?.toUpperCase())
          .filter((gst) => gst);
        setExistingGstList(gstNumbers);
      })
      .catch((err) => {
        console.error("Error fetching GST list:", err);
      });
  }, []);

  // GST Validation
  const GST_REGEX = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
  const [isGstValid, setIsGstValid] = useState(true);

  const stateCodes = {
    "01": "Jammu & Kashmir",
    "02": "Himachal Pradesh",
    "03": "Punjab",
    "04": "Chandigarh",
    "05": "Uttarakhand",
    "06": "Haryana",
    "07": "Delhi",
    "08": "Rajasthan",
    "09": "Uttar Pradesh",
    "10": "Bihar",
    "11": "Sikkim",
    "12": "Arunachal Pradesh",
    "13": "Nagaland",
    "14": "Manipur",
    "15": "Mizoram",
    "16": "Tripura",
    "17": "Meghalaya",
    "18": "Assam",
    "19": "West Bengal",
    "20": "Jharkhand",
    "21": "Odisha",
    "22": "Chhattisgarh",
    "23": "Madhya Pradesh",
    "24": "Gujarat",
    "25": "Daman and Diu",
    "26": "Dadra and Nagar Haveli",
    "27": "Maharashtra",
    "28": "Andhra Pradesh",
    "29": "Karnataka",
    "30": "Goa",
    "31": "Lakshadweep",
    "32": "Kerala",
    "33": "Tamil Nadu",
    "34": "Puducherry",
    "35": "Andaman & Nicobar Islands",
    "36": "Telangana",
    "37": "Andhra Pradesh (New)",
    "38": "Ladakh",
    " " : "Export"
  };

  // Restrict invalid key presses
  const handleKeyPress = (e) => {
    const { value } = e.target;
    const char = e.key.toUpperCase();
    const pos = value.length;

    const validPattern = [
      /^[0-9]$/,            // 1st & 2nd: Digits
      /^[0-9]$/,
      /^[A-Z]$/,            // 3rd to 7th: Alphabets
      /^[A-Z]$/,
      /^[A-Z]$/,
      /^[A-Z]$/,
      /^[A-Z]$/,
      /^[0-9]$/,            // 8th to 11th: Digits
      /^[0-9]$/,
      /^[0-9]$/,
      /^[0-9]$/,
      /^[A-Z]$/,            // 12th: Alphabet
      /^[1-9A-Z]$/,         // 13th: Alphanumeric (1-9, A-Z)
      /^Z$/,                // 14th: Always 'Z'
      /^[0-9A-Z]$/          // 15th: Alphanumeric (0-9, A-Z)
    ];

    if (pos < 15 && !validPattern[pos].test(char)) {
      e.preventDefault(); // Block invalid characters
    }
  };

  const handleChangeGst = (e) => {
    let value = e.target.value.toUpperCase(); // Force uppercase
    if (value.length > 15) return; // Restrict length

    const isValid = GST_REGEX.test(value);
    const isDuplicate = existingGstList.includes(value);
    setIsGstValid(isValid);

    let updatedState = "";
    let extractedPan = "";

    if (value.length >= 2) {
      const stateCode = value.slice(0, 2);
      updatedState = stateCodes[stateCode] || "";
    }

    // Extract PAN when GST is valid
    if (value.length === 15 && isValid) {
      extractedPan = value.substring(2, 12); // PAN is from 3rd to 12th character
    }

    setFormData((prev) => ({
      ...prev,
      gstNo: value,
      state: updatedState,
      pan: extractedPan,
    }));

    // Show toast only if value is fully entered (15 chars)
    if (value.length === 15) {
      if (isDuplicate) {
        toast.error("GST NO Already Exists !!");
      }
    }
  };

  const handlechangeState = (event) => {
    const selectedState = event.target.value;
    const gstStateCode = formData.gstNo?.slice(0, 2); // Extract state code from GST
    
    // Allow "Export" to be selected manually
    if (selectedState === "Export") {
      setFormData((prevState) => ({
        ...prevState,
        state: selectedState,
      }));
      return;
    }
  
    // If GST code is empty or invalid, allow any state selection
    if (!gstStateCode || !stateCodes[gstStateCode]) {
      setFormData((prevState) => ({
        ...prevState,
        state: selectedState,
      }));
      return;
    }
  
    // Prevent wrong state selection if GST code is present and valid
    if (stateCodes[gstStateCode] !== selectedState) {
      toast.error("State does not match GST Number!", { autoClose: 2000 });
      return;
    }
  
    setFormData((prevState) => ({
      ...prevState,
      state: selectedState,
    }));
  };
  
  const [fileInputKey, setFileInputKey] = useState(0);
  const [open, setOpen] = useState(false);

  const handleSaveClick = async () => {
    document.body.style.backgroundColor = "white";
    let isDataSaved = false;
  
    try {
      const isValid = formData.ahead.trim() !== ""; // Ensure no empty spaces
      if (!isValid) {
        toast.error("Please Fill the Account Name", {
          position: "top-center",
        });
        return; // Prevent save operation
      }
  
      const userConfirmed = window.confirm("Are you sure you want to save the data?");
      if (!userConfirmed) {
        return; // Exit without disabling buttons
      }
  
      const combinedData = {
        _id: formData._id,
        formData: { ...formData }, // Simplified merging
      };
  
      console.log("Combined Data:", combinedData);
  
      const apiEndpoint = `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/ledgerAccount${isAbcmode ? `/${data1._id}` : ""}`;
      const method = isAbcmode ? "put" : "post";
  
      const response = await axios({
        method,
        url: apiEndpoint,
        data: combinedData,
      });
  
      if (response.status === 200 || response.status === 201) {
        fetchData();
        isDataSaved = true;
      }
    } catch (error) {
      console.error("Error saving data:", error);
      toast.error("Failed to save data. Please try again.", {
        position: "top-center",
      });
    } finally {
      // Only handle button states if user confirmed and data was attempted to be saved
      if (isDataSaved) {
        setIsSubmitEnabled(false); // Disable after successful save
        setIsAddEnabled(true);
        setIsDisabled(true);
        setIsEditMode(false);
        toast.success("Data Saved Successfully!", { position: "top-center" });
      } 
      // Remove else block to avoid changing button states when user cancels
    }
  };
  
  // const handleSaveClick = async () => {
  //   document.body.style.backgroundColor = "white";
  //   let isDataSaved = false;
  
  //   try {
  //     const isValid = formData.ahead.trim() !== "";  // Ensure no empty spaces
  //     if (!isValid) {
  //       toast.error("Please Fill the Account Name", {
  //         position: "top-center",
  //       });
  //       return; // Prevent save operation
  //     }
  
  //     const userConfirmed = window.confirm("Are you sure you want to save the data?");
  //     if (!userConfirmed) {
  //       return;
  //     }
  
  //     const combinedData = {
  //       _id: formData._id,
  //       formData: { ...formData } // Simplified merging
  //     };
  
  //     // Debugging
  //     console.log("Combined Data:", combinedData);
  
  //     const apiEndpoint = `http://103.168.19.65:3012/auth/ledgerAccount${isAbcmode ? `/${data1._id}` : ""}`;
  //     const method = isAbcmode ? "put" : "post";
  
  //     const response = await axios({
  //       method,
  //       url: apiEndpoint,
  //       data: combinedData,
  //     });
  
  //     if (response.status === 200 || response.status === 201) {
  //       fetchData();
  //       isDataSaved = true;
  //     }
  //   } catch (error) {
  //     console.error("Error saving data:", error);
  //     toast.error("Failed to save data. Please try again.", {
  //       position: "top-center",
  //     });
  //   } finally {
  //     if (isDataSaved) {
  //       setIsSubmitEnabled(false); // Disable after successful save
  //       setIsAddEnabled(true);
  //       setIsDisabled(true);
  //       setIsEditMode(false);
  //       toast.success("Data Saved Successfully!", { position: "top-center" });
  //     } else {
  //       // Keep the button enabled if data isn't saved
  //       setIsSubmitEnabled(formData.ahead.trim() === ""); 
  //       setIsAddEnabled(false);
  //       setIsDisabled(false);
  //     }
  //   }
  // };
  
  const handleEditClick = () => {
    setIsDisabled(false); // Enable fields when editing
    setIsEditMode(true); // Enter edit mode when editing
    setIsSubmitEnabled(true); // Enable the Save button when in edit mode
    setIsFetchEnabled(true);
    setIsSubMasterEnabled(true);
    setIsAbcmode(true);
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  };

  const handleDeleteClick = async (id) => {
    if (!id) {
      toast.error("Invalid ID. Please select an item to delete.", {
        position: "top-center",
      });
      return;
    }
    const userConfirmed = window.confirm(
      "Are you sure you want to delete this item?"
    );
    if (!userConfirmed) return;
    try {
      const apiEndpoint = `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/ledgerAccount/${data1._id}`;
      const response = await axios.delete(apiEndpoint);

      if (response.status === 200) {
        toast.success("Data deleted successfully!", { position: "top-center" });
        fetchData(); // Refresh the data after successful deletion
      } else {
        throw new Error(`Failed to delete data: ${response.statusText}`);
      }
    } catch (error) {
      console.error("Error deleting data:", error);
      toast.error(`Failed to delete data. Error: ${error.message}`, {
        position: "top-center",
      });
    } finally {
    }
  };
  const handleExit = async () => {
    document.body.style.backgroundColor = 'white'; // Reset background color
    setIsAddEnabled(true); // Enable "Add" button
    setIsSubmitEnabled(false);
    try {
        const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/ledgerAccount/last`); // Fetch the latest data
        if (response.status === 200 && response.data.data) {
            // If data is available
            const lastEntry = response.data.data;
            const lastIndex = response.data.length - 1;
            setFormData(lastEntry.formData); // Set form data
            setData1(response.data.data);
            setIndex(lastIndex);
           setIsDisabled(true); // Disable fields after loading the data
        } else {
            // If no data is available, initialize with default values
            console.log("No data available");
            const newData = {
          Bsgroup: "",
          acode: "",
          gstNo: "",
          ahead: "",
          add1: "",
          city: "",
          state: "",
          distance: "",
          pinCode: "",
          distt: "",
          opening_dr: "",
          opening_cr: "",
          msmed: "",
          phone: "",
          email: "",
          area: "",
          agent: "",
          group: "",
          pan: "",
          tcs206: "",
          tds194q: "",
          tdsno: "",
          wahead: "",
          wadd1: "",
          wadd2: "",
          Rc: "",
          Ecc: "",
          erange: "",
          collc: "",
          srvno: "",
          cperson: "",
          irate: "",
          tds_rate: "",
          tcs_rate: "",
          sur_rate: "",
          weight: "",
          bank_ac: "",
          narration: "",
          subname: "",
          subaddress: "",
          subcity: "",
          subgstNo: "",
            };
            setFormData(newData); // Set default form data
            setIsDisabled(true); // Disable fields after loading the default data
        }
    } catch (error) {
        console.error("Error fetching data", error);
    }
  };
 
  // FILEPICKER
  const { openFilePicker, filesContent, loading } = useFilePicker({
    key: fileInputKey,
    accept: ".txt",
  });
  const resetFilePicker = () => {
    setFileInputKey(null);
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleInputChange = async (event) => {
    const { name, value } = event.target;
    const numberValue = value.replace(/[^0-9]/g, ""); // Only allow numbers

    setFormData((prevState) => ({
      ...prevState,
      [name]: numberValue,
    }));

    // Trigger API call when pincode length reaches 6
    if (name === "pinCode" && numberValue.length === 6) {
      fetchDistrictByPincode(numberValue);
    }
  };

  const fetchDistrictByPincode = async (pincode) => {
    try {
      const response = await axios.get(`https://api.postalpincode.in/pincode/${pincode}`);
      const postOfficeData = response.data[0].PostOffice;

      if (postOfficeData && postOfficeData.length > 0) {
        setFormData((prevState) => ({
          ...prevState,
          distt: postOfficeData[0].District, // Update the district
        }));
      } else {
        setFormData((prevState) => ({
          ...prevState,
          distt: "Invalid Pincode",
        }));
      }
    } catch (error) {
      console.error("Error fetching district:", error);
      setFormData((prevState) => ({
        ...prevState,
        distt: "Error fetching data",
      }));
    }
  };
  const handlePanChange = (event) => {
    const { name, value } = event.target;
    const panValue = value.toUpperCase().replace(/[^A-Z0-9]/g, ""); // Convert to uppercase and remove non-alphanumeric characters
    setFormData((prevState) => ({
      ...prevState,
      [name]: panValue,
    }));
  };
  const handleBlur = (event) => {
    const { name, value } = event.target;
    // Validate PAN format on blur
    if (value && !/^[A-Z]{5}\d{4}[A-Z]{1}$/i.test(value)) {
      toast.error("Please enter a Valid Pan Number", {
        position: "top-center",
      });
      setFormData((prevState) => ({
        ...prevState,
        [name]: "",
      }));
    }
  };
    // Handle Enter key to move focus to the next enabled input
    const handleKeyDown = (e, index) => {
      // If toast is open, prevent focus movement
      if (toastOpen && (e.key === "Tab" || e.key === "Enter")) {
        e.preventDefault();
        return;
      }
  
      if (e.key === "Enter") {
        e.preventDefault();
        let nextIndex = index + 1;
  
        while (inputRefs.current[nextIndex] && inputRefs.current[nextIndex].disabled) {
          nextIndex += 1;
        }
  
        const nextInput = inputRefs.current[nextIndex];
        if (nextInput) {
          nextInput.focus();
        }
      }
    };
    const handleNumericValue = (event) => {
      const { id, value } = event.target;
      // Allow only numeric values, including optional decimal points
      if (/^\d*\.?\d*$/.test(value) || value === '') {
        setFormData((prevData) => ({
          ...prevData,
          [id]: value,
        }));
      }
    };
    const validateEmail = (e) => {
      const email = e.target.value.trim();
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // Basic email validation pattern
    
      // Show toast only if there's input and it's invalid
      if (email !== "" && !emailRegex.test(email)) {
        toast.error("Email format is not correct", {
          position: "top-center",
        });
      }
    };

    const handleRateBlur = (field) => {
      const decimalPlaces = 3; // Default to 3 decimal places if rateValue is undefined
      let value = parseFloat(formData[field]);
    
      if (isNaN(value)) {
        setFormData((prev) => ({ ...prev, [field]: "" })); // Keep empty if NaN
      } else {
        setFormData((prev) => ({ ...prev, [field]: value.toFixed(decimalPlaces) }));
      }
    };

    const handleBlurGst = () => {
      if (formData.gstNo.length > 0 && formData.gstNo.length < 15) {
        setToastOpen(true); // Block focus movement
        toast.error(
          <div style={{ textAlign: "center" }}>
            <p>GST Number is Not Valid!</p>
            <button
              onClick={() => {
                toast.dismiss();
                setToastOpen(false); // Allow focus movement again
                inputRefs.current[0]?.focus();
              }}
              style={{
                background: "red",
                color: "white",
                border: "none",
                padding: "5px 10px",
                cursor: "pointer",
                borderRadius: "4px",
                marginTop: "5px",
              }}
            >
              OK
            </button>
          </div>,
          {
            autoClose: false,
            closeOnClick: false,
            position: "top-center",
          }
        );
      }
    };
  return (
    <div>
      <h1
        className="heading"
        style={{
          fontWeight:'bold',
          marginTop: -35,
          letterSpacing: 10,
          fontSize: 30,
          textAlign:'center'
        }}
      >
        {formData.Bsgroup}
      </h1>
      <div>
        <div>
          <ToastContainer style={{ width: "30%" }} />
        </div>
        <div style={{ display: "flex", flexDirection: "row",width:"90%",marginLeft:"5%"}}>
          {/* First Half Screen */}
          <div className="FirstSec">
            <div>
            <div style={{ display: "flex", flexDirection: "row" }}>
              <text>A/c Code:</text>
              <input
                readOnly={!isEditMode || isDisabled}
                className="AccCode"
                type="number"
                name="acode"
                value={formData.acode}
                onChange={handleChangevalues}
              />
              </div>
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                }}
              >
                <text>GST No:</text>
                <input
                  readOnly={!isEditMode || isDisabled}
                  className="GSTNO"
                  type="text"
                  size="small"
                  style={{
                    border: isGstValid ? "1px solid #000000" : "4px solid red", // Conditional border color
                  }}
                  name="gstNo"
                  value={formData.gstNo}
                  onChange={handleChangeGst}
                  onBlur={handleBlurGst} // Show toast on blur if incomplete
                  ref={(el) => (inputRefs.current[0] = el)} // Assign ref
                  onKeyDown={(e) => handleKeyDown(e, 0)} // Handle Enter key
                  onKeyPress={handleKeyPress} // Restrict invalid keys
                />
                <div>
                  <Button
                    className="back"
                    style={{
                      width:100,
                      height:35,
                      marginLeft:2,
                      marginTop:-2
                      }}
                      disabled={!isFetchEnabled}
                    onClick={handleFetchData}
                  >
                    FetchData
                  </Button>
                  <Button
                    className="back"
                    style={{
                    width:98,
                    height:35,
                    marginLeft:8,
                    marginTop:-2
                    }}
                    disabled={!isSubMasterEnabled}
                    onClick={handleClickOpen}
                  >
                  SubMaster
                  </Button>
                </div>
              </div>
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  marginTop: 2,
                }}
              >
                <text>A/cName:</text>
                <input
                   readOnly={!isEditMode || isDisabled}
                  className="AccountName"
                  size="small"
                  label="ahead"
                  name="ahead"
                  value={formData.ahead}
                  onChange={handleChangevalues}
                  ref={(el) => (inputRefs.current[1] = el)} // Assign ref
                  onKeyDown={(e) => handleKeyDown(e, 1)} // Handle Enter key
                  maxLength={60}
                />
                <Dialog
                  open={open}
                  TransitionComponent={Transition}
                  keepMounted
                  onClose={handleClose}
                  aria-describedby="alert-dialog-slide-description"
                  PaperProps={{
                    style: {
                      // backgroundColor: "aqua", // Change background color here
                      borderRadius: 20, // Add border radius here
                      border:"2px solid black",
                      width:"60%",
                    },
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    <DialogTitle
                      // className="headerBack"
                      style={{
                        marginTop: 10,
                        textAlign: "center",
                        fontSize: 30,
                      }}
                    >
                      {"SUB-MASTER"}
                    </DialogTitle>
                  </div>
                  <DialogContent>
                    <DialogContentText>
                      {/* Description or instructions for the form */}
                    </DialogContentText>
                    <div
                      className="DialogInput"
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        marginLeft: 20,
                      }}
                    >
                      <div style={{display:'flex',flexDirection:'row'}}>
                        <text style={{fontSize:20}}>Name:</text>
                      <input
                          className="form-control"
                          style={{
                            marginLeft: 25,
                            width:"100%"
                          }}
                          name="subname"
                          value={formData.subname}
                          onChange={handleChangevalues}
                          margin="dense"
                        />
                      </div>
                      <div style={{display:'flex',flexDirection:'row',marginTop:5}}>
                      <text style={{fontSize:20}}>Address:</text>
                      <input
                          className="form-control"
                          style={{
                            marginLeft: 5,
                             width:"100%"
                          }}
                          name="subaddress"
                          value={formData.subaddress}
                          onChange={handleChangevalues}
                          margin="dense"
                        />
                       </div>
                       <div style={{display:'flex',flexDirection:'row',marginTop:5}}>
                       <text style={{fontSize:20}}>City:</text>
                       <input
                          className="form-control"
                          style={{
                            marginLeft: 43,
                             width:"100%"
                          }}
                          name="subcity"
                          value={formData.subcity}
                          onChange={handleChangevalues}
                          margin="dense"
                        />
                        </div>
                        <div style={{display:'flex',flexDirection:'row',marginTop:5}}>
                        <text style={{fontSize:20}}>GSTNo:</text>
                        <input
                          className="form-control"
                          style={{
                            marginLeft: 14,
                             width:"100%"
                          }}
                          name="subgstNo"
                          value={formData.subgstNo}
                          onChange={handleChangevalues}
                          margin="dense"
                        />
                          </div>
                    </div>
                    {/* Add more form fields as needed */}
                  </DialogContent>
                  <DialogActions>
                    <Button
                      onClick={handleClose}
                      style={{
                        backgroundColor: "#DC143C",
                        color: "black",
                        border:"transparent",
                        width:200
                      }}
                    >
                      Disagree
                    </Button>
                    <Button
                      onClick={handleFormSubmit}
                      style={{
                        backgroundColor: "#8FBC8F",
                        color: "black",
                        marginRight: "15%",
                         border:"transparent",
                         width:200
                      }}
                    >
                      Submit
                    </Button>
                  </DialogActions>
                </Dialog>
              </div>
              <div style={{display:"flex",flexDirection:"row",marginTop:2}}>
                <text>Address:</text>
              <input
                 readOnly={!isEditMode || isDisabled}
                className="ADD"
                size="small"
                label="add1"
                name="add1"
                value={formData.add1}
                onChange={handleChangevalues}
                ref={(el) => (inputRefs.current[2] = el)} // Assign ref
                onKeyDown={(e) => handleKeyDown(e, 2)} // Handle Enter key
                maxLength={48}
              />
              </div>
              <div style={{ display: "flex", flexDirection: "row",marginTop:2 }}>
                <text>City:</text>
                <input
                   readOnly={!isEditMode || isDisabled}
                  className="CITYNAME"
                  size="small"
                  label="City"
                  name="city"
                  value={formData.city}
                  onChange={handleAlphabetOnly}
                  ref={(el) => (inputRefs.current[3] = el)} // Assign ref
                  onKeyDown={(e) => handleKeyDown(e, 3)} // Handle Enter key
                  maxLength={38}
                />
              
              </div>
              <div style={{ display: "flex", flexDirection: "row",  marginTop: 2, }}>
                <text>PinCode:</text>
                <input
                   readOnly={!isEditMode || isDisabled}
                  className="PinCODE"
                  size="small"
                  label="PinCode"
                  name="pinCode"
                  value={formData.pinCode}
                  onChange={handleInputChange}
                  ref={(el) => (inputRefs.current[4] = el)} // Assign ref
                  onKeyDown={(e) => handleKeyDown(e, 4)} // Handle Enter key
                  maxLength={7}
                />
                 <input
                  value={"Distt:"}
                  style={{
                    width: 50,
                    height:32,
                    backgroundColor: "skyblue",
                    fontWeight: 600,
                    textAlign: "center",
                    color:'black'
                  }}
                  disabled
                />
                <input
                   readOnly={!isEditMode || isDisabled}
                  className="DISTT"
                  size="small"
                  maxLength={48}
                  label="Distt"
                  name="distt"
                  value={formData.distt}
                  onChange={handleChangevalues}
                  ref={(el) => (inputRefs.current[5] = el)} // Assign ref
                  onKeyDown={(e) => handleKeyDown(e, 5)} // Handle Enter key
                />
              </div>
              <div style={{display:'flex',flexDirection:'row',marginTop:2}} >
              <text>State:</text>
              <select
                name="state"
                className="STATENAME"
                value={formData.state}
                onChange={handlechangeState}
                ref={(el) => (inputRefs.current[6] = el)} // Assign ref
                onKeyDown={(e) => handleKeyDown(e, 6)} // Handle Enter key
              >
                <option value="">Select State</option>
                {Object.values(stateCodes).map((state, index) => (
                  <option key={index} value={state}>
                    {state}
                  </option>
                ))}
              </select>
                  <input
                  value={"Distance"}
                  style={{
                    width: 70,
                    height:32,
                    backgroundColor: "skyblue",
                    fontWeight: 600,
                    textAlign: "center",
                    color:'black'
                  }}
                  disabled
                />
                  <input
                  id="distance"
                  readOnly={!isEditMode || isDisabled}
                  className="DISTANCE"
                  size="small"
                  maxLength={10}
                  value={formData.distance}
                  onChange={handleNumericValue}
                  ref={(el) => (inputRefs.current[7] = el)} // Assign ref
                  onKeyDown={(e) => handleKeyDown(e, 7)} // Handle Enter key
                />
              </div>
              <div style={{ display: "flex", flexDirection: "row",marginTop:2 }}>
                <text>OpeningBalance:</text>
                <input
                  value={"Dr"}
                  style={{
                    width: 30,
                    height:32,
                    backgroundColor: "skyblue",
                    fontWeight: 600,
                    textAlign: "center",
                    color:'black',
                    marginLeft:25
                  }}
                  disabled
                />
                <input
                   readOnly={!isEditMode || isDisabled}
                  className="OpeningDR"
                  size="small"
                  label="opening_dr"
                  name="opening_dr"
                  value={formData.opening_dr}
                  onChange={handleInputChange}
                  ref={(el) => (inputRefs.current[8] = el)} // Assign ref
                  onKeyDown={(e) => handleKeyDown(e, 8)} // Handle Enter key
                  disabled={parseFloat(formData.opening_cr) > 0}
                  maxLength={15}
                />
                <input
                  value={"Cr"}
                  style={{
                    width: 30,
                    height:32,
                    marginLeft:1,
                    backgroundColor: "skyblue",
                    fontWeight: 600,
                    textAlign: "center",
                    color:'black'
                  }}
                  disabled
                />
                <input
                   readOnly={!isEditMode || isDisabled}
                  className="OpeningCR"
                  size="small"
                  label="opening_cr"
                  name="opening_cr"
                  value={formData.opening_cr}
                  onChange={handleInputChange}
                  ref={(el) => (inputRefs.current[9] = el)} // Assign ref
                  onKeyDown={(e) => handleKeyDown(e, 9)} // Handle Enter key
                  disabled={parseFloat(formData.opening_dr) > 0}
                  maxLength={15}
                />
              </div>
              <div style={{display:'flex',flexDirection:"row",marginTop:2}}>
                <text>StatusofMSMED:</text>
                <select
                   readOnly={!isEditMode || isDisabled}
                  className="dropdown"
                  style={{width:"78.5%",fontWeight:"bold",marginLeft:25,height:35,fontSize:18,border:"1px solid black"}}
                  value={formData.msmed}
                  onChange={handlechangeStatus}
                  ref={(el) => (inputRefs.current[10] = el)} // Assign ref
                  onKeyDown={(e) => handleKeyDown(e, 10)} // Handle Enter key
                  sx={{
                    "&:before": { borderColor: "black" },
                    "&:after": { borderColor: "black" },
                  }}
                >
                  <option value=""> </option>
                  <option value={"Micro Enterprises"}>
                    Micro Enterprises
                  </option>
                  <option value={"Small Enterprises"}>
                    Small Enterprises{" "}
                  </option>
                  <option value={"Medium Enterprises"}>
                    Medium Enterprises{" "}
                  </option>
                  <option value={"Not Covered in MSMED "}>
                    Not Covered in MSMED{" "}
                  </option>
                </select>
                </div>
                <div style={{ display: "flex", flexDirection: "row",marginTop:2 }}>
                  <text>Contact No:</text>
              <div style={{ position: "relative",marginLeft:63 }}>
                <span
                  style={{
                    position: "absolute",
                    top: "50%",
                    transform: "translateY(-50%)",
                    left: "10px",
                    color: "black",
                    fontSize:18
                  }}
                >
                  +91
                </span>
                <input
                   readOnly={!isEditMode || isDisabled}
                  className="ContactNO"
                  size="small"
                  label="Contact No"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  ref={(el) => (inputRefs.current[11] = el)} // Assign ref
                  onKeyDown={(e) => handleKeyDown(e, 11)} // Handle Enter key
                  style={{ width:"198%", paddingLeft: "45px",height:35 }} // Adjust paddingLeft to make space for the country code
                  maxLength={10}
                />
              </div>
              </div>
              <div style={{ display: "flex", flexDirection: "row",marginTop:2 }}>
                <text>Email:</text>
                <input
  readOnly={!isEditMode || isDisabled}
  type="email"
  className="EMAIL"
  size="small"
  label="Email ID"
  name="email"
  value={formData.email}
  onChange={handleChangevalues}
  ref={(el) => (inputRefs.current[12] = el)} // Assign ref
  onKeyDown={(e) => handleKeyDown(e, 12)}   // Handle Enter key
  onBlur={validateEmail}                    // Trigger validation on focus out
/>

                <input
                  value={"Area:"}
                  style={{
                    width: 50,
                    height:32,
                    backgroundColor: "skyblue",
                    fontWeight: 600,
                    textAlign: "center",
                    color:"black"
                  }}
                  disabled
                />
                <input
                   readOnly={!isEditMode || isDisabled}
                  className="AREA"
                  size="small" 
                  label="Area"
                  name="area"
                  value={formData.area}
                  onChange={handleChangevalues}
                  ref={(el) => (inputRefs.current[13] = el)} // Assign ref
                  onKeyDown={(e) => handleKeyDown(e, 13)} // Handle Enter key
                  maxLength={28}
                />
              </div>
              <div style={{ display: "flex", flexDirection: "row",marginTop:2 }}>
                <text>Agent:</text>
                <input
                   readOnly={!isEditMode || isDisabled}
                  className="AGENT"
                  size="small" 
                  label="Agent / Group"
                  name="agent"
                  value={formData.agent}
                  onChange={handleChangevalues}
                  ref={(el) => (inputRefs.current[14] = el)} // Assign ref
                  onKeyDown={(e) => handleKeyDown(e, 14)} // Handle Enter key
                  maxLength={30}
                />
                 <input
                  value={"Group:"}
                  style={{
                    width: 50,
                    height:32,
                    backgroundColor: "skyblue",
                    fontWeight: 600,
                    textAlign: "center",
                    color:"black"
                  }}
                  disabled
                />
                <input
                   readOnly={!isEditMode || isDisabled}
                  className="GROUP"
                  size="small"      
                  label="Group"
                  name="group"
                  value={formData.group}
                  onChange={handleChangevalues}
                  ref={(el) => (inputRefs.current[15] = el)} // Assign ref
                  onKeyDown={(e) => handleKeyDown(e, 15)} // Handle Enter key
                  maxLength={30}
                />
              </div>
              <div style={{display:'flex',flexDirection:"row",marginTop:2}}>
                <text>Pan:</text>
              <input
                 readOnly={!isEditMode || isDisabled}
                className="PANNO"
                size="small"    
                label="PAN"
                name="pan"
                value={formData.pan}
                onChange={handlePanChange}
                onBlur={handleBlur}
                maxLength={10}
                ref={(el) => (inputRefs.current[16] = el)} // Assign ref
                onKeyDown={(e) => handleKeyDown(e, 16)} // Handle Enter key
              />
              </div>
              <div style={{ display: "flex", flexDirection: "row",marginTop:2 }}>
                <text style={{color:"red"}}>TurnoverBelow10Cr</text>

                <select
                   readOnly={!isEditMode || isDisabled}
                  className="dropdown"
                  style={{ width:"30%",height:35,border:"1px solid black",marginLeft:3,fontWeight:"bold",fontSize:18}}
                  value={formData.tcs206}
                  onChange={handleTurnover}
                  ref={(el) => (inputRefs.current[17] = el)} // Assign ref
                  onKeyDown={(e) => handleKeyDown(e, 17)} // Handle Enter key
                >
                  <option value=""></option>
                  <option value={"Yes"}>Yes</option>
                  <option value={"No"}>NO</option>
                </select>
                <input
                  value={"Whether Approved:"}
                  style={{
                    width: 150,
                    backgroundColor: "skyblue",
                    fontWeight: 600,
                    textAlign: "center",
                    color:'black',
                    marginLeft:5
                  }}
                  disabled
                />
                 <select
                    readOnly={!isEditMode || isDisabled}
                  className="dropdown"
                  style={{ width:"30%",height:35,marginLeft:5,border:"1px solid black",fontWeight:"bold",fontSize:18}}
                  value={formData.tds194q}
                  onChange={handleApproved}
                  ref={(el) => (inputRefs.current[18] = el)} // Assign ref
                  onKeyDown={(e) => handleKeyDown(e, 18)} // Handle Enter key
                >
                  <option value=""></option>
                  <option value={"Yes"}>Yes</option>
                </select>
                </div>
                <div style={{display:'flex',flexDirection:"row",marginTop:2}}>
                  <text>TDSA/CNo:</text>
              <input
                 readOnly={!isEditMode || isDisabled}
                className="TDSAccNO"
                size="small"
                label="TDS A/C No"
                name="tdsno"
                value={formData.tdsno}
                onChange={handleInputChange}
                ref={(el) => (inputRefs.current[19] = el)} // Assign ref
                  onKeyDown={(e) => handleKeyDown(e, 19)} // Handle Enter key
                maxLength={15}
              />
              </div>
              <div style={{display:'flex',flexDirection:"row",marginTop:2}}>
              <text>Works:</text>
              <input
                 readOnly={!isEditMode || isDisabled}
                className="WORKS"
                size="small"
                label="wahead"
                name="wahead"
                value={formData.wahead}
                onChange={handleChangevalues}
                ref={(el) => (inputRefs.current[20] = el)} // Assign ref
                onKeyDown={(e) => handleKeyDown(e, 20)} // Handle Enter key
                maxLength={30}
              />
              </div>
              <div style={{display:'flex',flexDirection:"row",marginTop:2}}>
              <text>Name&Address:</text>
              <input
                 readOnly={!isEditMode || isDisabled}
                className="NameAndAdd"
                size="small"
                label="Name & Address"
                name="wadd1"
                value={formData.wadd1}
                onChange={handleChangevalues}
                ref={(el) => (inputRefs.current[21] = el)} // Assign ref
                onKeyDown={(e) => handleKeyDown(e, 21)} // Handle Enter key
                maxLength={30}
              />
              </div>
            </div>
          </div>
          {/* Second Half Screen */}
          <div className="SecondSec">
                    <div style={{ display: "flex", flexDirection: "row" }}>
                    <text>A/c & RTGS# : </text>
                      <input
                         readOnly={!isEditMode || isDisabled}
                        className="RTGS"
                        size="small"
                        name="Rc"
                        value={formData.Rc}
                        onChange={handleInputChange}
                        ref={(el) => (inputRefs.current[22] = el)} // Assign ref
                        onKeyDown={(e) => handleKeyDown(e, 22)} // Handle Enter key
                        maxLength={14}
                      />
                      <input
                        readOnly={!isEditMode || isDisabled}
                        className="ECC"
                        size="small"
                        name="Ecc"
                        value={formData.Ecc}
                        onChange={handleChangevalues}
                        ref={(el) => (inputRefs.current[23] = el)} // Assign ref
                        onKeyDown={(e) => handleKeyDown(e, 23)} // Handle Enter key
                        maxLength={14}
                      />
                    </div>
                    <div style={{display:"flex",flexDirection:"row",marginTop:5}}>
                      <text>Bank Name:</text>
                    <input
                       readOnly={!isEditMode || isDisabled}
                      className="BankNAME"
                      size="small"
                      label="Bank Name"
                      name="erange"
                      value={formData.erange}
                      onChange={handleChangevalues}
                      ref={(el) => (inputRefs.current[24] = el)} // Assign ref
                onKeyDown={(e) => handleKeyDown(e, 24)} // Handle Enter key
                      maxLength={30}
                    />
                    </div>
                    <div style={{display:"flex",flexDirection:"row",marginTop:5}}>
                      <text> Adhar No:</text>
                    <input
                       readOnly={!isEditMode || isDisabled}
                      className="AdharNO"
                      size="small"
                      label="Adhar No"
                      name="collc"
                      value={formData.collc}
                      onChange={handleInputChange}
                      ref={(el) => (inputRefs.current[25] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 25)} // Handle Enter key
                      maxLength={12}
                    />
                    </div>
                    <div style={{display:"flex",flexDirection:"row",marginTop:5}}>
                    <text>SAC Code:</text>
                    <input
                       readOnly={!isEditMode || isDisabled}
                      className="SACcode"
                      size="small"
                      label="SAC Code"
                      name="srvno"
                      value={formData.srvno}
                      onChange={handleInputChange}
                      ref={(el) => (inputRefs.current[26] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 26)} // Handle Enter key
                      maxLength={10}
                    />
                    </div>
              {/* Misc. Information / Attach Image Button */}
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  marginBottom: 5,
                  marginTop: 20,
                }}
              >
                {/* onClick={openFilePicker()} */}
                <Button style={{width:"100%"}} className="back">
                  {" "}
                  Misc. Information / Attach Image
                </Button>
                {/* <Button className="back" onClick={openFilePicker()}> Misc. Information / Attach Image</Button> */}
                {filesContent.map((file, index) => (
                  <div>
                    <h2>{file.name}</h2>
                    <div key={index}>{file.content}</div>
                    <br />
                  </div>
                ))}
                {/* {modalOpen && <Modal setOpenModal={setModalOpen} />} */}
              </div>   
                      <div style={{display:"flex",flexDirection:'row',marginTop:20}}>
                        <text>Contact Person:</text>
                      <input
                         readOnly={!isEditMode || isDisabled}
                        className="ContactPerson"
                        size="small"
                        label="cperson"
                        name="cperson"
                        value={formData.cperson}
                        onChange={handleChangevalues}
                        ref={(el) => (inputRefs.current[27] = el)} // Assign ref
                        onKeyDown={(e) => handleKeyDown(e, 27)} // Handle Enter key
                      />
                      </div>
                      <div style={{display:"flex",flexDirection:'row',marginTop:5}}>
                      <text>Intt/Depc.Rate:</text>
                      <input
                         readOnly={!isEditMode || isDisabled}
                        className="DepcRate"
                        size="small"
                        label="Intt/Depc Rate"
                        name="irate"
                        value={formData.irate}
                        onChange={handleInputChange}
                        ref={(el) => (inputRefs.current[28] = el)} // Assign ref
                        onKeyDown={(e) => handleKeyDown(e, 28)} // Handle Enter key
                        maxLength={6}
                        onBlur={() => handleRateBlur("irate")}
                      />
                      </div>
                      <div style={{display:"flex",flexDirection:'row',marginTop:5}}>
                      <text>TDS Rate:</text>
                      <input
                         readOnly={!isEditMode || isDisabled}
                        className="TDSrate"
                        size="small"
                        maxLength={6}
                        label="TDS Rate"
                        name="tds_rate"
                        value={formData.tds_rate}
                        onChange={handleInputChange}
                        ref={(el) => (inputRefs.current[29] = el)} // Assign ref
                        onKeyDown={(e) => handleKeyDown(e, 29)} // Handle Enter key
                        onBlur={() => handleRateBlur("tds_rate")}
                      />
                      </div>
                      <div style={{display:"flex",flexDirection:'row',marginTop:5}}>
                      <text>TCS Rate:</text>
                      <input
                         readOnly={!isEditMode || isDisabled}
                        className="TCSRate"
                        size="small"
                        maxLength={6}
                        label="TCS Rate"
                        name="tcs_rate"
                        value={formData.tcs_rate}
                        onChange={handleInputChange}
                        ref={(el) => (inputRefs.current[30] = el)} // Assign ref
                        onKeyDown={(e) => handleKeyDown(e, 30)} // Handle Enter key
                        onBlur={() => handleRateBlur("tcs_rate")}
                      />
                      </div>
                      <div style={{display:"flex",flexDirection:'row',marginTop:5}}>
                      <text>GST/Share % :</text>
                      <input
                         readOnly={!isEditMode || isDisabled}
                        className="GSTshare"
                        size="small"
                        maxLength={6}
                        label="GST/Share %"
                        name="sur_rate"
                        value={formData.sur_rate}
                        onChange={handleInputChange}
                        ref={(el) => (inputRefs.current[31] = el)} // Assign ref
                        onKeyDown={(e) => handleKeyDown(e, 31)} // Handle Enter key
                        onBlur={() => handleRateBlur("sur_rate")}
                      />
                      </div>
                      <div style={{display:"flex",flexDirection:'row',marginTop:5}}>
                      <text>Quantity :</text>
                      <input
                         readOnly={!isEditMode || isDisabled}
                        className="QT"
                        size="small"
                        maxLength={6}
                        label="weight"
                        name="weight"
                        value={formData.weight}
                        onChange={handleInputChange}
                        ref={(el) => (inputRefs.current[32] = el)} // Assign ref
                        onKeyDown={(e) => handleKeyDown(e, 32)} // Handle Enter key
                        onBlur={() => handleRateBlur("weight")}
                      />
                      </div>
                      {/* <div style={{display:"flex",flexDirection:'row',marginTop:5}}>
                      <text>Bank A/c No :</text>
                      <input
                         readOnly={!isEditMode || isDisabled}
                        className="form-control"
                        size="small"
                        style={{
                              width:"62%",backgroundColor:"white",marginLeft:78,height:35
                        }}
                        maxLength={4}
                        label="BanK A/C No"
                        name="bank_ac"
                        value={formData.bank_ac}
                        onChange={handleInputChange}
                      />
                      </div> */}
                      <div style={{display:"flex",flexDirection:'row',marginTop:5}}>
                      <text>Composition/RCM Y/N :</text>
                        <select
                           readOnly={!isEditMode || isDisabled}
                          className="dropdown"
                          style={{fontWeight: "bold",width:'62%',height:35,border:"1px solid black",marginLeft:2}}
                          value={formData.narration}
                          onChange={handlePosition}
                          ref={(el) => (inputRefs.current[33] = el)} // Assign ref
                          onKeyDown={(e) => handleKeyDown(e, 33)} // Handle Enter key
                        >
                          <option value=""></option>
                          <option value={"Yes"}>Yes</option>
                          <option value={"No"}>No</option>
                        </select>
                 </div>
          </div>
        </div>
        <div style={{marginTop:"1%"}} className="Buttonsgroupz">
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[0] }}
            onClick={handleAdd}
            disabled={!isAddEnabled}
          >
            Add
          </Button>
      <AnexureModal
        show={showModal}
        handleClose={() => setShowModal(false)}
        onSelect={handleSelectBsgroup} // Pass callback function
        handleExit={handleExit}
      />
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[1] }}
            onClick={handleEditClick}
          >
            Edit
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[2] }}
            onClick={handlePrevious}
            disabled={index === 0}
          >
            Previous
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[3] }}
            onClick={handleNext}
            disabled={index === data.length - 1}
          >
            Next
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[4] }}
            onClick={handleFirst}
            disabled={index === 0}
          >
            First
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[5] }}
            onClick={handleLast}
            disabled={index === data.length - 1}
          >
            Last
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[6] }}
            onClick={handleOpen}
          >
            Search
          </Button>
            <Modal open={openSearch} onClose={handleCloseSearch}>
                                <Box
                                  sx={{
                                    position: "absolute",
                                    top: "50%",
                                    left: "50%",
                                    transform: "translate(-50%, -50%)",
                                    width: 400,
                                    bgcolor: "background.paper",
                                    boxShadow: 24,
                                    p: 4,
                                    borderRadius: 2,
                                  }}
                                >
                                  <Typography variant="h6" mb={2}>
                                    Select Ledger Account
                                  </Typography>
                                  <Autocomplete
                                    fullWidth
                                    options={data2}
                                    getOptionLabel={(option) =>option?.formData?.ahead || ""} // Display Name
                                    value={selectedOption}
                                    onChange={handleSelect} // Handle selection
                                    renderInput={(params) => (
                                      <TextField
                                        {...params}
                                        variant="outlined"
                                        label="Search and Select"
                                        inputRef={autoCompleteRef} // Set focus on open
                                      />
                                    )}
                                  />
                                </Box>
                              </Modal>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[7] }}
          >
            Print
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[8] }}
            onClick={handleDeleteClick}
          >
            Delete
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[9] }}
            onClick={handleExit}
          >
            Exit
          </Button>
          <div>
            <Button
              ref={(el) => (inputRefs.current[34] = el)} // Assign ref
              onKeyDown={(e) => handleKeyDown(e, 34)} // Handle Enter key
              className="Buttonz"
              onClick={handleSaveClick}
              disabled={!isSubmitEnabled}
              style={{ color: "black", backgroundColor: buttonColors[10]}}
            >
              Save
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LedgerAcc;
