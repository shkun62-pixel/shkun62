// import React, { useEffect, useState } from 'react';
// import { Link, useNavigate } from 'react-router-dom';
// import Table from 'react-bootstrap/Table';

// const TrailDetails = () => {
//     const [selectedItem, setSelectedItem] = useState(null);
//     const navigate = useNavigate(); // useNavigate hook

//     useEffect(() => {
//         // Retrieve the selected item from local storage
//         const storedItem = localStorage.getItem('selectedItem');
//         if (storedItem) {
//             setSelectedItem(JSON.parse(storedItem));
//         }

//         // Add event listener for 'keydown' when component mounts
//         window.addEventListener('keydown', handleKeyDown);

//         // Cleanup function to remove event listener when component unmounts
//         return () => {
//             window.removeEventListener('keydown', handleKeyDown);
//         };
//     }, []);

//     const handleKeyDown = (event) => {
//         if (event.key === 'Escape') {
//             // Navigate back to TrailBalance page when 'Escape' key is pressed
//             navigate('/TrailBalance');
//         }
//     };


//     return (
//         <div>
//             <h1>TRAIL BALANCE</h1>
//             <div style={{ padding: 10 }}>
//                 <Table striped bordered hover>
//                     <thead style={{ backgroundColor: "skyblue", position: "sticky", top: 0, }}>
//                         <tr style={{ color: "white" }}>
//                             <th>ACCOUNT NAME</th>
//                             <th>CITY</th>
//                             <th>QTY</th>
//                             <th>DEBIT</th>
//                             <th>CREDIT</th>
//                         </tr>
//                     </thead>
//                     <tbody>
//                         {selectedItem && (
//                             <tr>
//                                 <td>{selectedItem.Accountname}</td>
//                                 <td>{selectedItem.City}</td>
//                                 <td>{selectedItem.Qty}</td>
//                                 <td style={{ color: "darkblue", textAlign: "right", fontWeight: "bold" }}>{selectedItem.Debit}</td>
//                                 <td style={{ color: "red", textAlign: "right", fontWeight: "bold" }}>{selectedItem.Credit}</td>
//                             </tr>
//                         )}
//                     </tbody>
//                 </Table>
//             </div>
//             <Link style={{ marginLeft: "45%" }} to="/TrailBalance">Go back to Trail Balance</Link>
//         </div>
//     );
// }

// export default TrailDetails;

import React, { useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import CustomerDetails from "./CustomerDetails ";

const TrailDetails = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { vacode, details } = location.state || {};

  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        navigate("/TrailBalance"); // Navigate back to the customer list
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [navigate]);

  if (!details) {
    return (
      <div>
        <p>No data available. Please go back and select a customer.</p>
        {/* <button onClick={() => navigate("/example")}>Go Back</button> */}
      </div>
    );
  }

  return (
    <div>
      <CustomerDetails
        selectedCustomer={{ vacode, details }}
        goBack={() => navigate("/TrailBalance")}
      />
    </div>
  );
};

export default TrailDetails;
