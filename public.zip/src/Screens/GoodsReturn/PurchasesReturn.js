import React, { useState, useEffect, useRef } from "react";
import "../Purchase/Purchase.css";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Table from "react-bootstrap/Table";
import Button from "react-bootstrap/Button";
import { BiTrash } from "react-icons/bi";
import ProductModal from "../Modals/ProductModal";
import ProductModalCustomer from "../Modals/ProductModalCustomer";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ModalVehicle from "../Modals/ModalVehicle";
import ModalTransport from "../Modals/ModalTransport";
import ModalBroker from "../Modals/ModalBroker";
import { useNavigate } from "react-router-dom";
import { FaPlus, FaMinus } from "react-icons/fa";
import PurchaseSetup from "../Purchase/PurchaseSetup";
import InvoicePDFPur from "../InvoicePdfPur";
import InvoicePur2 from "../InvoicePDF/InvoicePur2";
import InvoicePur3 from "../InvoicePDF/InvoicePur3";
import { useEditMode } from "../../EditModeContext";
import { CompanyContext } from '../Context/CompanyContext';
import { useContext } from "react";

const PurchasesReturn = () => {
   const [selectedInvoice, setSelectedInvoice] = useState('InvoicePDFPur');
    const invoiceComponents = {
      InvoicePDFPur,
      InvoicePur2,
      InvoicePur3,
    };
    const handleCloseInvoice = () => setOpen(false);
    const SelectedInvoiceComponent = invoiceComponents[selectedInvoice];

  const { company } = useContext(CompanyContext);
      const tenant = company?.databaseName;
  
      if (!tenant) {
        // you may want to guard here or show an error state,
        // since without a tenant you can’t hit the right API
        console.error("No tenant selected!");
      }
      
  const [title, setTitle] = useState("(View)");
  const [currentIndex, setCurrentIndex] = useState(null);
  const navigate = useNavigate();
  const itemCodeRefs = useRef([]);
  const datePickerRef = useRef([]);
  const desciptionRefs = useRef([]);
  const peciesRefs = useRef([]);
  const quantityRefs = useRef([]);
  const priceRefs = useRef([]);
  const amountRefs = useRef([]);
  const discountRef = useRef([]);
  const gstRefs = useRef([]);
  const othersRefs = useRef([]);
  const cgstRefs = useRef([]);
  const sgstRefs = useRef([]);
  const igstRefs = useRef([]);
  const hsnCodeRefs = useRef([]);
  const saveButtonRef = useRef(null);
  const adjustAdvance = useRef(null);
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [custGst, setCustgst] = useState("");
  const initialColors = [
    "#E9967A",
    "#F0E68C",
    "#FFDEAD",
    "#ADD8E6",
    "#87CEFA",
    "#FFF0F5",
    "#FFC0CB",
    "#D8BFD8",
    "#DC143C",
    "#DCDCDC",
    "#8FBC8F",
  ];
  const [buttonColors, setButtonColors] = useState(initialColors); // Initial colors
  const [formData, setFormData] = useState({
    date: "",
    vtype: "P",
    vno: 0,
    vbillno: 0,
    exfor: "",
    trpt: "",
    p_entry: 0,
    stype: "",
    btype: "",
    conv: "",
    vacode1: "",
    rem2: "",
    v_tpt: "",
    broker: "",
    srv_rate: 0,
    srv_tax: 0,
    tcs1_rate: 0,
    tcs1: 0,
    tcs206_rate: 0,
    tcs206: 0,
    duedate: "",
    gr: "",
    tdson: "",
    pcess: 0,
    tax: 0,
    cess1: 0,
    cess2: 0,
    sub_total: 0,
    exp_before: 0,
    Exp_rate6: 0,
    Exp_rate7: 0,
    Exp_rate8: 0,
    Exp_rate9:0,
    Exp_rate10: 0,
    Exp6: 0,
    Exp7: 0,
    Exp8: 0,
    Exp9: 0,
    Exp10: 0,
    Tds2:"",
    Ctds:"",
    Stds:"",
    iTds:"",
    cgst: 0,
    sgst: 0,
    igst: 0,
    expafterGST: 0,
    ExpRoundoff:0,
    grandtotal: 0,
    
  });
  const [supplierdetails, setsupplierdetails] = useState([
    {
      // VcodeSup
      Vcode:"",
      vacode: "",
      gstno: "",
      pan: "",
      Add1:"",
      city: "",
      state: "",
      Tcs206c1H:"",
      TDS194Q:"",
    },
  ]);
  const [items, setItems] = useState([
    {
      id: 1,
      vcode: "",
      sdisc: "",
      Units:"",
      pkgs: "",
      weight: "",
      rate: 0,
      amount: 0,
      disc:"",
      discount:"",
      gst: 0,
      Pcodes01:"",
      Pcodess:"",
      Scodes01:"",
      Scodess:"",
      Exp_rate1:0,
      Exp_rate2:0,
      Exp_rate3:0,
      Exp_rate4:0,
      Exp_rate5:0,
      Exp1:0,
      Exp2:0,
      Exp3:0,
      Exp4:0,
      Exp5:0,
      RateCal:"",
      Qtyperpc:0,
      exp_before: 0,
      ctax: 0,
      stax: 0,
      itax: 0,
      tariff: "",
      vamt: 0,
    },
  ]);
  const customerNameRef = useRef(null);
  const grNoRef = useRef(null);
  const termsRef = useRef(null);
  const vehicleNoRef = useRef(null);
  const tableRef = useRef(null);

  useEffect(() => {
    if (customerNameRef.current) {
      customerNameRef.current.focus();
    }
  }, []);

  const handleEnterKeyPress = (currentRef, nextRef) => (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      if (nextRef && nextRef.current) {
        nextRef.current.focus();
      } else {
        if (tableRef.current) {
          const firstInputInTable = tableRef.current.querySelector("input");
          if (firstInputInTable) {
            firstInputInTable.focus();
          }
        }
      }
    }
  };
  const [T11, setT11] = useState(false); // State to hold T11 value
  const [T12, setT12] = useState(false); // State to hold T11 value
  const [pkgsValue, setpkgsValue] = useState(null); 
  const [weightValue, setweightValue] = useState(null); 
  const [rateValue, setrateValue] = useState(null); 
      const [Expense1, setExpense1] = useState(""); 
      const [Expense2, setExpense2] = useState(""); 
      const [Expense3, setExpense3] = useState(""); 
      const [Expense4, setExpense4] = useState(null); 
      const [Expense5, setExpense5] = useState(null); 
      const [Expense6, setExpense6] = useState(null); 
      const [Expense7, setExpense7] = useState(null); 
      const [Expense8, setExpense8] = useState(null); 
      const [Expense9, setExpense9] = useState(null); 
      const [Expense10, setExpens10] = useState(null); 
      const [ExpRate1, setExpRate1] = useState(null); 
      const [ExpRate2, setExpRate2] = useState(null); 
      const [ExpRate3, setExpRate3] = useState(null); 
      const [ExpRate4, setExpRate4] = useState(null); 
      const [ExpRate5, setExpRate5] = useState(null); 
      const [ExpRate6, setExpRate6] = useState(null); 
      const [ExpRate7, setExpRate7] = useState(null); 
      const [ExpRate8, setExpRate8] = useState(null); 
      const [ExpRate9, setExpRate9] = useState(null); 
      const [ExpRate10, setExpRate10] = useState(null); 
      const [CalExp1, setCalExp1] = useState("");  
      const [CalExp2, setCalExp2] = useState("");  
      const [CalExp3, setCalExp3] = useState("");  
      const [CalExp4, setCalExp4] = useState("");  
      const [CalExp5, setCalExp5] = useState(""); 
      const [CalExp6, setCalExp6] = useState("");  
      const [CalExp7, setCalExp7] = useState("");  
      const [CalExp8, setCalExp8] = useState("");  
      const [CalExp9, setCalExp9] = useState("");  
      const [CalExp10, setCalExp10] = useState(""); 
      const [Pos, setPos] = useState("");   
      const [Pos2, setPos2] = useState("");  
      const [Pos3, setPos3] = useState("");  
      const [Pos4, setPos4] = useState("");  
      const [Pos5, setPos5] = useState("");  
      const [Pos6, setPos6] = useState("");  
      const [Pos7, setPos7] = useState("");  
      const [Pos8, setPos8] = useState("");  
      const [Pos9, setPos9] = useState("");  
      const [Pos10, setPos10] = useState("");  
      const [WindowBefore, setWindowBefore] = useState(null); 
      const [WindowAfter, setWindowAfter] = useState(null); 

    const fetchPurSetup = async () => {
      try {
        const response = await fetch(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/purchasesetup`);
        if (!response.ok) throw new Error("Failed to fetch sales setup");
    
        const data = await response.json();
    
        if (Array.isArray(data) && data.length > 0 && data[0].formData) {
          const formDataFromAPI = data[0].formData;
          setsetupFormData(formDataFromAPI);
          const T11Value = formDataFromAPI.T11;
          const T12Value = formDataFromAPI.T12;
          const e1RateValue = formDataFromAPI.E1rate;
          setpkgsValue(formDataFromAPI.pkgs);
          setweightValue(formDataFromAPI.weight);
          setrateValue(formDataFromAPI.rate);  
          setExpense1(formDataFromAPI.Exp1);   
          setExpense2(formDataFromAPI.Exp2);   
          setExpense3(formDataFromAPI.Exp3);   
          setExpense4(formDataFromAPI.Exp4);   
          setExpense5(formDataFromAPI.Exp5);   
          setExpense6(formDataFromAPI.Exp6);   
          setExpense7(formDataFromAPI.Exp7);   
          setExpense8(formDataFromAPI.Exp8);   
          setExpense9(formDataFromAPI.Exp9);   
          setExpens10(formDataFromAPI.Exp10); 
          setExpRate1(e1RateValue);
          setExpRate2(formDataFromAPI.E2rate);
          setExpRate3(formDataFromAPI.E3rate);
          setExpRate4(formDataFromAPI.E4rate);
          setExpRate5(formDataFromAPI.E5rate);
          setExpRate6(formDataFromAPI.E6rate);
          setExpRate7(formDataFromAPI.E7rate);
          setExpRate8(formDataFromAPI.E8rate);
          setExpRate9(formDataFromAPI.E9rate);
          setExpRate10(formDataFromAPI.E10rate);
          setCalExp1(formDataFromAPI.E1);  
          setCalExp2(formDataFromAPI.E2);  
          setCalExp3(formDataFromAPI.E3);  
          setCalExp4(formDataFromAPI.E4);  
          setCalExp5(formDataFromAPI.E5);  
          setCalExp6(formDataFromAPI.E6);  
          setCalExp7(formDataFromAPI.E7);  
          setCalExp8(formDataFromAPI.E8);  
          setCalExp9(formDataFromAPI.E9);  
          setCalExp10(formDataFromAPI.E10);  
          setPos(formDataFromAPI.E1add);
          setPos2(formDataFromAPI.E2add);
          setPos3(formDataFromAPI.E3add);
          setPos4(formDataFromAPI.E4add);
          setPos5(formDataFromAPI.E5add);
          setPos6(formDataFromAPI.E6add);
          setPos7(formDataFromAPI.E7add);
          setPos8(formDataFromAPI.E8add);
          setPos9(formDataFromAPI.E9add);
          setPos10(formDataFromAPI.E10add);
          setWindowBefore(formDataFromAPI.T6)
          setWindowAfter(formDataFromAPI.T7) 
          setSelectedInvoice(formDataFromAPI.reportformat)   
          // Update T21 and T12 states
          setT12(T12Value === "Yes");
          setT11(T11Value === "Yes");
        } else {
          throw new Error("Invalid response structure");
        }
      } catch (error) {
        console.error("Error fetching sales setup:", error.message);
      }
    };
    useEffect(() => {
      fetchPurSetup();
    }, [ExpRate1,ExpRate2,ExpRate3,,ExpRate4,,ExpRate5,ExpRate6,ExpRate7,ExpRate8,ExpRate9,ExpRate10]);

     // Getting UnitType From the Company Setup
  const getUnitTypeFromLocalStorage = () => {
    const companySetup = localStorage.getItem("companySetup");
    if (companySetup) {
      const parsedData = JSON.parse(companySetup);
      return parsedData?.formData?.unitType || ""; // Safely access unitType or return an empty string if not found
    }
    return ""; // Return an empty string if no data in localStorage
  };
  // Usage
  const unitType = getUnitTypeFromLocalStorage();
  console.log("Retrieved unitType:", unitType);

  const calculateTotalGst = (formDataOverride = formData, skipTCS = false) => {
     let totalValue = 0;
     let cgstTotal = 0;
     let sgstTotal = 0;
     let igstTotal = 0;
     let totalOthers = 0;
     let totalpcs = 0;
     let totalQty = 0;
     let totalDis = 0;
     const applicableTariffs = ["7204", "7602", "7902", "7404", "7503", "8002", "8101", "7802", "8112", "8113", "8104"];
   
     items.forEach((item) => {
       const value = parseFloat(item.amount || 0);
       totalValue += value;
       cgstTotal += parseFloat(item.ctax || 0);
       sgstTotal += parseFloat(item.stax || 0);
       igstTotal += parseFloat(item.itax || 0);
       totalOthers += parseFloat(item.exp_before || 0);
       totalpcs += parseFloat(item.pkgs || 0);
       totalQty += parseFloat(item.weight || 0);
       totalDis += parseFloat(item.discount || 0);
     });
 // Expense Calculations
 const subTotal = parseFloat(formDataOverride.sub_total) || 0;
 let exp6Rate = parseFloat(formDataOverride.Exp_rate6) || 0;
 let exp7Rate = parseFloat(formDataOverride.Exp_rate7) || 0;
 let exp8Rate = parseFloat(formDataOverride.Exp_rate8) || 0;
 let exp9Rate = parseFloat(formDataOverride.Exp_rate9) || 0;
 let exp10Rate = parseFloat(formDataOverride.Exp_rate10) || 0;
 let exp6 = 0; 
 let exp7 =0;
  let exp8=0; 
  let exp9=0; 
  let exp10=0;
 const Exp1Multiplier6 = Pos6 === "-Ve" ? -1 : 1;
 const Exp1Multiplier7 = Pos7 === "-Ve" ? -1 : 1;
 const Exp1Multiplier8 = Pos8 === "-Ve" ? -1 : 1;
 const Exp1Multiplier9 = Pos9 === "-Ve" ? -1 : 1;
 const Exp1Multiplier10 = Pos10 === "-Ve" ? -1 : 1;
 
 if(CalExp6 === "P" || CalExp6 === "p"){
   exp6 = (totalpcs * exp6Rate) / 100 || 0;
 }
 else if(CalExp6 === "W" || CalExp6 === "w"){
   exp6 = (totalQty * exp6Rate) / 100 || 0;
 }
 else if(CalExp6 === "V" || CalExp6 === "V" || CalExp6 === ""){
   exp6 = (subTotal * exp6Rate) / 100 || 0;
 }
 exp6 *= Exp1Multiplier6; // Apply negative only for Exp if Pos is "-Ve"
 formDataOverride.Exp6 = exp6.toFixed(2);
 // EXP 7 
 if(CalExp7 === "P" || CalExp7 === "p"){
   exp7 = (totalpcs * exp7Rate) / 100 || 0;
 }
 else if(CalExp7 === "W" || CalExp7 === "w"){
   exp7 = (totalQty * exp7Rate) / 100 || 0;
 }
 else if(CalExp7 === "V" || CalExp7 === "V" || CalExp7 === ""){
   exp7 = (subTotal * exp7Rate) / 100 || 0;
 }
 exp7 *= Exp1Multiplier7; // Apply negative only for Exp if Pos is "-Ve"
 formDataOverride.Exp7 = exp7.toFixed(2);
 // EXP 8 
 if(CalExp8 === "P" || CalExp8 === "p"){
   exp8 = (totalpcs * exp8Rate) / 100 || 0;
 }
 else if(CalExp8 === "W" || CalExp8 === "w"){
   exp8 = (totalQty * exp8Rate) / 100 || 0;
 }
 else if(CalExp8 === "V" || CalExp8 === "V" || CalExp8 === ""){
   exp8 = (subTotal * exp8Rate) / 100 || 0;
 }
 exp8 *= Exp1Multiplier8; // Apply negative only for Exp if Pos is "-Ve"
 formDataOverride.Exp8 = exp8.toFixed(2);
 // EXP 9
 if(CalExp9 === "P" || CalExp9 === "p"){
   exp9 = (totalpcs * exp9Rate) / 100 || 0;
 }
 else if(CalExp9 === "W" || CalExp9 === "w"){
   exp9 = (totalQty * exp9Rate) / 100 || 0;
 }
 else if(CalExp9 === "V" || CalExp9 === "V" || CalExp9 === ""){
   exp9 = (subTotal * exp9Rate) / 100 || 0;
 }
 exp9 *= Exp1Multiplier9; // Apply negative only for Exp if Pos is "-Ve"
 formDataOverride.Exp9 = exp9.toFixed(2);
 // EXP 10
 if(CalExp10 === "P" || CalExp10 === "p"){
   exp10 = (totalpcs * exp10Rate) / 100 || 0;
 }
 else if(CalExp10 === "W" || CalExp10 === "w"){
   exp10 = (totalQty * exp10Rate) / 100 || 0;
 }
 else if(CalExp10 === "V" || CalExp10 === "V" || CalExp10 === ""){
   exp10 = (subTotal * exp10Rate) / 100 || 0;
 }
 exp10 *= Exp1Multiplier10; // Apply negative only for Exp if Pos is "-Ve"
 formDataOverride.Exp10 = exp10.toFixed(2);
 
 // Calculate Total Expenses
 const totalExpenses = exp6 + exp7 + exp8 + exp9 + exp10;
 
     let gstTotal = cgstTotal + sgstTotal + igstTotal;
     let grandTotal = totalValue + gstTotal + totalOthers + totalExpenses - totalDis ;
     // ✅ Skip TCS Calculation if skipTCS is true
     let tcs206 = skipTCS ? parseFloat(formDataOverride.tcs206) : 0;
     let tcs206Rate = skipTCS ? parseFloat(formDataOverride.tcs206_rate) : 0;
     let tcs1 = skipTCS ? parseFloat(formDataOverride.tcs1) : 0;
     let tcs1Rate = skipTCS ? parseFloat(formDataOverride.tcs1_rate) : 0;
     let srvRate = skipTCS ? parseFloat(formDataOverride.srv_rate) : 0;
     let srv_tax = skipTCS ? parseFloat(formDataOverride.srv_tax) : 0;
   
     if (!skipTCS && unitType === "Trading") {
       tcs206 = (grandTotal * 1) / 100; // 1% TCS
       tcs206Rate = 1;
       grandTotal += tcs206;
     } else if (skipTCS) {
       grandTotal += parseFloat(tcs206); // Add existing TCS to grand total
     }
   
     const isTcs206c1HYes = supplierdetails?.some(cust => cust.Tcs206c1H?.toLowerCase() === "yes") || false;
     if (!skipTCS && isTcs206c1HYes) {
       tcs1 = (grandTotal * 0.1) / 100; // 0.1%
       tcs1Rate = 0.1;
       grandTotal += tcs1;
     }else if (skipTCS) {
       grandTotal += parseFloat(tcs1); // Add existing TCS to grand total
     }
   
     const isTDS149QYes = supplierdetails?.some(cust => cust.TDS194Q?.toLowerCase() === "yes") || false;
     if (!skipTCS && isTDS149QYes) {
       srv_tax = (grandTotal * 2) / 100; // 2%
       srvRate = 2;
       // grandTotal += srv_tax;
     }
   
     let cTds = 0, sTds = 0, iTds = 0 , tcspercentage = "0";
     const gstNumber = "03";
     const same = custGst.substring(0, 2);
     items.forEach((item) => {
       if (item.tariff && applicableTariffs.some((tariff) => item.tariff.startsWith(tariff))) {
         if (gstNumber === same) {
           cTds = totalValue * 0.01;
           sTds = totalValue * 0.01;
           tcspercentage = "2%"
         } else {
           iTds = totalValue * 0.02;
           tcspercentage = "2%"
         }
       }
     });
 
    let totalTds = cTds + sTds + iTds;
    let expafterGST = tcs206 + tcs1;
    let originalGrandTotal = grandTotal; // Save the unrounded grandTotal
 
     if (T11) {
       totalValue = Math.round(totalValue);
       grandTotal = Math.round(grandTotal);
       totalDis = Math.round(totalDis);
     }
   
     if (T12) {
       gstTotal = Math.round(gstTotal);
       cgstTotal = Math.round(cgstTotal);
       sgstTotal = Math.round(sgstTotal);
       igstTotal = Math.round(igstTotal);
       totalOthers = Math.round(totalOthers);
       expafterGST = Math.round(expafterGST);
       totalTds = Math.round(totalTds);
       tcs206 = Math.round(tcs206);
       srv_tax = Math.round(srv_tax);
       cTds = Math.round(cTds);
       sTds = Math.round(sTds);
       iTds = Math.round(iTds);
     }
     // Calculate Round-Off Difference
     let ExpRoundoff = grandTotal - originalGrandTotal;
 
     return {
       ...formDataOverride,
       tcsper:tcspercentage,
       tcs206: tcs206.toFixed(2),
       tcs206_rate: tcs206Rate.toFixed(2),
       tcs1: tcs1.toFixed(2),
       tcs1_rate: tcs1Rate.toFixed(2),
       srv_tax: srv_tax.toFixed(2),
       srv_rate: srvRate.toFixed(2),
       tax: gstTotal.toFixed(2),
       cgst: cgstTotal.toFixed(2),
       sgst: sgstTotal.toFixed(2),
       igst: igstTotal.toFixed(2),
       sub_total: totalValue.toFixed(2),
       Tds2: totalTds.toFixed(2),
       Ctds: cTds.toFixed(2),
       Stds: sTds.toFixed(2),
       iTds: iTds.toFixed(2),
       grandtotal: grandTotal.toFixed(2),
       exp_before: (totalOthers - totalDis).toFixed(2),
       expafterGST: (totalExpenses + tcs206 + tcs1).toFixed(2),
       ExpRoundoff :ExpRoundoff.toFixed(2)
     };
   };
    
   useEffect(() => {
   setFormData((prevState) => calculateTotalGst(prevState));
   }, [items,T11,T12]);

  // Api Response
    const [data, setData] = useState([]);
    const [data1, setData1] = useState([]);
    const [index, setIndex] = useState(0);
    const [isAddEnabled, setIsAddEnabled] = useState(true);
    const [isSubmitEnabled, setIsSubmitEnabled] = useState(false);
    const [isPreviousEnabled, setIsPreviousEnabled] = useState(true);
    const [isNextEnabled, setIsNextEnabled] = useState(true);
    const [isFirstEnabled, setIsFirstEnabled] = useState(true);
    const [isLastEnabled, setIsLastEnabled] = useState(true);
    const [isSearchEnabled, setIsSearchEnabled] = useState(true);
    const [isPrintEnabled, setIsSPrintEnabled] = useState(true);
    const [isDeleteEnabled, setIsDeleteEnabled] = useState(true);
    const { isEditMode, setIsEditMode } = useEditMode(); // Access the context
    const [isAbcmode, setIsAbcmode] = useState(false);
    const [isEditMode2, setIsEditMode2] = useState(false); // State to track edit mode
    const [isDisabled, setIsDisabled] = useState(false); // State to track field disablement
    const [firstTimeCheckData, setFirstTimeCheckData] = useState("");
    const [setupFormData, setsetupFormData] = useState(null);
 
  const fetchData = async () => {
      try {
        const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/purchasegst/last`);
        // console.log("Response: ", response.data);
    
        if (response.status === 200 && response.data && response.data.data) {
          const lastEntry = response.data.data;
          // Ensure date is valid
          const isValidDate = (date) => {
            return !isNaN(Date.parse(date));
          };
    
          // Update form data, use current date if date is invalid or not available
          const updatedFormData = {
            ...lastEntry.formData,
            date: isValidDate(lastEntry.formData.date) ? lastEntry.formData.date : new Date().toLocaleDateString("en-IN"),
          };
    
          setFirstTimeCheckData("DataAvailable");
          setFormData(updatedFormData);
          //console.log(updatedFormData, "Formdata2");
    
          // Update items and supplier details
          const updatedItems = lastEntry.items.map(item => ({
            ...item,
          }));
          const updatedCustomer = lastEntry.supplierdetails.map(item => ({
            ...item,
          }));
          setItems(updatedItems);
          setsupplierdetails(updatedCustomer);
    
          // Set custGst from the supplier details
          if (updatedCustomer.length > 0) {
            setCustgst(updatedCustomer[0].gstno);  // Set GST number
          }
    
          // Set data and index
          setData1({ ...lastEntry, formData: updatedFormData });
          setIndex(lastEntry.vno);
        } else {
          setFirstTimeCheckData("DataNotAvailable");
          //console.log("No data available");
          initializeEmptyData();
        }
      } catch (error) {
        console.error("Error fetching data", error);
        initializeEmptyData();
      }
    };
   // Function to initialize empty data
   const initializeEmptyData = () => {
    // Default date as current date
    const emptyFormData = {
        date: new Date().toLocaleDateString(), // Use today's date
        vtype: "P",
        vno: 0,
        vbillno: 0,
        exfor: "",
        trpt: "",
        p_entry: 0,
        stype: "",
        btype: "",
        conv: "",
        vacode1: "",
        rem2: "",
        v_tpt: "",
        broker: "",
        srv_rate: 0,
        srv_tax: 0,
        tcs1_rate: 0,
        tcs1: 0,
        tcs206_rate: 0,
        tcs206: 0,
        duedate: "",
        gr: "",
        tdson: "",
        pcess: 0,
        tax: 0,
        cess1: 0,
        cess2: 0,
        sub_total: 0,
        exp_before: 0,
        Exp_rate6: 0,
        Exp_rate7: 0,
        Exp_rate8: 0,
        Exp_rate9:0,
        Exp_rate10: 0,
        Exp6: 0,
        Exp7: 0,
        Exp8: 0,
        Exp9: 0,
        Exp10: 0,
        cgst: 0,
        sgst: 0,
        igst: 0,
        expafterGST: 0,
        grandtotal: 0,
    };
    const emptyItems = [{
      id: 1,
      vcode: "",
      sdisc: "",
      Units:"",
      pkgs: "",
      weight: "",
      rate: 0,
      amount: 0,
      disc:"",
      discount:"",
      gst: 0,
      Pcodes01:"",
      Pcodess:"",
      Scodes01:"",
      Scodess:"",
      Exp_rate1:0,
      Exp_rate2:0,
      Exp_rate3:0,
      Exp_rate4:0,
      Exp_rate5:0,
      Exp1:0,
      Exp2:0,
      Exp3:0,
      Exp4:0,
      Exp5:0,
      exp_before: 0,
      ctax: 0,
      stax: 0,
      itax: 0,
      tariff: "",
      vamt: 0,
    }];
    const emptysupplier = [{
       // VcodeSup
      Vcode:"",
        vacode: "",
        gstno: "",
        pan: "",
        Add1:"",
        city: "",
        state: "",
        Tcs206c1H:"",
        TDS194Q:"",
    }];
    // Set the empty data
    setFormData(emptyFormData);
    setItems(emptyItems);
    setsupplierdetails(emptysupplier);
    setData1({ formData: emptyFormData, items: emptyItems, supplierdetails: emptysupplier }); // Store empty data
    setIndex(0);
};

  useEffect(() => {
    fetchData(); // Fetch data when component mounts
  }, []); // Empty dependency array ensures it only runs once when component mounts

  useEffect(() => {
    if (data.length > 0) {
      setFormData(data[data.length - 1]); // Set currentData to the last record
      setIndex(data.length - 1);
    }
  }, [data]);

  // Add this line to set isDisabled to true initially
  useEffect(() => {
    setIsDisabled(true);
  }, []);

  const handleNext = async () => {
    document.body.style.backgroundColor = 'white';
    setTitle("(View)");
  
    try {
      if (data1) {
        const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/purchasegst/${data1._id}/next`);
        if (response.status === 200 && response.data) {
          const nextData = response.data.data;
          setData1(nextData);
          setIndex(index + 1);
          setFormData(nextData.formData);
  
          // Update items and supplier details
          const updatedItems = nextData.items.map(item => ({
            ...item,
          }));
          const updatedCustomer = nextData.supplierdetails.map(item => ({
            ...item,
          }));
          setItems(updatedItems);
          setsupplierdetails(updatedCustomer);
  
          // Set custGst from the supplier details
          if (updatedCustomer.length > 0) {
            setCustgst(updatedCustomer[0].gstno);  // Set GST number
          }
  
          setIsDisabled(true);
        }
      }
    } catch (error) {
      console.error("Error fetching next record:", error);
    }
  };

  const handlePrevious = async () => {
    document.body.style.backgroundColor = 'white';
    setTitle("(View)");
  
    try {
      if (data1) {
        const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/purchasegst/${data1._id}/previous`);
        if (response.status === 200 && response.data) {
          const prevData = response.data.data;
          setData1(prevData);
          setIndex(index - 1);
          setFormData(prevData.formData);
  
          // Update items and supplier details
          const updatedItems = prevData.items.map(item => ({
            ...item,
          }));
          const updatedCustomer = prevData.supplierdetails.map(item => ({
            ...item,
          }));
          setItems(updatedItems);
          setsupplierdetails(updatedCustomer);
  
          // Set custGst from the supplier details
          if (updatedCustomer.length > 0) {
            setCustgst(updatedCustomer[0].gstno);  // Set GST number
          }
          setIsDisabled(true);
        }
      }
    } catch (error) {
      console.error("Error fetching previous record:", error);
    }
  };

  const handleFirst = async () => {
    document.body.style.backgroundColor = 'white';
    setTitle("(View)");
  
    try {
      const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/purchasegst/first`);
      if (response.status === 200 && response.data) {
        const firstData = response.data.data;
        setData1(firstData);
        setIndex(0);
        setFormData(firstData.formData);
  
        // Update items and supplier details
        const updatedItems = firstData.items.map(item => ({
          ...item,
        }));
        const updatedCustomer = firstData.supplierdetails.map(item => ({
          ...item,
        }));
        setItems(updatedItems);
        setsupplierdetails(updatedCustomer);
  
        // Set custGst from the supplier details
        if (updatedCustomer.length > 0) {
          setCustgst(updatedCustomer[0].gstno);  // Set GST number
        }
  
        setIsDisabled(true);
      }
    } catch (error) {
      console.error("Error fetching first record:", error);
    }
  };

  const handleLast = async () => {
    document.body.style.backgroundColor = 'white';
    setTitle("(View)");
  
    try {
      const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/purchasegst/last`);
      if (response.status === 200 && response.data) {
        const lastData = response.data.data;
        setData1(lastData);
        const lastIndex = response.data.length - 1;
        setIndex(lastIndex);
        setFormData(lastData.formData);
  
        // Update items and supplier details
        const updatedItems = lastData.items.map(item => ({
          ...item,
        }));
        const updatedCustomer = lastData.supplierdetails.map(item => ({
          ...item,
        }));
        setItems(updatedItems);
        setsupplierdetails(updatedCustomer);
  
        // Set custGst from the supplier details
        if (updatedCustomer.length > 0) {
          setCustgst(updatedCustomer[0].gstno);  // Set GST number
        }
  
        setIsDisabled(true);
      }
    } catch (error) {
      console.error("Error fetching last record:", error);
    }
  };

const handleAdd = async () => {
  try {
      await fetchData(); // This should set up the state correctly whether data is found or not
      let lastvoucherno = formData.vno ? parseInt(formData.vno) + 1 : 1;
      let lastBillno = formData.vbillno ? parseInt(formData.vbillno) + 1 : 1;
      const newData = {
        date: "",
        vtype: "P",
        vno: lastvoucherno,
        vbillno: "",
        exfor: "",
        trpt: "",
        p_entry: 0,
        stype: "",
        btype: "",
        conv: "",
        vacode1: "",
        rem2: "",
        v_tpt: "",
        broker: "",
        srv_rate: 0,
        srv_tax: 0,
        tcs1_rate: 0,
        tcs1: 0,
        tcs206_rate: 0,
        tcs206: 0,
        duedate: "",
        gr: "",
        tdson: "",
        pcess: 0,
        tax: 0,
        cess1: 0,
        cess2: 0,
        sub_total: 0,
        exp_before: 0,
        Exp_rate6: ExpRate6 || 0,
        Exp_rate7: ExpRate7 || 0,
        Exp_rate8: ExpRate8 || 0,
        Exp_rate9: ExpRate9 || 0,
        Exp_rate10: ExpRate10 || 0,
        Exp6: 0,
        Exp7: 0,
        Exp8: 0,
        Exp9: 0,
        Exp10: 0,
        cgst: 0,
        sgst: 0,
        igst: 0,
        expafterGST: 0,
        grandtotal: 0,
      };
      setData([...data, newData]);
      setFormData(newData);
      setItems([{ 
        id: 1,
      vcode: "",
      sdisc: "",
      Units:"",
      pkgs: 0,
      weight: 0,
      rate: 0,
      amount: 0,
      disc:"",
      discount:"",
      gst: 0,
      Pcodes01:"",
      Pcodess:"",
      Scodes01:"",
      Scodess:"",
      Exp_rate1:ExpRate1 || 0,
      Exp_rate2:ExpRate2 || 0,
      Exp_rate3:ExpRate3 || 0,
      Exp_rate4:ExpRate4 || 0,
      Exp_rate5:ExpRate5 || 0,
      Exp1:0,
      Exp2:0,
      Exp3:0,
      Exp4:0,
      Exp5:0,
      exp_before: 0,
      ctax: 0,
      stax: 0,
      itax: 0,
      tariff: "",
      vamt: 0,
      }]);
      setsupplierdetails([{ 
         // VcodeSup
        Vcode:"",
        vacode: "",
        gstno: "",
        pan: "",
        Add1:"",
        city: "",
        state: "",
        Tcs206c1H:"",
        TDS194Q:"",
      }]);
      setIndex(data.length);
      setIsAddEnabled(false);
      setIsSubmitEnabled(true);
      setIsPreviousEnabled(false);
      setIsNextEnabled(false);
      setIsFirstEnabled(false);
      setIsLastEnabled(false);
      setIsSearchEnabled(false);
      setIsSPrintEnabled(false);
      setIsDeleteEnabled(false);
      setIsDisabled(false);
      setIsEditMode(true);
      if (datePickerRef.current) {
        datePickerRef.current.setFocus();
      }
  } catch (error) {
      console.error("Error adding new entry:", error);
  }
};

  const handleEditClick = () => {
    // document.body.style.backgroundColor = "#F0E68C";
    setTitle("Edit");
    setIsDisabled(false);
    setIsEditMode(true);
    setIsAddEnabled(false);
    setIsSubmitEnabled(true);
    setIsPreviousEnabled(false);
    setIsNextEnabled(false);
    setIsFirstEnabled(false);
    setIsLastEnabled(false);
    setIsSearchEnabled(false);
    setIsSPrintEnabled(false);
    setIsDeleteEnabled(false);
    setIsAbcmode(true);
    if (customerNameRef.current) {
      customerNameRef.current.focus();
    }
  };
  const handleSaveClick = async () => {
    document.body.style.backgroundColor = "white";
    let isDataSaved = false;
    try {
      const isValid = supplierdetails.every((item) => item.vacode !== "");
      if (!isValid) {
        toast.error("Please Fill the Customer Details", {
          position: "top-center",
        });
        return; // Prevent save operation
      }
      const nonEmptyItems = items.filter((item) => item.sdisc.trim() !== "");
      if (nonEmptyItems.length === 0) {
        toast.error("Please fill in at least one Items name.", {
          position: "top-center",
        });
        return;
      }
      const userConfirmed = window.confirm("Are you sure you want to save the data?");
      if (!userConfirmed) {
        return;
      }
      let combinedData;
      if (isAbcmode) {
        combinedData = {
          _id: formData._id,
          formData: {
            date: selectedDate.toLocaleDateString("en-IN"),
            vtype: formData.vtype,
            vno: formData.vno,
            vbillno: formData.vbillno,
            exfor: formData.exfor,
            trpt: formData.trpt,
            p_entry: formData.p_entry,
            stype: formData.stype,
            btype: formData.btype,
            conv: formData.conv,
            vacode1: formData.vacode1,
            rem2: formData.rem2,
            v_tpt: formData.v_tpt,
            broker: formData.broker,
            srv_rate: formData.srv_rate,
            srv_tax: formData.srv_tax,
            tcs1_rate: formData.tcs1_rate,
            tcs1: formData.tcs1,
            tcs206_rate: formData.tcs206_rate,
            tcs206: formData.tcs206,
            duedate: expiredDate.toLocaleDateString("en-IN"),
            gr: formData.gr,
            tdson: formData.tdson,
            pcess: formData.pcess,
            tax: formData.tax,
            cess1: formData.cess1,
            cess2: formData.cess2,
            sub_total: formData.sub_total,
            exp_before: formData.exp_before,
            Exp_rate6:formData.Exp_rate6,
            Exp_rate7:formData.Exp_rate7,
            Exp_rate8:formData.Exp_rate8,
            Exp_rate9:formData.Exp_rate9,
            Exp_rate10:formData.Exp_rate10,
            Exp6:formData.Exp6,
            Exp7:formData.Exp7,
            Exp8:formData.Exp8,
            Exp9:formData.Exp9,
            Exp10:formData.Exp10,
            Tds2:formData.Tds2,
            Ctds:formData.Ctds,
            Stds:formData.Stds,
            iTds:formData.iTds,
            cgst: formData.cgst,
            sgst: formData.sgst,
            igst: formData.igst,
            expafterGST: formData.expafterGST,
            ExpRoundoff:formData.ExpRoundoff,
            grandtotal: formData.grandtotal,
            // CGST, SGST, and IGST fields come from setupFormData
            cgst_ac: setupFormData.cgst_ac,
            cgst_code: setupFormData.cgst_code,
            sgst_ac: setupFormData.sgst_ac,
            sgst_code: setupFormData.sgst_code,
            igst_ac: setupFormData.igst_ac,
            igst_code: setupFormData.igst_code,
            labour_code: setupFormData.E1Code,
            labour_ac: setupFormData.E1name,

            postage_code: setupFormData.E2Code,
            postage_ac: setupFormData.E2name,

            discount_code: setupFormData.E3Code,
            discount_ac: setupFormData.E3name,

            freight_code: setupFormData.E4Code,
            freight_ac: setupFormData.E4name,

            expense5_code: setupFormData.E5Code,
            expense5_ac: setupFormData.E5name,

            expense6_code: setupFormData.E6Code,
            expense6_ac: setupFormData.E6name,

            expense7_code: setupFormData.E7Code,
            expense7_ac: setupFormData.E7name,

            expense8_code: setupFormData.E8Code,
            expense8_ac: setupFormData.E8name,

            expense9_code: setupFormData.E9Code,
            expense9_ac: setupFormData.E9name,

            expense10_code: setupFormData.E10Code,
            expense10_ac: setupFormData.E10name,
          },
          items: nonEmptyItems.map((item) => ({
            id: item.id,
            vcode: item.vcode,
            sdisc: item.sdisc,
            Units:item.Units,
            pkgs: item.pkgs,
            weight: item.weight,
            rate: item.rate,
            amount: item.amount,
            disc:item.disc,
            discount:item.discount,
            gst: item.gst,
            Pcodess:item.Pcodess,
            Pcodes01:item.Pcodes01,
            Scodess:item.Scodess,
            Scodes01:item.Scodes01,
            exp_before: item.exp_before,
            Exp_rate1:item.Exp_rate1,
            Exp_rate2:item.Exp_rate2,
            Exp_rate3:item.Exp_rate3,
            Exp_rate4:item.Exp_rate4,
            Exp_rate5:item.Exp_rate5,
            Exp1:item.Exp1,
            Exp2:item.Exp2,
            Exp3:item.Exp3,
            Exp4:item.Exp4,
            Exp5:item.Exp5,
            ctax: item.ctax,
            stax: item.stax,
            itax: item.itax,
            tariff: item.tariff,
            vamt: item.vamt,
          })),
          supplierdetails: supplierdetails.map((item) => ({
             // VcodeSup
            Vcode:item.Vcode,
            vacode: item.vacode,
            gstno: item.gstno,
            pan: item.pan,
            Add1:item.Add1,
            city: item.city,
            state: item.state,
            Tcs206c1H:item.Tcs206c1H,
            TDS194Q: item.TDS194Q,
          })),
        };
      } else {
        combinedData = {
          _id: formData._id,
          formData: {
            date: selectedDate.toLocaleDateString("en-IN"),
            vtype: formData.vtype,
            vno: formData.vno,
            vbillno: formData.vbillno,
            exfor: formData.exfor,
            trpt: formData.trpt,
            p_entry: formData.p_entry,
            stype: formData.stype,
            btype: formData.btype,
            conv: formData.conv,
            vacode1: formData.vacode1,
            rem2: formData.rem2,
            v_tpt: formData.v_tpt,
            broker: formData.broker,
            srv_rate: formData.srv_rate,
            srv_tax: formData.srv_tax,
            tcs1_rate: formData.tcs1_rate,
            tcs1: formData.tcs1,
            tcs206_rate: formData.tcs206_rate,
            tcs206: formData.tcs206,
            duedate: expiredDate.toLocaleDateString("en-IN"),
            gr: formData.gr,
            tdson: formData.tdson,
            pcess: formData.pcess,
            tax: formData.tax,
            cess1: formData.cess1,
            cess2: formData.cess2,
            sub_total: formData.sub_total,
            exp_before: formData.exp_before,
            Exp_rate6:formData.Exp_rate6,
            Exp_rate7:formData.Exp_rate7,
            Exp_rate8:formData.Exp_rate8,
            Exp_rate9:formData.Exp_rate9,
            Exp_rate10:formData.Exp_rate10,
            Exp6:formData.Exp6,
            Exp7:formData.Exp7,
            Exp8:formData.Exp8,
            Exp9:formData.Exp9,
            Exp10:formData.Exp10,
            Tds2:formData.Tds2,
            Ctds:formData.Ctds,
            Stds:formData.Stds,
            iTds:formData.iTds,
            cgst: formData.cgst,
            sgst: formData.sgst,
            igst: formData.igst,
            expafterGST: formData.expafterGST,
            ExpRoundoff:formData.ExpRoundoff,
            grandtotal: formData.grandtotal,
            // CGST, SGST, and IGST fields come from setupFormData
            cgst_ac: setupFormData.cgst_ac,
            cgst_code: setupFormData.cgst_code,
            sgst_ac: setupFormData.sgst_ac,
            sgst_code: setupFormData.sgst_code,
            igst_ac: setupFormData.igst_ac,
            igst_code: setupFormData.igst_code,
            labour_code: setupFormData.E1Code,
            labour_ac: setupFormData.E1name,

            postage_code: setupFormData.E2Code,
            postage_ac: setupFormData.E2name,

            discount_code: setupFormData.E3Code,
            discount_ac: setupFormData.E3name,

            freight_code: setupFormData.E4Code,
            freight_ac: setupFormData.E4name,

            expense5_code: setupFormData.E5Code,
            expense5_ac: setupFormData.E5name,

            expense6_code: setupFormData.E6Code,
            expense6_ac: setupFormData.E6name,

            expense7_code: setupFormData.E7Code,
            expense7_ac: setupFormData.E7name,

            expense8_code: setupFormData.E8Code,
            expense8_ac: setupFormData.E8name,

            expense9_code: setupFormData.E9Code,
            expense9_ac: setupFormData.E9name,

            expense10_code: setupFormData.E10Code,
            expense10_ac: setupFormData.E10name,
          },
          items: nonEmptyItems.map((item) => ({
            id: item.id,
            vcode: item.vcode,
            sdisc: item.sdisc,
            Units:item.Units,
            pkgs: item.pkgs,
            weight: item.weight,
            rate: item.rate,
            amount: item.amount,
            disc:item.disc,
            discount:item.discount,
            gst: item.gst,
            Pcodess:item.Pcodess,
            Pcodes01:item.Pcodes01,
            Scodess:item.Scodess,
            Scodes01:item.Scodes01,
            exp_before: item.exp_before,
            Exp_rate1:item.Exp_rate1,
            Exp_rate2:item.Exp_rate2,
            Exp_rate3:item.Exp_rate3,
            Exp_rate4:item.Exp_rate4,
            Exp_rate5:item.Exp_rate5,
            Exp1:item.Exp1,
            Exp2:item.Exp2,
            Exp3:item.Exp3,
            Exp4:item.Exp4,
            Exp5:item.Exp5,
            ctax: item.ctax,
            stax: item.stax,
            itax: item.itax,
            tariff: item.tariff,
            vamt: item.vamt,
          })),
          supplierdetails: supplierdetails.map((item) => ({
             // VcodeSup
            Vcode:item.Vcode,
            vacode: item.vacode,
            gstno: item.gstno,
            pan: item.pan,
            Add1:item.Add1,
            city: item.city,
            state: item.state,
            Tcs206c1H:item.Tcs206c1H,
            TDS194Q:item.TDS194Q,
          })),
        };
      }
      // Debugging
      console.log("Combined DataPUR:", combinedData);
      const apiEndpoint = `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/purchasegst${isAbcmode ? `/${data1._id}` : ""}`;
      const method = isAbcmode ? "put" : "post";
      const response = await axios({
        method,
        url: apiEndpoint,
        data: combinedData,
      });
      console.log("API Response:",response);

      if (response.status === 200 || response.status === 201) {
        fetchData();
        isDataSaved = true;
      }
    } catch (error) {
      console.error("Error saving data:", error);
      toast.error("Failed to save data. Please try again.", {
        position: "top-center",
      });
    } finally {
      setIsSubmitEnabled(false);
      if (isDataSaved) {
        setTitle("View");
        setIsAddEnabled(true);
        setIsDisabled(true);
        setIsEditMode(false);
        setIsPreviousEnabled(true);
        setIsNextEnabled(true);
        setIsFirstEnabled(true);
        setIsLastEnabled(true);
        setIsSPrintEnabled(true);
        setIsNextEnabled(true);
        setIsSearchEnabled(true);
        setIsDeleteEnabled(true);
        toast.success("Data Saved Successfully!", { position: "top-center" });
      } else {
        setIsAddEnabled(false);
        setIsDisabled(false);
      }
    }
  };
 
  const handleDeleteClick = async (id) => {
    if (!id) {
      toast.error("Invalid ID. Please select an item to delete.", {
        position: "top-center",
      });
      return;
    }
    const userConfirmed = window.confirm(
      "Are you sure you want to delete this item?"
    );
    if (!userConfirmed) return;
    try {
      const apiEndpoint = `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/purchasegst/${data1._id}`;
      const response = await axios.delete(apiEndpoint);

      if (response.status === 200) {
        toast.success("Data deleted successfully!", { position: "top-center" });
        fetchData(); // Refresh the data after successful deletion
      } else {
        throw new Error(`Failed to delete data: ${response.statusText}`);
      }
    } catch (error) {
      console.error("Error deleting data:", error);
      toast.error(`Failed to delete data. Error: ${error.message}`, {
        position: "top-center",
      });
    } finally {
   
    }
  };
 
  // Modal For Product Selection
  const [products, setProducts] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [selectedItemIndex, setSelectedItemIndex] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  React.useEffect(() => {
    // Fetch products from the API when the component mounts
    fetchProducts();
  }, []);

  const handleProductSelect = (product) => {
    if (selectedItemIndex !== null) {
      handleItemChange(selectedItemIndex, "name", product.Aheads);
      setShowModal(false);
    }
  };
  const handleItemChange = (index, key, value,field) => {
    // If key is "pkgs" or "weight", allow only numbers and a single decimal point
    if ((key === "pkgs" || key === "weight" || key === "tariff" || key === "rate" || key === "disc") && !/^\d*\.?\d*$/.test(value)) {
      return; // reject invalid input
    }
  const updatedItems = [...items];
  updatedItems[index][key] = value;

  // If the key is 'name', find the corresponding product and set the price
  if (key === "name") {
    const selectedProduct = products.find((product) => product.Aheads === value);
    if (selectedProduct) {
      updatedItems[index]["vcode"] = selectedProduct.Acodes;
      updatedItems[index]["sdisc"] = selectedProduct.Aheads;
      updatedItems[index]["Units"] = selectedProduct.Units;
      updatedItems[index]["rate"] = selectedProduct.Mrps;
      updatedItems[index]["gst"] = selectedProduct.itax_rate;
      updatedItems[index]["tariff"] = selectedProduct.Hsn;
      updatedItems[index]["Scodes01"] = selectedProduct.AcCode;
      updatedItems[index]["Scodess"] = selectedProduct.Scodess;
      updatedItems[index]["Pcodes01"] = selectedProduct.acCode;
      updatedItems[index]["Pcodess"] = selectedProduct.Pcodess;
      updatedItems[index]["RateCal"] = selectedProduct.Rateins;
      updatedItems[index]["Qtyperpc"] = selectedProduct.Qpps || 0;
    } else {
      updatedItems[index]["rate"] = ""; // Reset price if product not found
      updatedItems[index]["gst"] = ""; // Reset gst if product not found
    }
  }
  let rate = parseFloat(updatedItems[index].rate);
  let pkgs =  parseFloat(updatedItems[index].pkgs);
  let amount = parseFloat(updatedItems[index].amount);
  let Qtyperpkgs = updatedItems[index].Qtyperpc; 
  let AL = pkgs * Qtyperpkgs;
  let gst;
  if (pkgs > 0  && Qtyperpkgs > 0 && key !== "weight") {
    updatedItems[index]["weight"] = AL.toFixed(weightValue);
    }
  // Calculate CGST and SGST based on the GST value
  if(formData.stype ==="Tax Free Within State" &&  custGst.startsWith("03")){
    gst = 0
  }else if(formData.stype ==="Tax Free Interstate" &&  !custGst.startsWith("03")){
    gst = 0
  }
  else{
    gst = parseFloat(updatedItems[index].gst);
  }
  const totalAccordingWeight = parseFloat(updatedItems[index].weight) * parseFloat(updatedItems[index].rate);
  const totalAccordingPkgs = parseFloat(updatedItems[index].pkgs) * parseFloat(updatedItems[index].rate);
  let RateCal = updatedItems[index].RateCal;
  let TotalAcc = totalAccordingWeight; // Set a default value

// Calcuate the Amount According to RateCalculation field
  if (RateCal === "Default" || RateCal === "" || RateCal === null || RateCal === undefined) {
    TotalAcc = totalAccordingWeight;
    console.log("Default");
  } else if (RateCal === "Wt/Qty") {
    TotalAcc = totalAccordingWeight;
    console.log("totalAccordingWeight");
  } else if (RateCal === "Pc/Pkgs") {
    TotalAcc = totalAccordingPkgs;
    console.log("totalAccordingPkgs");
  }
  
  let others = parseFloat(updatedItems[index].exp_before) || 0;
    let disc = parseFloat(updatedItems[index].disc) || 0;
    let per = ((disc / 100) * TotalAcc).toFixed(2);
    let Amounts = TotalAcc - per + others;
  
  // Ensure TotalAcc is a valid number before calling toFixed()
  TotalAcc = isNaN(TotalAcc) ? 0 : TotalAcc;
  // Check if GST number starts with "0" to "3"
  const gstNumber = "03";
  const same = custGst.substring(0, 2);
  let cgst, sgst, igst;
  if (gstNumber == same) {
    cgst = (Amounts * (gst / 2)) / 100 || 0;
    sgst = (Amounts * (gst / 2)) / 100 || 0;
    igst = 0;
  } else {
    cgst = sgst = 0;
    igst = (Amounts * gst) / 100 || 0;
  }
  // Set CGST and SGST to 0 if IGST is applied, and vice versa
  if (igst > 0) {
    cgst = 0;
    sgst = 0;
  } else {
    igst = 0;
  }
  // Calculate the total with GST and Others
  // let rate = parseFloat(updatedItems[index].rate) || 0;
  let totalWithGST = Amounts + cgst + sgst + igst  ;
  // totalWithGST += others;
  // Update CGST, SGST, Others, and total fields in the item
  if (T11) {
    updatedItems[index]["discount"] = Math.round(per).toFixed(2);
    updatedItems[index]["amount"] = Math.round(TotalAcc).toFixed(2);
    updatedItems[index]["vamt"] = Math.round(totalWithGST).toFixed(2);
  } else {
    updatedItems[index]["discount"] = parseFloat(per).toFixed(2);
    updatedItems[index]["amount"] = TotalAcc.toFixed(2);
    updatedItems[index]["vamt"] = totalWithGST.toFixed(2);
  }
  if (T12) {
    updatedItems[index]["ctax"] = Math.round(cgst).toFixed(2);
    updatedItems[index]["stax"] = Math.round(sgst).toFixed(2);
    updatedItems[index]["itax"] = Math.round(igst).toFixed(2);
  } else {
    updatedItems[index]["ctax"] = cgst.toFixed(2);
    updatedItems[index]["stax"] = sgst.toFixed(2);
    updatedItems[index]["itax"] = igst.toFixed(2);
  }
  // Calculate the percentage of the value based on the GST percentage
  const percentage =((totalWithGST - TotalAcc) / TotalAcc) * 100;
  updatedItems[index]["percentage"] = percentage.toFixed(2);
  setItems(updatedItems);
  calculateTotalGst();
};

  const handleAddItem = () => {
    if (isEditMode) {
      const newItem = {
      id: items.length + 1,
      vcode: "",
      sdisc: "",
      Units:"",
      pkgs: 0,
      weight: 0,
      rate: 0,
      amount: 0,
      disc:"",
      discount:"",
      gst: 0,
      Pcodes01:"",
      Pcodess:"",
      Scodes01:"",
      Scodess:"",
      Exp_rate1:0,
      Exp_rate2:0,
      Exp_rate3:0,
      Exp_rate4:0,
      Exp_rate5:0,
      Exp1:0,
      Exp2:0,
      Exp3:0,
      Exp4:0,
      Exp5:0,
      exp_before: 0,
      ctax: 0,
      stax: 0,
      itax: 0,
      tariff: "",
      vamt: 0,
      };
      setItems((prevItems) => [...prevItems, newItem]);
      setTimeout(() => {
        itemCodeRefs.current[items.length].focus();
      }, 100);
    }
  };
  const handleDeleteItem = (index) => {
    if (isEditMode) {
        const confirmDelete = window.confirm("Do you really want to delete this item?");
        // Proceed with deletion if the user confirms
        if (confirmDelete) {
            const filteredItems = items.filter((item, i) => i !== index);
            setItems(filteredItems);
        }
    }
};

  const fetchProducts = async () => {
    try {
      const response = await fetch(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/stockmaster`);
      if (!response.ok) {
        throw new Error("Failed to fetch products");
      }
      const data = await response.json();
      // Flatten the data to make the nested formData directly accessible
      const flattenedData = data.map(item => ({
        ...item.formData,
        _id: item._id,
        PurchaseAcc: item.PurchaseAcc,
        SaleAcc: item.SaleAcc
      }));
      setProducts(flattenedData);
      setLoading(false);
      //console.log(flattenedData);
    } catch (error) {
      setError(error.message);
      setLoading(false);
    }
  };

  const openModalForItem = (index) => {
    if (isEditMode) {
      setSelectedItemIndex(index);
      setShowModal(true);
    }
  };

  const allFields = products.reduce((fields, product) => {
    Object.keys(product).forEach((key) => {
      if (!fields.includes(key)) {
        fields.push(key);
      }
    });

    return fields;
  }, []);

  // Modal For Customer
  const [productsCus, setProductsCus] = useState([]);
  const [showModalCus, setShowModalCus] = useState(false);
  const [selectedItemIndexCus, setSelectedItemIndexCus] = useState(null);
  const [loadingCus, setLoadingCus] = useState(true);
  const [errorCus, setErrorCus] = useState(null);
  
  React.useEffect(() => {
    // Fetch products from the API when the component mounts
    fetchCustomers();
  }, []);
  const fetchCustomers = async () => {
    try {
      const response = await fetch(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/ledgerAccount`);
      if (!response.ok) {
        throw new Error("Failed to fetch products");
      }

      const data = await response.json();
      //console.log(data);
      // Ensure to extract the formData for easier access in the rest of your app
      const formattedData = data.map(item => ({ ...item.formData, _id: item._id }));
      setProductsCus(formattedData);
      setLoadingCus(false);
    } catch (error) {
      setErrorCus(error.message);
      setLoadingCus(false);
    }
  };

  const handleOpenModalTpt = (event, index, field) => {
    if (event.key === "ArrowDown" && field ==='v_tpt') {
      setSelectedItemIndexCus(index);
      setShowModalCus(true);
      event.preventDefault();
    }
    if (event.key === "ArrowDown" && field ==='broker') {
      setSelectedItemIndexCus(index);
      setShowModalCus(true);
      event.preventDefault();
    }
  };

  const handleProductSelectCus = (product) => {
    if (selectedItemIndexCus !== null) {
      if (selectedItemIndexCus === "v_tpt") {
        setFormData((prevData) => ({
          ...prevData,
          v_tpt: product.ahead, // Update v_tpt field with selected value
        }));
      } else if(selectedItemIndexCus === "broker"){
        setFormData((prevData) => ({
          ...prevData,
          broker: product.ahead, // Update v_tpt field with selected value
        }));
      }
      else {
        handleItemChangeCus(selectedItemIndexCus, "name", product.ahead);
      }
      setShowModalCus(false);
  
      // Focus back on the respective input field after selecting the value
      setTimeout(() => {
        if (selectedItemIndexCus === "v_tpt") {
          transportRef.current?.focus(); // Focus back to transport field
        }else if(selectedItemIndexCus === "broker"){
          tdsRef.current?.focus()
        }
         else {
          grNoRef.current.focus();
        }
      }, 0);
    }
  };
  
  const handleItemChangeCus = (index, key, value) => {
    const updatedItems = [...supplierdetails];
    updatedItems[index][key] = value;
    // If the key is 'name', find the corresponding product and set the details
    if (key === "name") {
      const selectedProduct = productsCus.find((product) => product.ahead === value);
      if (selectedProduct) {
         // VcodeSup
        updatedItems[index]["Vcode"] = selectedProduct.acode;
        updatedItems[index]["vacode"] = selectedProduct.ahead;
        updatedItems[index]["gstno"] = selectedProduct.gstNo;
        updatedItems[index]["pan"] = selectedProduct.pan;
        updatedItems[index]["Add1"] = selectedProduct.add1;
        updatedItems[index]["city"] = selectedProduct.city;
        updatedItems[index]["state"] = selectedProduct.state;
        updatedItems[index]["Tcs206c1H"] = selectedProduct.tcs206;
        updatedItems[index]["TDS194Q"] = selectedProduct.tds194q;
        setCustgst(selectedProduct.gstNo);
      }
    }
    setsupplierdetails(updatedItems);
  };
  
  const openModalForItemCus = (index) => {
    if (isEditMode) {
      setSelectedItemIndexCus(index);
      setShowModalCus(true);
    }
  };

  const allFieldsCus = productsCus.reduce((fields, product) => {
    Object.keys(product).forEach((key) => {
      if (!fields.includes(key)) {
        fields.push(key);
      }
    });
    return fields;
  }, []);

  const handleTaxType = (event) => {
    const { value } = event.target; // Get the selected value from the event
    setFormData((prevState) => ({
      ...prevState,
      stype: value, // Update the ratecalculate field in FormData
    }));
  };
  const handleBillCash = (event) => {
    const { value } = event.target; // Get the selected value from the event
    setFormData((prevState) => ({
      ...prevState,
      btype: value, // Update the ratecalculate field in FormData
    }));
  };
  const handleTdsOn = (event) => {
    const { value } = event.target; // Get the selected value from the event
    setFormData((prevState) => ({
      ...prevState,
      tdson: value, // Update the ratecalculate field in FormData
    }));
  };

  const [selectedDate, setSelectedDate] = useState(new Date());
  const [dayName, setDayName] = useState('');
  const getDayName = (date) => {
    const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return daysOfWeek[date.getDay()];
};

  useEffect(() => {
      // If formData.date has a valid date string, parse it and set selectedDate
      if (formData.date) {
        try {
          const date = new Date(formData.date);
          if (!isNaN(date.getTime())) {
            setSelectedDate(date);
          } else {
            console.error("Invalid date value in formData.date:", formData.date);
          }
        } catch (error) {
          console.error("Error parsing date:", error);
        }
      } else {
        // If there's no date, we keep selectedDate as null so the DatePicker is blank,
        // but we can still have it open on today's date via openToDate
        setSelectedDate(null);
      }
    }, [formData.date]);
    
  const [expiredDate, setexpiredDate] = useState(null);

  useEffect(() => {
    if (formData.duedate) {
      setexpiredDate(new Date(formData.duedate));
    } else {
      const today = new Date();
      setexpiredDate(today);
      setFormData({ ...formData, duedate: today });
    }
  }, []);

  const handleDateChange = (date) => {
    if (date instanceof Date && !isNaN(date)) {
      setSelectedDate(date);

      // Format or store date in formData as needed
      const formattedDate = date.toISOString().split("T")[0]; // e.g. "2025-03-10"
      setFormData((prev) => ({ ...prev, date: date , duedate: date }));
    } else {
      console.error("Invalid date value");
    }
  };

  const handleCalendarClose = () => {
    // If no date is selected when the calendar closes, default to today's date
    if (!selectedDate) {
      const today = new Date();
      setSelectedDate(today);
    }
  };
  const HandleInputsChanges = (event) => {
    const { id, value } = event.target;
    setFormData((prevData) => ({
      ...prevData,
      [id]: value,
    }));
  };

  const handleNumberChange = (event) => {
    const { id, value } = event.target;
    const numberValue = value.replace(/[^0-9.]/g, "");
    const validNumberValue =
      numberValue.split(".").length > 2
        ? numberValue.replace(/\.{2,}/g, "").replace(/(.*)\./g, "$1.")
        : numberValue;
  
    setFormData((prevState) => {
      const newFormData = { ...prevState, [id]: validNumberValue };
      return calculateTotalGst(newFormData, true); // ✅ Skip TCS recalculation
    });
  };
  // INVOICE
  const [shopName, setShopName] = useState("NARAYAN FRUIT BAR"); // Set default value here
  const [description, setDescription] = useState(
    "STOCKISTS IN : FRESH FRUITS ARE AVAIABLE HERE"
  );
  const [address, setAddress] = useState(
    "AMLOH ROAD, OPP. FRIENDS INDS., MANDI GOBINDGARH (PB)"
  );
  const [GSTIN, setGSTIN] = useState("07AAAHT5580L1ZX");
  const [PAN, setPAN] = useState("BNV5855MN6");

  // Function to save data to local storage
  const saveToLocalStorage = () => {
    localStorage.setItem("shopName", shopName);
    localStorage.setItem("description", description);
    localStorage.setItem("address", address);
    localStorage.setItem("GSTIN", GSTIN);
    localStorage.setItem("PAN", PAN);
  };

  // Function to retrieve data from local storage
  const getFromLocalStorage = () => {
    const savedShopName = localStorage.getItem("shopName");
    const savedDescription = localStorage.getItem("description");
    const savedAddress = localStorage.getItem("address");
    const savedGSTIN = localStorage.getItem("GSTIN");
    const savedPAN = localStorage.getItem("PAN");

    if (savedShopName) setShopName(savedShopName);
    if (savedDescription) setDescription(savedDescription);
    if (savedAddress) setAddress(savedAddress);
    if (savedGSTIN) setGSTIN(savedGSTIN);
    if (savedPAN) setPAN(savedPAN);
  };

  useEffect(() => {
    // Retrieve data from local storage when component mounts
    getFromLocalStorage();
  }, []);

  useEffect(() => {
    // Save data to local storage whenever shopName, description, or address change
    saveToLocalStorage();
  }, [shopName, description, address, GSTIN, PAN]);
  
  //Modal to open modal for vehicle description
  const [open2, setOpen2] = useState(false);
  const handleOpen2 = () => setOpen2(true);
  const handleClose2 = () => setOpen2(false);

  const [users2, setUsers2] = useState(() => {
    const savedUsers2 = localStorage.getItem("users2");
    return savedUsers2
      ? JSON.parse(savedUsers2)
      : ["Option 1", "Option 2", "Option 3"];
  });
  const [selectedUser2, setSelectedUser2] = useState("");
  const [editedUser2, setEditedUser2] = useState("");
  const [isAddingNewUser2, setIsAddingNewUser2] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const filteredUsers = users2.filter((user) =>
    user.toLowerCase().includes(searchQuery.toLowerCase())
  );
  const inputRef = useRef(null);
  const tableBodyRef = useRef(null);

  useEffect(() => {
    localStorage.setItem("users2", JSON.stringify(users2));
  }, [users2]);

  const handleUserClick = (user) => {
    setSelectedUser2(user);
    setEditedUser2(user);
    setIsAddingNewUser2(false);
    inputRef.current.focus();
  };

  const handleSaveClick2 = () => {
    if (isAddingNewUser2) {
      setUsers2([...users2, editedUser2]);
      setIsAddingNewUser2(false);
    } else {
      const updatedUsers2 = users2.map((user) =>
        user === selectedUser2 ? editedUser2 : user
      );
      setUsers2(updatedUsers2);
    }
    setSelectedUser2("");
    setEditedUser2("");
  };

  const handleAddClick = () => {
    setIsAddingNewUser2(true);
    setSelectedUser2("");
    setEditedUser2("");
    inputRef.current.focus();
  };

  const handleRowClick = (user) => {
    setSelectedUser2(user);
    setFormData((prevData) => ({
      ...prevData,
      trpt: user,
    }));
    handleClose2(); // Close the modal
  };

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };
  const handleInputKeyDown = (event) => {
    if (isEditMode && event.key === "F7") {
      handleOpen2();
    }
  };
  // Modal For Broker
  const [openB, setOpenB] = useState(false);
  const handleOpenB = () => setOpenB(true);
  const handleCloseB = () => setOpenB(false);

  const [usersB, setUsersB] = useState(() => {
    const savedUsersB = localStorage.getItem("usersB");
    return savedUsersB
      ? JSON.parse(savedUsersB)
      : ["Option 1", "Option 2", "Option 3"];
  });
  const [selectedUserB, setSelectedUserB] = useState("");
  const [editedUserB, setEditedUserB] = useState("");
  const [isAddingNewUserB, setIsAddingNewUserB] = useState(false);
  const [highlightedIndexB, setHighlightedIndexB] = useState(0);
  const [searchQueryB, setSearchQueryB] = useState("");
  const filteredUsersB = usersB.filter((userB) =>
    userB.toLowerCase().includes(searchQueryB.toLowerCase())
  );
  const inputRefB = useRef(null);
  const tableBodyRefB = useRef(null);

  useEffect(() => {
    localStorage.setItem("usersB", JSON.stringify(usersB));
  }, [usersB]);

  const handleUserClickB = (userB) => {
    setSelectedUserB(userB);
    setEditedUserB(userB);
    setIsAddingNewUserB(false);
    inputRefB.current.focus();
  };

  const handleSaveClickB = () => {
    if (isAddingNewUserB) {
      setUsersB([...usersB, editedUserB]);
      setIsAddingNewUserB(false);
    } else {
      const updatedUsersB = usersB.map((userB) =>
        userB === selectedUserB ? editedUserB : userB
      );
      setUsersB(updatedUsersB);
    }
    setSelectedUserB("");
    setEditedUserB("");
  };

  const handleAddClickB = () => {
    setIsAddingNewUserB(true);
    setSelectedUserB("");
    setEditedUserB("");
    inputRefB.current.focus();
  };

  const handleRowClickB = (userB) => {
    setSelectedUserB(userB);
    setFormData((prevData) => ({
      ...prevData,
      broker: userB,
    }));
    handleCloseB(); // Close the modal
  };

  const handleSearchChangeB = (event) => {
    setSearchQueryB(event.target.value);
  };
  const handleInputKeyDownB = (event) => {
    if (isEditMode && event.key === "F7") {
      handleOpenB();
    }
  };

  const [fontSize, setFontSize] = useState(16.5); // Initial font size in pixels
  const increaseFontSize = () => {
    setFontSize((prevSize) => (prevSize < 20 ? prevSize + 2 : prevSize)); // Increase font size up to 20 pixels
  };
  const decreaseFontSize = () => {
    setFontSize((prevSize) => (prevSize > 14 ? prevSize - 2 : prevSize)); // Decrease font size down to 14 pixels
  };
  const [pressedKey, setPressedKey] = useState(""); // State to hold the pressed key
  const handleKeyDown = (event, index, field) => {
    if (event.key === "Enter") {
        switch (field) {
            case "vcode":
                desciptionRefs.current[index]?.focus();
                break;
            case "sdisc":
                if (items[index].sdisc.trim() === "") {
                    transportRef.current.focus();
                } else {
                    hsnCodeRefs.current[index]?.focus();
                }
                break;
            case "tariff":
                peciesRefs.current[index]?.focus();
                break;
            case "pkgs":
                quantityRefs.current[index]?.focus();
                break;
            case "weight":
                priceRefs.current[index]?.focus();
                break;
            case "rate":
                discountRef.current[index]?.focus();
                break;
            case "disc":
                othersRefs.current[index]?.focus();
                break;
            case "exp_before":
                if (index === items.length - 1) {
                    handleAddItem();
                    itemCodeRefs.current[index + 1]?.focus();
                } else {
                    itemCodeRefs.current[index + 1]?.focus();
                }
                break;
            default:
                break;
        }
    }
    // Move Right (→)
    else if (event.key === "ArrowRight") {
        if (field === "vcode"){ desciptionRefs.current[index]?.focus();
          setTimeout(() => desciptionRefs.current[index]?.select(), 0);
        }
        else if (field === "sdisc"){ hsnCodeRefs.current[index]?.focus();
          setTimeout(() => hsnCodeRefs.current[index]?.select(), 0);
        }
        else if (field === "tariff"){ peciesRefs.current[index]?.focus();
          setTimeout(() => peciesRefs.current[index]?.select(), 0);
        }
        else if (field === "pkgs"){ quantityRefs.current[index]?.focus();
          setTimeout(() => quantityRefs.current[index]?.select(), 0);
        }
        else if (field === "weight"){ priceRefs.current[index]?.focus();
          setTimeout(() => priceRefs.current[index]?.select(), 0);
        }
        else if (field === "rate"){ discountRef.current[index]?.focus();
          setTimeout(() => discountRef.current[index]?.select(), 0);
        }
         else if (field === "disc"){ othersRefs.current[index]?.focus();
          setTimeout(() => othersRefs.current[index]?.select(), 0);
        }
    }
    // Move Left (←)
    else if (event.key === "ArrowLeft") {
        if (field === "exp_before"){ discountRef.current[index]?.focus();
          setTimeout(() => discountRef.current[index]?.select(), 0);
        }
        else if (field === "disc"){ priceRefs.current[index]?.focus();
          setTimeout(() => priceRefs.current[index]?.select(), 0);
        }
        else if (field === "rate"){ quantityRefs.current[index]?.focus();
          setTimeout(() => quantityRefs.current[index]?.select(), 0);
        }
        else if (field === "weight"){ peciesRefs.current[index]?.focus();
          setTimeout(() => peciesRefs.current[index]?.select(), 0);
        }
        else if (field === "pkgs"){ hsnCodeRefs.current[index]?.focus();
          setTimeout(() => hsnCodeRefs.current[index]?.select(), 0);
        }
        else if (field === "tariff"){ desciptionRefs.current[index]?.focus();
          setTimeout(() => desciptionRefs.current[index]?.select(), 0);
        }
        else if (field === "sdisc"){ itemCodeRefs.current[index]?.focus();
          setTimeout(() => itemCodeRefs.current[index]?.select(), 0);
        }
        else if (field === "vcode") itemCodeRefs.current[index]?.focus();
    }
      // Move Up
 else if (event.key === "ArrowUp" && index > 0) {
  setTimeout(() => {
    if (field === "vcode") itemCodeRefs.current[index - 1]?.focus();
    else if (field === "sdisc") desciptionRefs.current[index - 1]?.focus();
    else if (field === "tariff") hsnCodeRefs.current[index - 1]?.focus();
    else if (field === "pkgs") peciesRefs.current[index - 1]?.focus();
    else if (field === "weight") quantityRefs.current[index - 1]?.focus();
    else if (field === "rate") priceRefs.current[index - 1]?.focus();
    else if (field === "disc") discountRef.current[index - 1]?.focus();
    else if (field === "exp_before") othersRefs.current[index - 1]?.focus();
  }, 100);
} 
// Move Down
else if (event.key === "ArrowDown" && index < items.length - 1) {
  setTimeout(() => {
    if (field === "vcode") itemCodeRefs.current[index + 1]?.focus();
    else if (field === "sdisc") desciptionRefs.current[index + 1]?.focus();
    else if (field === "tariff") hsnCodeRefs.current[index + 1]?.focus();
    else if (field === "pkgs") peciesRefs.current[index + 1]?.focus();
    else if (field === "weight") quantityRefs.current[index + 1]?.focus();
    else if (field === "rate") priceRefs.current[index + 1]?.focus();
    else if (field === "disc") discountRef.current[index + 1]?.focus();
    else if (field === "exp_before") othersRefs.current[index + 1]?.focus();
  }, 100);
} 
    // Open Modal on Letter Input in Account Name
    else if (/^[a-zA-Z]$/.test(event.key) && field === "accountname") {
        setPressedKey(event.key);
        openModalForItemCus(index);
        event.preventDefault();
    }
};
  // const handleKeyDown = (event, index, field) => {
  //   if (event.key === "Enter") {
  //     switch (field) {
  //       case "vcode":
  //         desciptionRefs.current[index].focus();
  //         break;
  //       case "sdisc":
  //         if (items[index].sdisc.trim() === "") {
  //           // Move focus to Save button if accountname is empty
  //           transportRef.current.focus();
  //         } else {
  //           peciesRefs.current[index].focus();
  //         }
  //         break;
  //       case "pkgs":
  //         quantityRefs.current[index].focus();
  //         break;
  //       case "weight":
  //         priceRefs.current[index].focus();
  //         break;
  //       case "rate":
  //         amountRefs.current[index].focus();
  //         break;
  //       case "amount":
  //         othersRefs.current[index].focus();
  //         break;
  //       // case 'gst':
  //       //     othersRefs.current[index].focus();
  //       //     break;
  //       case "exp_before":
  //         cgstRefs.current[index].focus();
  //         break;
  //       case "ctax":
  //         sgstRefs.current[index].focus();
  //         break;
  //       case "stax":
  //         igstRefs.current[index].focus();
  //         break;
  //       case "itax":
  //         hsnCodeRefs.current[index].focus();
  //         break;
  //       case "tariff":
  //         if (index === items.length - 1) {
  //           handleAddItem(); // Optionally add a new item if needed
  //           itemCodeRefs.current[index + 1]?.focus(); // Focus on the first input of the next row
  //         } else {
  //           itemCodeRefs.current[index + 1]?.focus();
  //         }
  //         break;
  //       default:
  //         break;
  //     }
  //   } else if (/^[a-zA-Z]$/.test(event.key) && field === "accountname") {
  //     setPressedKey(event.key); // Set the pressed key
  //     openModalForItemCus(index);
  //     event.preventDefault(); // Prevent any default action
  //   }
  // };
  const handleOpenModal = (event, index, field) => {
    if (/^[a-zA-Z]$/.test(event.key) && field === "vcode") {
      setPressedKey(event.key); // Set the pressed key
      openModalForItem(index);
      event.preventDefault(); // Prevent any default action
    }
  };
  const handleExit = async () => {
    try {
        const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/purchasegst/last`); // Fetch the latest data
        if (response.status === 200 && response.data.data) {
            // If data is available
            const lastEntry = response.data.data;
            setFormData(lastEntry.formData); // Set form data
            setData1(response.data.data);
            const updateditems = lastEntry.items.map(item => ({
              ...item, 
          }));
          const updateditems2 = lastEntry.supplierdetails.map(item => ({
            ...item, 
        }));
        setItems(updateditems)
          setsupplierdetails(updateditems2);
          setIsDisabled(true); // Disable fields after loading the data
          setIndex(lastEntry.formData)
          setIsAddEnabled(true);
          setIsSubmitEnabled(false);
          setIsPreviousEnabled(true);
          setIsNextEnabled(true);
          setIsFirstEnabled(true);
          setIsLastEnabled(true);
          setIsSearchEnabled(true);
          setIsSPrintEnabled(true)
          setIsDeleteEnabled(true)
        } else {
            // If no data is available, initialize with default values
            //console.log("No data available");
            const newData = {
              date: "",
              vtype: "P",
              vno: 0,
              vbillno: 0,
              exfor: "",
              trpt: "",
              p_entry: 0,
              stype: "",
              btype: "",
              conv: "",
              vacode1: "",
              rem2: "",
              v_tpt: "",
              broker: "",
              srv_rate: "",
              srv_tax: "",
              tcs1_rate: "",
              tcs1: "",
              tcs206_rate: "",
              tcs206: "",
              duedate: "",
              gr: "",
              tdson: "",
              pcess: "",
              tax: "",
              cess1: "",
              cess2: "",
              sub_total: "",
              exp_before: "",
              Exp_rate6: "",
              Exp_rate7: "",
              Exp_rate8: "",
              Exp_rate9:"",
              Exp_rate10: "",
              Exp6: "",
              Exp7: "'",
              Exp8: "",
              Exp9: "",
              Exp10: "",
              cgst: "",
              sgst: "",
              igst: "",
              expafterGST: "",
              grandtotal: "",
            };
            setFormData(newData); // Set default form data
            setItems([{
              id: 1,
              vcode: "",
              sdisc: "",
              Units:"",
              pkgs: "",
              weight: "",
              rate: 0,
              amount: 0,
              disc:"",
              discount:"",
              gst: 0,
              Pcodes01:"",
              Pcodess:"",
              Scodes01:"",
              Scodess:"",
              Exp_rate1:0,
              Exp_rate2:0,
              Exp_rate3:0,
              Exp_rate4:0,
              Exp_rate5:0,
              Exp1:0,
              Exp2:0,
              Exp3:0,
              Exp4:0,
              Exp5:0,
              exp_before: 0,
              ctax: 0,
              stax: 0,
              itax: 0,
              tariff: "",
              vamt: 0,
            }]);
            setsupplierdetails([{
              Vcode:"",
              vacode: "",
              gstno: "",
              pan: "",
              Add1:"",
              city: "",
              state: "",
              Tcs206c1H:"",
              TDS194Q:"",
            }]);
  
            setIsDisabled(true); // Disable fields after loading the default data
        }
    } catch (error) {
        console.error("Error fetching data", error);
    }
  };
  const advanceRef = useRef(null);
  const twoBRef = useRef(null);
  const transportRef = useRef(null);
  const brokerRef = useRef(null);
  const tcsRef = useRef([]);
  const tdsRef = useRef([]);
  const tdsRef2 = useRef([]);
  const GrRef = useRef(null);
  const vehicelRef = useRef(null);
  const cess1Ref = useRef(null);
  const cess2Ref = useRef(null);

  const handleKeyDowndown = (event, nextFieldRef) => {
    if (event.key === "Enter") {
      event.preventDefault(); // Prevent form submission
      if (nextFieldRef.current) {
        nextFieldRef.current.focus();
      }
    }
  };
  const gradientOptions = [
    { label: "Lavender", value: "linear-gradient(to right, #e6e6fa, #b19cd9)" },
    { label: "Yellow", value: "linear-gradient(to right, #fffac2, #ffdd57)" },
    { label: "Skyblue", value: "linear-gradient(to right, #ceedf0, #7fd1e4)" },
    { label: "Green", value: "linear-gradient(to right, #9ff0c3, #45a049)" },
    { label: "Pink", value: "linear-gradient(to right, #ecc7cd, #ff9a9e)" },
   ];
 
   const [color, setColor] = useState(() => {
     return localStorage.getItem("SelectedColorZ") || gradientOptions[0].value;
   });
 
   useEffect(() => {
     localStorage.setItem("SelectedColorZ", color);
   }, [color]);
 
   const handleChange = (event) => {
     setColor(event.target.value);
   };
   const handleInputChange = (index, field, value) => {
      const numericValue = value.replace(/[^0-9.-]/g, ''); // Allow only numbers, decimal points, and negative signs
      const updatedItems = [...items];
      updatedItems[index][field] = numericValue; 
    
      // Recalculate expenses when Exp_rate1 to Exp_rate6 change
      const vamt = parseFloat(updatedItems[index].amount) || 0;
      const expRates = [
        parseFloat(updatedItems[index].Exp_rate1) || 0,
        parseFloat(updatedItems[index].Exp_rate2) || 0,
        parseFloat(updatedItems[index].Exp_rate3) || 0,
        parseFloat(updatedItems[index].Exp_rate4) || 0,
        parseFloat(updatedItems[index].Exp_rate5) || 0,
      ];
      const expFields = ['Exp1', 'Exp2', 'Exp3', 'Exp4', 'Exp5',];
    
      let totalExpenses = 0;
      expRates.forEach((rate, i) => {
        const expense = (vamt * rate) / 100;
        updatedItems[index][expFields[i]] = expense.toFixed(2);
        totalExpenses += expense;
      });
      // Update the exp_before field with the total of all expenses
      updatedItems[index].exp_before = totalExpenses.toFixed(2);
    
      const gst = parseFloat(updatedItems[index].gst);
      const totalAccordingWeight = parseFloat(updatedItems[index].weight) * parseFloat(updatedItems[index].rate);
      const totalAccordingPkgs = parseFloat(updatedItems[index].pkgs) * parseFloat(updatedItems[index].rate);
      let RateCal = updatedItems[index].RateCal;
      let TotalAcc = totalAccordingWeight; // Set a default value
      
      if (RateCal === "Default" || RateCal === "" || RateCal === null || RateCal === undefined) {
        TotalAcc = totalAccordingWeight;
      } else if (RateCal === "Wt/Qty") {
        TotalAcc = totalAccordingWeight;
      } else if (RateCal === "Pc/Pkgs") {
        TotalAcc = totalAccordingPkgs;
      }

    const others = parseFloat(updatedItems[index].exp_before) || 0;
    let disc = parseFloat(updatedItems[index].disc) || 0;
    let per = ((disc / 100) * TotalAcc).toFixed(2);
    let Amounts = TotalAcc + others - per;
      
      // Ensure TotalAcc is a valid number before calling toFixed()
      TotalAcc = isNaN(TotalAcc) ? 0 : TotalAcc;
      const gstNumber = "03";
      const same = custGst.substring(0, 2);
    
      let cgst = 0, sgst = 0, igst = 0;
      if (gstNumber === same) {
     cgst = (Amounts * (gst / 2)) / 100;
      sgst = (Amounts * (gst / 2)) / 100;
      } else {
        igst = (Amounts * gst) / 100;
      }
  
      const totalWithGST = Amounts + cgst + sgst + igst;
    
      // Update tax and total fields
      updatedItems[index]["ctax"] = cgst.toFixed(2);
      updatedItems[index]["stax"] = sgst.toFixed(2);
      updatedItems[index]["itax"] = igst.toFixed(2);
      updatedItems[index]["discount"] = parseFloat(per).toFixed(2);
      updatedItems[index]["vamt"] = totalWithGST.toFixed(2);  // ✅ Update the total amount (vamt)
    
      setItems(updatedItems);
      calculateTotalGst(); // ✅ Recalculate the grand total
    };
    useEffect(() => {
      if (currentIndex !== null && items[currentIndex]) {
        const updatedItems = [...items];
        const item = { ...updatedItems[currentIndex] };
    
        const vamt = parseFloat(item.amount) || 0;
        const pkgs = parseFloat(item.pkgs) || 0;
        const weight = parseFloat(item.weight) || 0;
        // Expense Calculations (Separate Logic for Each Expense)
        let Exp1 = 0, Exp2 = 0, Exp3 = 0, Exp4 = 0, Exp5 = 0;
        const Exp1Multiplier = Pos === "-Ve" ? -1 : 1;
        const Exp1Multiplier2 = Pos2 === "-Ve" ? -1 : 1;
        const Exp1Multiplier3 = Pos3 === "-Ve" ? -1 : 1;
        const Exp1Multiplier4 = Pos4 === "-Ve" ? -1 : 1;
        const Exp1Multiplier5 = Pos5 === "-Ve" ? -1 : 1;
        if (item.Exp_rate1) {
          if(CalExp1 === 'W' || CalExp1 === 'w'){
            Exp1 = (weight * parseFloat(item.Exp_rate1)) / 100;
          }
          else if(CalExp1 === 'P' || CalExp1 === 'p'){
            Exp1 = (pkgs * parseFloat(item.Exp_rate1)) / 100;
          }
          else if(CalExp1 === 'V' || CalExp1 === 'v' || CalExp1 === ''){
            Exp1 = (vamt * parseFloat(item.Exp_rate1)) / 100;
          }
          Exp1 *= Exp1Multiplier; // Apply negative only for Exp if Pos is "-Ve"
          item.Exp1 = Exp1.toFixed(2);
        } else {
          item.Exp1 = "0.00";
        }
    
        if (item.Exp_rate2) {
           if(CalExp2 === 'W' || CalExp2 === 'w'){
            Exp2 = (weight * parseFloat(item.Exp_rate2)) / 100;
          }
          else if(CalExp2 === 'P' || CalExp2 === 'p'){
            Exp2 = (pkgs * parseFloat(item.Exp_rate2)) / 100;
          }
          else if(CalExp2 === 'V' || CalExp2 === 'v' || CalExp2 === ''){
            Exp2 = (vamt * parseFloat(item.Exp_rate2)) / 100;
          }
          Exp2 *= Exp1Multiplier2; // Apply negative only for Exp if Pos is "-Ve"
          item.Exp2 = Exp2.toFixed(2);
        } else {
          item.Exp2 = "0.00";
        }
    
        if (item.Exp_rate3) {
          if(CalExp3 === 'W' || CalExp3 === 'w'){
            Exp3 = (weight * parseFloat(item.Exp_rate3)) / 100;
          }
          else if(CalExp3 === 'P' || CalExp3 === 'p'){
            Exp3 = (pkgs * parseFloat(item.Exp_rate3)) / 100;
          }
          else if(CalExp3 === 'V' || CalExp3 === 'v' || CalExp3 === ''){
            Exp3 = (vamt * parseFloat(item.Exp_rate3)) / 100;
          }
          Exp3 *= Exp1Multiplier3; // Apply negative only for Exp if Pos is "-Ve"
          item.Exp3 = Exp3.toFixed(2);
        } else {
          item.Exp3 = "0.00";
        }
    
        if (item.Exp_rate4) {
          if(CalExp4 === 'W' || CalExp4 === 'w'){
            Exp4 = (weight * parseFloat(item.Exp_rate4)) / 100;
          }
          else if(CalExp4 === 'P' || CalExp4 === 'p'){
            Exp4 = (pkgs * parseFloat(item.Exp_rate4)) / 100;
          }
          else if(CalExp4 === 'V' || CalExp4 === 'v' || CalExp4 === ''){
            Exp4 = (vamt * parseFloat(item.Exp_rate4)) / 100;
          }
          Exp4 *= Exp1Multiplier4; // Apply negative only for Exp if Pos is "-Ve"
          item.Exp4 = Exp4.toFixed(2);
        } else {
          item.Exp4 = "0.00";
        }
    
        if (item.Exp_rate5) {
          if(CalExp5 === 'W' || CalExp5 === 'w'){
            Exp5 = (weight * parseFloat(item.Exp_rate5)) / 100;
          }
          else if(CalExp5 === 'P' || CalExp5 === 'p'){
            Exp5 = (pkgs * parseFloat(item.Exp_rate5)) / 100;
          }
          else if(CalExp5 === 'V' || CalExp5 === 'v' || CalExp5 === ''){
            Exp5 = (vamt * parseFloat(item.Exp_rate5)) / 100;
          }
          Exp5 *= Exp1Multiplier5; // Apply negative only for Exp if Pos is "-Ve"
          item.Exp5 = Exp5.toFixed(2);
        } else {
          item.Exp5 = "0.00";
        }
    
        // Total Expense Before GST
        const totalExpenses = Exp1 + Exp2 + Exp3 + Exp4 + Exp5;
        item.exp_before = totalExpenses.toFixed(2);
    
        // GST & Total Calculations
        const gst = parseFloat(item.gst) || 0;
        const totalAccordingWeight = (parseFloat(item.weight) || 0) * (parseFloat(item.rate) || 0);
        const totalAccordingPkgs = (parseFloat(item.pkgs) || 0) * (parseFloat(item.rate) || 0);
        let RateCal = item.RateCal;
        let TotalAcc = RateCal === "Pc/Pkgs" ? totalAccordingPkgs : totalAccordingWeight;

        let disc = parseFloat(item.disc) || 0;
        let per = ((disc / 100) * TotalAcc).toFixed(2);
        let Amounts = TotalAcc + totalExpenses - per;

        TotalAcc = isNaN(TotalAcc) ? 0 : TotalAcc;
 
        // GST Logic Based on State
        const gstNumber = "03";
        const same = custGst.substring(0, 2);
        let cgst = 0, sgst = 0, igst = 0;
  
        if (gstNumber === same) {
          cgst = (Amounts * (gst / 2)) / 100;
          sgst = (Amounts * (gst / 2)) / 100;
        } else {
          igst = (Amounts * gst) / 100;
        }

      // Final Total Calculation
      const totalWithGST = Amounts + cgst + sgst + igst;
      if (T12) {
        item.ctax = Math.round(cgst).toFixed(2);
        item.stax = Math.round(sgst).toFixed(2);
        item.itax = Math.round(igst).toFixed(2);
        item.discount = Math.round(per).toFixed(2)
        item.vamt = Math.round(totalWithGST).toFixed(2);
      } else {
        item.ctax = cgst.toFixed(2);
        item.stax = sgst.toFixed(2);
        item.itax = igst.toFixed(2);
        item.discount = parseFloat(per).toFixed(2);
        item.vamt = totalWithGST.toFixed(2);
      }
      
      updatedItems[currentIndex] = item;
      setItems(updatedItems);
      calculateTotalGst();
      }
    }, [
      currentIndex,
      items[currentIndex]?.amount,
      items[currentIndex]?.Exp_rate1,
      items[currentIndex]?.Exp_rate2,
      items[currentIndex]?.Exp_rate3,
      items[currentIndex]?.Exp_rate4,
      items[currentIndex]?.Exp_rate5,
      items[currentIndex]?.gst,
      items[currentIndex]?.weight,
      items[currentIndex]?.rate,
      items[currentIndex]?.pkgs,
      items[currentIndex]?.RateCal,
    ]);

    const handleOpenModalBack = (event, index, field) => {
      if (event.key === "Backspace" && field === "accountname") {
          setSelectedItemIndexCus(index);
          setShowModalCus(true);
          event.preventDefault();
      }
    if (event.key === "Backspace" && field === "vcode") {
      setSelectedItemIndex(index);
      setShowModal(true);
      event.preventDefault();
  }
  };

  const handleGross = (e) => {
    const { id, value, type, checked } = e.target;
    const val = type === "checkbox" ? checked : value; // Handle checkbox differently
    setFormData({ ...formData, [id]: val });
  };

  const [isModalOpen, setIsModalOpen] = useState(false);
  const openModal = () => {
      //console.log("Modal opened");
      setIsModalOpen(true);
  };
  const closeModal = () => {
      setIsModalOpen(false);
  };
  const [isModalOpenExp, setIsModalOpenExp] = useState(false);
  const handleKeyDownExp = (e) => {
    if (e.key === "F2") {
      setIsModalOpenExp(true);
    }
  };
  const closeModalExp = () => {
    setIsModalOpenExp(false);
  };
  const [isModalOpenAfter, setIsModalOpenAfter] = useState(false);
  const handleKeyDownAfter = (e) => {
    if (e.key === "ArrowDown") {
      setIsModalOpenAfter(true);
    }
  };
  const closeModalAfter = () => {
    setIsModalOpenAfter(false);
    saveButtonRef.current.focus();
  };

  const handleDoubleClickAfter = (fieldName, index) => {
    if (fieldName === "expafterGST" && isEditMode) {
      setIsModalOpenAfter(true);
      // Open another modal if needed
    } else if (fieldName === "exp_before" && isEditMode) {
      setCurrentIndex(index); // Set the current index
      setIsModalOpenExp(true); // Open the modal
    }
  };
  const handleExpAfterGst = (event) => {
    const { id, value } = event.target;
    const subTotal = parseFloat(formData.sub_total) || 0;

    // Initialize newFormData and expenses
    let newFormData = { ...formData, [id]: value };
    let expense = 0;

    // Check if the value is empty; if so, set corresponding Exp value to 0
    if (value === "") {
      newFormData[id] = 0; // Ensure Exp_rate is set to 0
    } else {
      const expRate = parseFloat(value) || 0;

      // Calculate percentage for Exp_rate7 to Exp_rate12
      switch (id) {
        case 'Exp_rate7':
          newFormData.Exp7 = ((subTotal * expRate) / 100).toFixed(2);
          break;
        case 'Exp_rate8':
          newFormData.Exp8 = ((subTotal * expRate) / 100).toFixed(2);
          break;
        case 'Exp_rate9':
          newFormData.Exp9 = ((subTotal * expRate) / 100).toFixed(2);
          break;
        case 'Exp_rate10':
          newFormData.Exp10 = ((subTotal * expRate) / 100).toFixed(2);
          break;
        case 'Exp_rate11':
          newFormData.Exp11 = ((subTotal * expRate) / 100).toFixed(2);
          break;
        case 'Exp_rate12':
          newFormData.Exp12 = ((subTotal * expRate) / 100).toFixed(2);
          break;
        default:
          break;
      }
    }

    // Calculate total of Exp7 to Exp12 and update expafterGST
    const totalExpenses = 
      parseFloat(newFormData.Exp7 || 0) +
      parseFloat(newFormData.Exp8 || 0) +
      parseFloat(newFormData.Exp9 || 0) +
      parseFloat(newFormData.Exp10 || 0) +
      parseFloat(newFormData.Exp11 || 0) +
      parseFloat(newFormData.Exp12 || 0);
    
    newFormData.expafterGST = totalExpenses.toFixed(2);

    setFormData(newFormData);
  };
  
 // Update the blur handlers so that they always format the value to 2 decimals.
 const handlePkgsBlur = (index) => {
  const decimalPlaces = pkgsValue
  const updatedItems = [...items];
  let value = parseFloat(updatedItems[index].pkgs);
  if (isNaN(value)) {
    value = 0;
  }
  updatedItems[index].pkgs = value.toFixed(decimalPlaces);
  setItems(updatedItems);
};

 const handleWeightBlur = (index) => {
    const decimalPlaces = weightValue;
    const updatedItems = [...items];
    let value = parseFloat(updatedItems[index].weight);
    if (isNaN(value)) {
      value = 0;
    }
    // Validation: Check if weight is null, NaN, or <= 0
    // if (isNaN(value) || value <= 0) {
    //   // Custom Confirmation Toast
    //   toast.info(
    //     ({ closeToast }) => (
    //       <div>
    //          <p style={{fontSize:20,color:'black'}}>⚠️ Quantity is invalid. It Should be Greater than 0 </p>
    //         <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px'}}>
    //           <button
    //             onClick={() => {
    //               closeToast(); // Close the toast
    //               // Focus back on the invalid input
    //               const weightInput = document.querySelectorAll('.QTY')[index];
    //               if (weightInput) {
    //                 weightInput.focus();
    //               }
    //             }}
    //             style={{width:100,backgroundColor: '#2ecc71',color: 'white',border: 'none',padding: '5px 10px',borderRadius: '5px',cursor: 'pointer'}}
    //           >
    //             OK
    //           </button>
    //         </div>
    //       </div>
    //     ),
    //     {
    //       position: 'top-center',
    //       autoClose: false,
    //       closeOnClick: false,
    //       closeButton: false,
    //       draggable: false,
    //       style: {
    //         width: '400px',
    //         border:'1px solid black',
    //         textAlign: 'center',
    //         borderRadius: '12px',
    //         boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
    //         marginTop:150,
    //       },
    //     }
    //   );
    //   return;
    // }
    updatedItems[index].weight = value.toFixed(decimalPlaces) || 0 ;
    setItems(updatedItems);
  };

const handleRateBlur = (index) => {
  const decimalPlaces = rateValue;
  const updatedItems = [...items];
  let value = parseFloat(updatedItems[index].rate);
  if (isNaN(value)) {
    value = 0;
  }
  updatedItems[index].rate = value.toFixed(decimalPlaces);
  setItems(updatedItems);
};;
  return (
    <div>
      <div>
        <ToastContainer />
      </div>
      <div className="Plusminus">
      <text className="tittles">{title}</text>
      <Button  onClick={openModal}>SETUP</Button>
      {isModalOpen && <PurchaseSetup onClose={closeModal} />}
      <select
        className="colorselectz"
        value={color}
        onChange={handleChange}
      >
        {gradientOptions.map((option, index) => (
          <option key={index} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
        <Button className="plusbutton" onClick={decreaseFontSize}>
          <FaMinus />
        </Button>
        <Button style={{ marginLeft: 10 }} onClick={increaseFontSize}>
          <FaPlus />
        </Button>
      </div>
      <div style={{ visibility: "hidden", width: 0, height: 0 }}>
      {SelectedInvoiceComponent && (
          <SelectedInvoiceComponent
            formData={formData}
            items={items}
            supplierdetails={supplierdetails}
            isOpen={open}
            handleClose={handleCloseInvoice}
            GSTIN={GSTIN}
            PAN={PAN}
            shopName={shopName}
            description={description}
            address={address}
          />
        )}
      {/* <InvoicePDFPur
      formData={formData}
      items={items}
      supplierdetails={supplierdetails}
      // shipped={shipped}
      isOpen={open}
      handleClose={handleClose}
      GSTIN={GSTIN}
      PAN={PAN}
      shopName={shopName}
      description={description}
      address={address}
    /> */}
      </div>
      <h1 className="headers">PURCHASE RETURN</h1>
      <div className="toppart">
        <div className="topz" style={{ padding: 5, background: color  }}>
          <div style={{ display: "flex", flexDirection: "column" }}>
            <div style={{ display: "flex", flexDirection: "row" }}>
              <text>Date:</text>
              <div className="Date" style={{ height: 10 }}>
              <DatePicker
        ref={datePickerRef}
        className="custom-datepickerr"
        id="date"
        // If selectedDate is null, nothing is "selected" in the calendar
        selected={selectedDate || null}
        // This ensures that if there's no selected date, 
        // the calendar will open focused on today's date:
        openToDate={new Date()}
        onCalendarClose={handleCalendarClose}
        dateFormat="dd-MM-yyyy"
        onChange={handleDateChange}
      />
                {/* <DatePicker
                  ref={datePickerRef}
                  className="custom-datepickerr"
                  id="date"
                  selected={selectedDate}
                  dateFormat="dd-MM-yyyy"
                  onChange={(date) => {
                    if (date instanceof Date && !isNaN(date)) {
                      // Only set the date if it's a valid Date object
                      setSelectedDate(date);
                    } else {
                      console.error("Invalid date value");
                    }
                  }}
                /> */}
              </div>
              <div
                className="voucherdiv"
                style={{ display: "flex", flexDirection: "row", }}
              >
                <text>VNo:</text>
                <input
                  className="vnoz"
                  style={{
                    height: "30px",
                    width: 80,
                    fontSize: `${fontSize}px`,
                  }}
                  id="vno"
                  value={formData.vno}
                  readOnly={!isEditMode || isDisabled}
                  placeholder="VNo."
                  // onChange={handleNumberChange}
                />
              </div>
            </div>
            <div style={{ marginTop: 10 }}>
              {supplierdetails.map((item, index) => (
                <div key={item.vacode}>
                  <div className="cus">
                    <div>
                      <text>Supplier:</text>
                      <input
                        ref={customerNameRef}
                        type="text"
                        className="supplierss"
                        style={{ height: "30px", fontSize: `${fontSize}px` }}
                        placeholder="Supplier Name"
                        value={item.vacode}
                        // onClick={() => openModalForItemCus(index)}
                        onKeyDown={(e) => {
                          handleEnterKeyPress(customerNameRef, grNoRef)(e);
                          handleKeyDown(e, index, "accountname");
                          handleOpenModalBack(e, index, "accountname");
                        }}
                      />
                    </div>
                    <div className="citydivZ">
                      <text>City:</text>
                      <input
                        className="Cityz"
                        value={item.city}
                        style={{ height: "30px", fontSize: `${fontSize}px` }}
                        placeholder="Enter City"
                        readOnly={!isEditMode || isDisabled}
                        onChange={(e) =>
                          handleItemChangeCus(index, "city", e.target.value)
                        }
                      />
                    </div>
                  </div>
                  <div className="gst">
                    <div>
                      <text>GST No:</text>
                      <input
                        className="Gstnos"
                        value={item.gstno}
                        style={{ height: "30px", fontSize: `${fontSize}px` }}
                        placeholder="GST No"
                        readOnly={!isEditMode || isDisabled}
                        onChange={(e) =>
                          handleItemChangeCus(index,"gstNumber",e.target.value)
                        }
                      />
                    </div>
                    <div className="pandivz">
                      <text>PAN:</text>
                      <input
                        className="Panz"
                        style={{ height: "30px", fontSize: `${fontSize}px` }}
                        value={item.pan}
                        placeholder="PanNo"
                        readOnly={!isEditMode || isDisabled}
                        onChange={(e) =>
                          handleItemChangeCus(index, "PanNo", e.target.value)
                        }
                      />
                    </div>
                  </div>
                </div>
              ))}
              {showModalCus && (
              <ProductModalCustomer
                allFields={allFieldsCus}
                products={productsCus}
                onSelect={handleProductSelectCus}
                onClose={() => setShowModalCus(false)}
                initialKey={pressedKey}
              />
              )}
            </div>
          </div>
        </div>
        <div className="topz" style={{ padding: 5, background: color  }}>
          <div
            className="Billdiv"
            style={{ display: "flex", flexDirection: "column" }}
          >
            <div>
              <text>BillNo:</text>
              <input
                ref={grNoRef}
                className="vbillnoz"
                style={{ height: "30px", fontSize: `${fontSize}px` }}
                id="vbillno"
                value={formData.vbillno}
                readOnly={!isEditMode || isDisabled}
                placeholder="Billno"
                onChange={handleNumberChange}
                onKeyDown={handleEnterKeyPress(grNoRef, termsRef)}
              />
            </div>
            <div
              className="datediv"
              style={{ display: "flex", flexDirection: "row" }}
            >
              <text>Date:</text>
              <div className="dbdate" style={{ height: 10 }}>
                <DatePicker
                  className="custom-datepickerr"
                  id="date"
                  selected={selectedDate}
                  onChange={(date) => setSelectedDate(date)}
                  dateFormat="dd-MM-yyyy"
                />
              </div>
            </div>
            <div>
              <text>Terms:</text>
              <input
                ref={termsRef}
                className="Termsz"
                style={{ height: "30px", fontSize: `${fontSize}px` }}
                id="exfor"
                placeholder="Terms"
                readOnly={!isEditMode || isDisabled}
                value={formData.exfor}
                onChange={HandleInputsChanges}
                // onKeyDown={handleInputKeyDown}
                onKeyDown={handleEnterKeyPress(termsRef, null)}
              />
            </div>
          </div>
          <div
            className="selectors"
            style={{ display: "flex", flexDirection: "column" }}
          >
            <div
              className="taxdiv"
              style={{ display: "flex", flexDirection: "row" }}
            >
              <text>Taxtype:</text>
              <select
                className="Taxtype"
                id="taxtype"
                style={{
                  height: "30px",
                  backgroundColor: "white",
                  fontSize: `${fontSize}px`,
                  color: "black",
                }}
                value={formData.stype}
                onChange={handleTaxType}
                disabled={!isEditMode || isDisabled}
              >
                <option value="">Tax-Type</option>
                <option value="Vat Sale">Vat Sale</option>
                <option value="Out of State">Out of State</option>
                <option value="Retails Within State">
                  Retails Within State
                </option>
                <option value="Exempted Sale">Exempted Sale</option>
                <option value="Tax Free Within Sale">
                  Tax Free Within Sale
                </option>
                <option value="Export Sale">Export Sale</option>
                <option value="H Form Within State">H Form Within State</option>
                <option value="H Form Outside State">
                  H Form Outside State
                </option>
                <option value="E1/E2 Sale">E1/E2 Sale</option>
                <option value="Including Tax">Including Tax</option>
                <option value="Consigment">Consigment</option>
                <option value="Not Applicable">Not Applicable</option>
                <option value="Tax Free Interstate">Tax Free Interstate</option>
              </select>
            </div>
            <div style={{ marginTop: 5 }}>
              <text>Self Inv.#:</text>
              <input
                ref={vehicleNoRef}
                className="Selfinv"
                style={{ height: "30px", fontSize: `${fontSize}px` }}
                id="p_entry"
                placeholder="Self Inv"
                readOnly={!isEditMode || isDisabled}
                value={formData.p_entry}
                onChange={HandleInputsChanges}
                onKeyDown={handleEnterKeyPress(vehicleNoRef, null)}
              />
            </div>
            <div
              style={{ display: "flex", flexDirection: "row", marginTop: 5 }}
            >
              <text>BillCash:</text>
              <select
                className="Billcash"
                id="billcash"
                style={{
                  height: "30px",
                  backgroundColor: "white",
                  fontSize: `${fontSize}px`,
                  color: "black",
                }}
                value={formData.btype}
                onChange={handleBillCash}
                disabled={!isEditMode || isDisabled}
              >
                <option value="">Bill Cash</option>
                <option value="Bill">Bill</option>
                <option value="Cash Memo">Cash Memo</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      {/* Table content */}
        <div className="tablestyle">
          <Table ref={tableRef} className="custom-table">
            <thead
              style={{
                background: color ,
                textAlign: "center",
                position: "sticky",
                top: 0,
              }}
            >
              <tr style={{ color: "#575a5a" }}>
                <th>ITEMCODE</th>
                <th>DESCRIPTION</th>
                <th>HSNCODE</th>
                <th>PCS</th>
                <th>QTY</th>
                <th>RATE</th>
                <th>AMOUNT</th>
                <th>Dis@</th>
                <th>Discount</th>
                {/* <th>GST</th> */}
                <th>Others</th>
                <th>CGST</th>
                <th>SGST</th>
                <th>IGST</th>
                <th>TOTAL</th>
                <th className="text-center">ACTION</th>
              </tr>
            </thead>
            <tbody
              style={{ overflowY: "auto", maxHeight: "calc(320px - 40px)" }}
            >
              {items.map((item, index) => (
                <tr key={item.id}>
                  <td style={{ padding: 0, width: 30 }}>
                    <input
                    className="ItemCode"
                      style={{
                        height: 40,
                        fontSize: `${fontSize}px`,
                        width: "100%",
                        boxSizing: "border-box",
                        border: "none",
                        padding: 5,
                      }}
                      type="text"
                      value={item.vcode}
                      readOnly
                      // onClick={() => openModalForItem(index)}
                      onKeyDown={(e) => {
                        handleKeyDown(e, index, "vcode");
                        handleOpenModal(e, index, "vcode");
                        handleOpenModalBack(e, index, "vcode");
                      }}
                      ref={(el) => (itemCodeRefs.current[index] = el)} 
                      onFocus={(e) => e.target.select()}  // Select text on focus
                    />
                  </td>
                  <td style={{ padding: 0, width: 300 }}>
                    <input
                    className="desc"
                      style={{
                        height: 40,
                        fontSize: `${fontSize}px`,
                        width: "100%",
                        boxSizing: "border-box",
                        border: "none",
                        padding: 5,
                      }}
                      value={item.sdisc}
                      readOnly={!isEditMode || isDisabled}
                      onChange={(e) =>
                        handleItemChange(index, "sdisc", e.target.value)
                      }
                      onKeyDown={(e) => {
                        handleKeyDown(e, index, "sdisc");
                      }}
                      ref={(el) => (desciptionRefs.current[index] = el)}
                      onFocus={(e) => e.target.select()}  // Select text on focus
                    />
                  </td>
                  <td style={{ padding: 0 }}>
                    <input
                    className="Hsn"
                      style={{
                        height: 40,
                        fontSize: `${fontSize}px`,
                        width: "100%",
                        boxSizing: "border-box",
                        border: "none",
                        padding: 5,
                        textAlign: "right",
                      }}
                      readOnly={!isEditMode || isDisabled}
                      value={item.tariff}
                      onChange={(e) =>
                        handleItemChange(index, "tariff", e.target.value)
                      }
                      onKeyDown={(e) => {
                        handleKeyDown(e, index, "tariff");
                      }}
                      ref={(el) => (hsnCodeRefs.current[index] = el)}
                      onFocus={(e) => e.target.select()}  // Select text on focus
                    />
                  </td>
                  <td style={{ padding: 0 }}>
  <input
    className="PCS"
    style={{
      height: 40,
      width: "100%",
      boxSizing: "border-box",
      border: "none",
      padding: 5,
      textAlign: "right",
    }}
    maxLength={48}
    readOnly={!isEditMode || isDisabled}
    value={item.pkgs} // Show raw value during input
    onChange={(e) => handleItemChange(index, "pkgs", e.target.value)}
    onBlur={() => handlePkgsBlur(index)} // Format value on blur
    onKeyDown={(e) => {handleKeyDown(e, index, "pkgs");}}
    ref={(el) => (peciesRefs.current[index] = el)}
    onFocus={(e) => e.target.select()}  // Select text on focus
  />
</td>
<td style={{ padding: 0 }}>
  <input
    className="QTY"
    style={{
      height: 40,
      width: "100%",
      boxSizing: "border-box",
      border: "none",
      padding: 5,
      textAlign: "right",
    }}
    maxLength={48}
    readOnly={!isEditMode || isDisabled}
    value={item.weight} // Show raw value during input
    onChange={(e) => handleItemChange(index, "weight", e.target.value)}
    onBlur={() => handleWeightBlur(index)} // Format value on blur
    onKeyDown={(e) => {
      handleKeyDown(e, index, "weight");
    }}
    ref={(el) => (quantityRefs.current[index] = el)}
    onFocus={(e) => e.target.select()}  // Select text on focus
  />
</td>
<td style={{ padding: 0 }}>
  <input
    className="Price"
    style={{
      height: 40,
      width: "100%",
      boxSizing: "border-box",
      border: "none",
      padding: 5,
      textAlign: "right",
    }}
    maxLength={48}
    readOnly={!isEditMode || isDisabled}
    value={item.rate} // Show raw value during input
    onChange={(e) => handleItemChange(index, "rate", e.target.value)}
    onBlur={() => handleRateBlur(index)} // Format value on blur
    onKeyDown={(e) => {handleKeyDown(e, index, "rate");}}
    ref={(el) => (priceRefs.current[index] = el)}
    onFocus={(e) => e.target.select()}  // Select text on focus
  />
</td>
                  <td style={{ padding: 0 }}>
                    <input
                    className="Amount"
                      style={{
                        height: 40,
                        fontSize: `${fontSize}px`,
                        width: "100%",
                        boxSizing: "border-box",
                        border: "none",
                        padding: 5,
                        textAlign: "right",
                      }}
                      type="number"
                      readOnly={!isEditMode || isDisabled}
                      value={item.amount}
                      onKeyDown={(e) => {
                        handleKeyDown(e, index, "amount");
                      }}
                      ref={(el) => (amountRefs.current[index] = el)}
                      min="0"
                      onFocus={(e) => e.target.select()}  // Select text on focus
                    />
                  </td>
                  <td style={{padding:0}}>
                    <input
                    className="Disc"
                     style={{
                        height: 40,
                        fontSize: `${fontSize}px`,
                        width: "100%",
                        boxSizing: "border-box",
                        border: "none",
                        padding: 5,
                        textAlign: "right",
                      }}
                      value={item.disc}
                      onChange={(e) =>handleItemChange(index, "disc", e.target.value)}
                      onKeyDown={(e) => {handleKeyDown(e, index, "disc")}}
                      ref={(el) => (discountRef.current[index] = el)}
                      onFocus={(e) => e.target.select()}  // Select text on focus
                    />
                  </td>
                  <td style={{padding:0}}>
                    <input
                    className="discount"
                     style={{
                        height: 40,
                        fontSize: `${fontSize}px`,
                        width: "100%",
                        boxSizing: "border-box",
                        border: "none",
                        padding: 5,
                        textAlign: "right",
                      }}
                      value={item.discount}
                      onChange={(e) =>handleItemChange(index, "discount", e.target.value)}
                      onFocus={(e) => e.target.select()}  // Select text on focus
                    />
                  </td>
                  {/* <td>
                                        <input
                                            style={{ width: 56, height: 30, fontSize: `${fontSize}px` }}
                                            className="inputfields"
                                            readOnly={!isEditMode || isDisabled}
                                            value={item.gst}
                                            onKeyDown={(e) => {
                                                handleKeyDown(e, index, 'gst')
                                            }}
                                            ref={el => gstRefs.current[index] = el}
                                            min="0"
                                        />
                                    </td> */}
                  <td style={{ padding: 0 }}>
                    <input
                    className="Others"
                      style={{
                        height: 40,
                        fontSize: `${fontSize}px`,
                        width: "100%",
                        boxSizing: "border-box",
                        border: "none",
                        padding: 5,
                        textAlign: "right",
                      }}
                      type="text"
                      value={item.exp_before}
                      readOnly={!isEditMode || isDisabled}
                      onDoubleClick={() => handleDoubleClickAfter("exp_before", index)} // Pass index here
                      // onChange={(e) =>handleItemChange(index, "exp_before", e.target.value)}
                      onKeyDown={(e) => {
                        handleKeyDown(e, index, "exp_before");
                        handleKeyDownExp(e);
                      }}
                      onFocus={(e) => {
                        e.target.select()
                        if (WindowBefore) {
                          setCurrentIndex(index);
                          setIsModalOpenExp(true);
                        }
                      }}
                      ref={(el) => (othersRefs.current[index] = el)}
                    />
                  </td>
                  {isModalOpenExp && currentIndex !== null && (
  <div className="Modal">
    <div className="Modal-content">
      <h1 className="headingE">ADD/LESS BEFORE GST</h1>
      <div className="form-group">
        <input
          type="checkbox"
          id="gross"
          checked={items[currentIndex]?.gross || false}
          onChange={(e) =>
            handleInputChange(currentIndex, "gross", e.target.checked)
          }
        />
        <label style={{ marginLeft: 5 }} className="label" htmlFor="Gross">
          GROSS
        </label>
      </div>
      {[
  { label: Expense1, rate: "Exp_rate1", value: "Exp1" },
  { label: Expense2, rate: "Exp_rate2", value: "Exp2" },
  { label: Expense3, rate: "Exp_rate3", value: "Exp3" },
  { label: Expense4, rate: "Exp_rate4", value: "Exp4" },
  { label: Expense5, rate: "Exp_rate5", value: "Exp5" },
].map((field, idx) => (
  <div key={idx} style={{
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "10px",       // Spacing between items
    marginBottom: "10px", // Space between rows
  }}>
    <label style={{ width: "100px", fontWeight: "bold" }}>{field.label}</label>
    
    <input
      value={items[currentIndex][field.rate]}
      style={{
        border: "1px solid black",
        padding: "5px",
        width: "120px",
        textAlign: "right",
        borderRadius: "4px",
      }}
      onChange={(e) =>
        handleInputChange(currentIndex, field.rate, e.target.value)
      }
    />

    <input
      value={items[currentIndex][field.value]}
      style={{
        border: "1px solid black",
        padding: "5px",
        width: "120px",
        textAlign: "right",
        borderRadius: "4px",
      }}
      onChange={(e) =>
        handleInputChange(currentIndex, field.value, e.target.value)
      }
    />
  </div>
))}
      <Button
        onClick={() => {
          setIsModalOpenExp(false);
          setCurrentIndex(null); // Reset the index when closing the modal
          transportRef.current.focus();
        }}
        style={{
          borderColor: "transparent",
          backgroundColor: "red",
          marginTop: 10,
        }}
      >
        CLOSE
      </Button>
    </div>
  </div>
)}
                  <td style={{ padding: 0 }}>
                    <input
                    className="CTax"
                      style={{
                        height: 40,
                        fontSize: `${fontSize}px`,
                        width: "100%",
                        boxSizing: "border-box",
                        border: "none",
                        padding: 5,
                        textAlign: "right",
                      }}
                      readOnly={!isEditMode || isDisabled}
                      value={item.ctax}
                      onChange={(e) =>
                        handleItemChange(index, "ctax", e.target.value)
                      }
                      onKeyDown={(e) => {
                        handleKeyDown(e, index, "ctax");
                      }}
                      ref={(el) => (cgstRefs.current[index] = el)}
                    />
                  </td>
                  <td style={{ padding: 0 }}>
                    <input
                     className="STax"
                      style={{
                        height: 40,
                        fontSize: `${fontSize}px`,
                        width: "100%",
                        boxSizing: "border-box",
                        border: "none",
                        padding: 5,
                        textAlign: "right",
                      }}
                      readOnly={!isEditMode || isDisabled}
                      value={item.stax}
                      onChange={(e) =>
                        handleItemChange(index, "stax", e.target.value)
                      }
                      onKeyDown={(e) => {
                        handleKeyDown(e, index, "stax");
                      }}
                      ref={(el) => (sgstRefs.current[index] = el)}
                      min="0"
                    />
                  </td>
                  <td style={{ padding: 0 }}>
                    <input
                     className="ITax"
                      style={{
                        height: 40,
                        fontSize: `${fontSize}px`,
                        width: "100%",
                        boxSizing: "border-box",
                        border: "none",
                        padding: 5,
                        textAlign: "right",
                      }}
                      readOnly={!isEditMode || isDisabled}
                      value={item.itax}
                      onChange={(e) =>
                        handleItemChange(index, "itax", e.target.value)
                      }
                      onKeyDown={(e) => {
                        handleKeyDown(e, index, "itax");
                      }}
                      ref={(el) => (igstRefs.current[index] = el)}
                      min="0"
                    />
                  </td>
                  <td style={{ padding: 0 }}>
                    <input
                    className="TotalTable"
                      style={{
                        fontSize: `${fontSize}px`,
                      }}
                      readOnly
                      value={item.vamt}
                    />
                  </td>
                  <td style={{ padding: 0 }} className="text-center">
                    <BiTrash onClick={() => handleDeleteItem(index)} style={{ cursor: 'pointer' }} />
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
        {showModal && (
          <ProductModal
            allFields={allFields}
            products={products}
            onSelect={handleProductSelect}
            onClose={() => setShowModal(false)}
            initialKey={pressedKey} // Pass the pressed key to the modal
          />
        )}
     
      <div className="Belowcontents" style={{padding:5}}>
        <div className="Bottomcontainer" style={{ background: color  ,padding:5}}>
            <div className="Bottomdivs" style={{marginLeft:5}}>
              <div style={{ marginTop: 5 }}>
                <text>2BStatus:</text>
                <input
                  ref={twoBRef}
                  className="vacodez"
                  style={{ height: 30, fontSize: `${fontSize}px`,backgroundColor:"white"}}
                  id="vacode1"
                  disabled
                  value={formData.vacode1}
                  onChange={HandleInputsChanges}
                  onKeyDown={(e) => {
                    handleKeyDowndown(e, transportRef);
                  }}
                />
              </div>
              <div style={{ marginTop: 5 }}>
                <text>Transport:</text>
                <input
                  ref={transportRef}
                  className="tptz"
                  style={{ height: 30, fontSize: `${fontSize}px`}}
                  id="v_tpt"
                  readOnly={!isEditMode || isDisabled}
                  value={formData.v_tpt}
                  onChange={HandleInputsChanges}
                  onKeyDown={(e) => {
                    handleOpenModalTpt(e, "v_tpt", "v_tpt")
                    handleKeyDowndown(e, brokerRef);
                  }}
                />
              </div>
              <div style={{ marginTop: 5 }}>
                <text>Broker:</text>
                <input
                  ref={brokerRef}
                  className="brokerr"
                  style={{ height: 30, fontSize: `${fontSize}px`}}
                  id="broker"
                  readOnly={!isEditMode || isDisabled}
                  value={formData.broker}
                  onChange={HandleInputsChanges}
                  onKeyDown={(e) => {
                    handleInputKeyDownB(e);
                    handleKeyDowndown(e, tdsRef);
                    handleOpenModalTpt(e, "broker", "broker");
                  }}
                />
              </div>
              <ModalBroker
                openB={openB}
                handleCloseB={handleCloseB}
                usersB={usersB}
                filteredUsersB={filteredUsersB}
                highlightedIndexB={highlightedIndexB}
                setHighlightedIndexB={setHighlightedIndexB}
                handleRowClickB={handleRowClickB}
                handleUserClickB={handleUserClickB}
                handleSaveClickB={handleSaveClickB}
                handleAddClickB={handleAddClickB}
                editedUserB={editedUserB}
                setEditedUserB={setEditedUserB}
                isAddingNewUserB={isAddingNewUserB}
                searchQueryB={searchQueryB}
                handleSearchChangeB={handleSearchChangeB}
                inputRefB={inputRefB}
                tableBodyRefB={tableBodyRefB}
              />
            </div>
            <div className="Bottomdivs" style={{marginLeft:5}}>
            <div style={{ display: "flex", flexDirection: "row" ,marginTop:5}}>
                <text style={{color:'red'}}>TdsOn:</text>
                <select
                  className="tdsonz"
                  id="tdson"
                  style={{
                    height: 30,
                    backgroundColor: "white",
                    borderColor: "black",
                    fontSize: `${fontSize}px`,
                    color: "red",
                    fontWeight:"bold"
                  }}
                  value={formData.tdson}
                  onChange={handleTdsOn}
                  disabled={!isEditMode || isDisabled}
                  aria-label="Without label"
                >
                  <option value="Interest">Interest</option>
                  <option value="Freight">Freight</option>
                  <option value="Brokerage">Brokerage</option>
                  <option value="Commission">Commission</option>
                  <option value="Advertisement">Advertisement</option>
                  <option value="Labour">Labour</option>
                  <option value="Contract">Contract</option>
                  <option value="Job Work">Job Work</option>
                  <option value="Salary">Salary</option>
                  <option value="Rent">Rent</option>
                  <option value="Professional">Professional</option>
                  <option value="Purchase">Purchase</option>
                </select>
              </div>
            <div style={{ display: "flex", flexDirection: "row", marginTop: 5}}>
                <text style={{color:'red'}}>Tds194Q:</text>
                <div style={{ display: "flex", flexDirection: "row" }}>
                  <input
                    ref={tdsRef}
                    className="Tds"
                    style={{ height: 30, width: 60, fontSize: `${fontSize}px`,color:'red' }}
                    readOnly={!isEditMode || isDisabled}
                    id="srv_rate"
                    value={formData.srv_rate}
                    onChange={handleNumberChange}
                    onKeyDown={(e) => {
                      handleKeyDowndown(e, tcsRef);
                    }}
                  />
                  <input
                    className="tdsq2"
                    style={{
                      height: 30,
                      width: 95,
                      marginLeft: 5,
                      marginTop: 2,
                      fontSize: `${fontSize}px`,color:'red'
                    }}
                    readOnly={!isEditMode || isDisabled}
                    id="srv_tax"
                    value={formData.srv_tax}
                    onChange={handleNumberChange}
                  />
                </div>
              </div>      
              <div style={{ display: "flex", flexDirection: "row", marginTop: 5}}>
                <text style={{color:'red'}}>Tcs@:</text>
                <div style={{ display: "flex", flexDirection: "row" }}>
                  <input
                    ref={tcsRef}
                    className="Tcs"
                    style={{ height: 30, width: 60, fontSize: `${fontSize}px`,color:'red' }}
                    id="tcs206_rate"
                    value={formData.tcs206_rate}
                    readOnly={!isEditMode || isDisabled}
                    onChange={handleNumberChange}
                    onKeyDown={(e) => {
                      handleKeyDowndown(e, tdsRef2);
                    }}
                  />
                  <input
                    className="tdsq2"
                    style={{
                      height: 30,
                      width: 95,
                      marginLeft: 5,
                      marginTop: 2,
                      fontSize: `${fontSize}px`,color:'red'
                    }}
                    id="tcs206"
                    value={formData.tcs206}
                    readOnly={!isEditMode || isDisabled}
                    onChange={handleNumberChange}
                  />
                </div>
              </div>
              <div
                style={{display: "flex", flexDirection: "row", marginTop: 5 }}
              >
                <text style={{color:'red'}}>Tcs206c1H:</text>
                <div style={{ display: "flex", flexDirection: "row" }}>
                  <input
                    ref={tdsRef2}
                    className="Tcs206"
                    style={{ height: 30, width: 60, fontSize: `${fontSize}px`,color:'red' }}
                    id="tcs1_rate"
                    value={formData.tcs1_rate}
                    readOnly={!isEditMode || isDisabled}
                    onChange={handleNumberChange}
                    onKeyDown={(e) => {
                      handleKeyDowndown(e, GrRef);
                    }}
                  />
                  <input
                    className="tdsq2"
                    style={{
                      height: 30,
                      width: 95,
                      marginLeft: 5,
                      marginTop: 2,
                      fontSize: `${fontSize}px`,color:'red'
                    }}
                    id="tcs1"
                    value={formData.tcs1}
                    readOnly={!isEditMode || isDisabled}
                    onChange={handleNumberChange}
                  />
                </div>
              </div>
            </div>
            <div style={{display:'flex',flexDirection:'column',marginTop:2,marginLeft:5}}>
            <div style={{display:'flex',flexDirection:'row'}}>
                <text>G.Tds@:</text>
              <input value={"2%"} style={{width:50,fontWeight:'bold',height:30,border:"1px solid black",paddingLeft:5,borderRadius:5}}/>
              </div>
              <div style={{display:'flex',flexDirection:'row'}}>
                <text>C.Tds:</text>
              <input value={formData.Ctds} style={{width:130,fontWeight:'bold',height:30,border:"1px solid black",paddingLeft:5,borderRadius:5}}/>
              </div>
              <div style={{display:'flex',flexDirection:'row',marginTop:2}}>
              <text>S.Tds:</text>
              <input value={formData.Stds} style={{width:130,fontWeight:'bold',height:30,border:"1px solid black",paddingLeft:5,borderRadius:5}}/>
              </div>
              <div style={{display:'flex',flexDirection:'row',marginTop:2}}>
              <text>I.Tds:</text>
              <input value={formData.iTds} style={{width:130,fontWeight:'bold',marginLeft:3,height:30,border:"1px solid black",paddingLeft:5,borderRadius:5}}/>
              </div>
              <div style={{display:'flex',flexDirection:'row',marginTop:2}}>
              <text>Total:</text>
              <input value={formData.Tds2} style={{width:130,fontWeight:'bold',height:30,border:"1px solid black",paddingLeft:5,color:'red',borderRadius:5}}/>
              </div>
          
            </div>
            <div className="Bottomdivs" style={{marginLeft:5}}>
              <div style={{ display: "flex", flexDirection: "row", marginTop: 10 }}>
                <text>DueDate:</text>
                <div className="vdate">
                  <DatePicker
                    id="duedate"
                    value={formData.duedate}
                    className="custom-datepickerr"
                    selected={expiredDate}
                    onChange={handleDateChange}
                    readOnly={!isEditMode || isDisabled}
                    placeholderText="DueDate"
                    dateFormat="dd/MM/yyyy"
                  />
                </div>
              </div>
              <div className="margin">
                <text>GrNo:</text>
                <input
                  ref={GrRef}
                  className="grNos"
                  style={{ height: 30, fontSize: `${fontSize}px` }}
                  id="gr"
                  readOnly={!isEditMode || isDisabled}
                  value={formData.gr}
                  onChange={handleNumberChange}
                  onKeyDown={(e) => {
                    handleKeyDowndown(e, vehicelRef);
                  }}
                />
              </div>
              <div className="margin">
                <text>VehicleNo:</text>
                <input
                  ref={vehicelRef}
                  className="Trpts"
                  style={{ height: 30, fontSize: `${fontSize}px` }}
                  id="trpt"
                  value={formData.trpt}
                  readOnly={!isEditMode || isDisabled}
                  onChange={HandleInputsChanges}
                  onKeyDown={(e) => {
                    handleInputKeyDown(e);
                    handleKeyDowndown(e, saveButtonRef);
                  }}
                />
              </div>
              <ModalVehicle
                open2={open2}
                handleClose2={handleClose2}
                users2={users2}
                filteredUsers={filteredUsers}
                highlightedIndex={highlightedIndex}
                setHighlightedIndex={setHighlightedIndex}
                handleRowClick={handleRowClick}
                handleUserClick={handleUserClick}
                handleSaveClick2={handleSaveClick2}
                handleAddClick={handleAddClick}
                editedUser2={editedUser2}
                setEditedUser2={setEditedUser2}
                isAddingNewUser2={isAddingNewUser2}
                searchQuery={searchQuery}
                handleSearchChange={handleSearchChange}
                inputRef={inputRef}
                tableBodyRef={tableBodyRef}
              />
              <div className="margin">
                <text>TotalGST:</text>
                <input
                  className="Totalgsts"
                  style={{ height: 30, fontSize: `${fontSize}px` }}
                  id="tax"
                  readOnly={!isEditMode || isDisabled}
                  value={formData.tax}
                  // onChange={handleNumberChange}
                />
              </div>
            </div>
            <div className="Bottomdivs" style={{marginLeft:5}}>
              <div>
                <text>Cess1:</text>
                <input
                  className="Cess1"
                  style={{ height: 30, fontSize: `${fontSize}px` }}
                  id="cess1"
                  value={formData.cess1}
                  readOnly={!isEditMode || isDisabled}
                  onChange={handleNumberChange}
                />
              </div>
              <div>
                <text>Cess2:</text>
                <input
                  className="Cess2"
                  style={{ height: 30, fontSize: `${fontSize}px` }}
                  id="cess2"
                  value={formData.cess2}
                  readOnly={!isEditMode || isDisabled}
                  onChange={handleNumberChange}
                />
              </div>
              <div>
                <text>Add/Less:</text>
                <input
                  className="Addless"
                  style={{ height: 30, fontSize: `${fontSize}px` }}
                  id="exp_before"
                  value={formData.exp_before}
                  readOnly={!isEditMode || isDisabled}
                  onChange={handleNumberChange}
                />
              </div>
              <div>
                <text>Expense:</text>
                <input
                  className="Expense"
                  style={{ height: 30, fontSize: `${fontSize}px` }}
                  id="expafterGST"
                  value={formData.expafterGST}
                  readOnly={!isEditMode || isDisabled}
                  // onChange={handleNumberChange}
                  onKeyDown={(e) => {
                    // handleKeyDowndown(e, saveButtonRef);
                    handleKeyDownAfter(e);
                  }}
                  onFocus={() => {
                    if (WindowAfter) {
                      setIsModalOpenAfter(true);
                    }
                  }}
                  onDoubleClick={() => handleDoubleClickAfter("expafterGST")}
                />
              </div>
              {isModalOpenAfter && (
        <div className="Modal">
          <div className="Modal-content">
            <h1 className="headingE">EXPENSE AFTER TAX</h1>
            <div className="form-group">
              <input
                type="checkbox"
                id="gross"
                checked={formData.gross}
                onChange={handleGross}
              />
              <label style={{ marginLeft: 5 }} className="label" htmlFor="Gross">
                GROSS
              </label>
            </div>
            <div style={{ display: "flex", flexDirection: "row", marginTop: 10 }}>
              <text>{Expense6}</text>
              <input
                id='Exp_rate6'
                value={formData.Exp_rate6}
                style={{ border: "1px solid black", width: 100, marginLeft: 26 }}
                onChange={handleNumberChange} // Updated to the new function name
              />
              <input
                id='Exp6'
                value={formData.Exp6}
                style={{ border: "1px solid black", width: 100, marginLeft: 5 }}
              />
            </div>
            <div style={{ display: "flex", flexDirection: "row", marginTop: 10 }}>
            <text>{Expense7}</text>
              <input
                id='Exp_rate7'
                value={formData.Exp_rate7}
                style={{ border: "1px solid black", width: 100, marginLeft: 26 }}
                onChange={handleNumberChange} // Updated to the new function name
              />
              <input
                id='Exp7'
                value={formData.Exp7}
                style={{ border: "1px solid black", width: 100, marginLeft: 5 }}
              />
            </div>
            <div style={{ display: "flex", flexDirection: "row", marginTop: 10 }}>
            <text>{Expense8}</text>
              <input
                id='Exp_rate8'
                value={formData.Exp_rate8}
                style={{ border: "1px solid black", width: 100, marginLeft: 26.5 }}
                onChange={handleNumberChange} // Updated to the new function name
              />
              <input
                id='Exp8'
                value={formData.Exp8}
                style={{ border: "1px solid black", width: 100, marginLeft: 5 }}
              />
            </div>
            <div style={{ display: "flex", flexDirection: "row", marginTop: 10 }}>
            <text>{Expense9}</text>
              <input
                id='Exp_rate9'
                value={formData.Exp_rate9}
                style={{ border: "1px solid black", width: 100, marginLeft: 18 }}
                onChange={handleNumberChange} // Updated to the new function name
              />
              <input
                id='Exp9'
                value={formData.Exp9}
                style={{ border: "1px solid black", width: 100, marginLeft: 5 }}
              />
            </div>
            <div style={{ display: "flex", flexDirection: "row", marginTop: 10 }}>
            <text>{Expense10}</text>
              <input
                id='Exp_rate10'
                value={formData.Exp_rate10}
                style={{ border: "1px solid black", width: 100, marginLeft: 24.5 }}
                onChange={handleNumberChange} // Updated to the new function name
              />
              <input
                id='Exp10'
                value={formData.Exp10}
                style={{ border: "1px solid black", width: 100, marginLeft: 5 }}
              />
            </div>
            {/* <div style={{ display: "flex", flexDirection: "row", marginTop: 10 }}>
              <text>TRANSPORT</text>
              <input
                id='Exp_rate12'
                value={formData.Exp_rate12}
                style={{ border: "1px solid black", width: 100, marginLeft: 14.5 }}
                onChange={handleNumberChange} // Updated to the new function name
              />
              <input
                id='Exp12'
                value={formData.Exp12}
                style={{ border: "1px solid black", width: 100, marginLeft: 5 }}
              />
            </div> */}
            <Button onClick={closeModalAfter} style={{ borderColor: "transparent", backgroundColor: "red", marginTop: 10 }}>
              CLOSE
            </Button>
          </div>
        </div>
      )}
      {T11 && (
    <div style={{display:'flex',flexDirection:'row',marginTop:2}}>
      <text>RoundOff:</text>
      <input style={{width:118,marginLeft:0}} className="RoundOff" value={formData.ExpRoundoff} disabled/>
    </div>
  )}
            </div>
            <div className="Bottomdivs" style={{marginLeft:5}}>
              <div>
                <text>SubTotal:</text>
                <input
                  className="SubTotal"
                  style={{ height: 30, fontSize: `${fontSize}px` }}
                  id="sub_total"
                  placeholder="subtotal"
                  value={formData.sub_total}
                  readOnly={!isEditMode || isDisabled}
                  onChange={handleNumberChange}
                />
              </div>
              <div className="margin">
                <text>C.Gst:</text>
                <input
                  className="CGST"
                  style={{ height: 30, fontSize: `${fontSize}px` }}
                  id="cgst"
                  placeholder="cgst"
                  value={formData.cgst}
                  readOnly={!isEditMode || isDisabled}
                  onChange={handleNumberChange}
                />
              </div>
              <div className="margin">
                <text>S.Gst:</text>
                <input
                  className="SGST"
                  style={{ height: 30, fontSize: `${fontSize}px` }}
                  id="sgst"
                  readOnly={!isEditMode || isDisabled}
                  placeholder="sgst"
                  value={formData.sgst}
                  onChange={handleNumberChange}
                />
              </div>
              <div className="margin">
                <text>I.GST:</text>
                <input
                  className="IGST"
                  style={{ height: 30, fontSize: `${fontSize}px` }}
                  id="igst"
                  value={formData.igst}
                  readOnly={!isEditMode || isDisabled}
                  placeholder="igst"
                  onChange={handleNumberChange}
                />
              </div>
              <div className="margin">
                <text>GrandTotal:</text>
                <input
                  className="GrandTotal"
                  style={{ height: 30, fontSize: `${fontSize}px` }}
                  id="grandtotal"
                  placeholder="grandtotal"
                  readOnly={!isEditMode || isDisabled}
                  value={formData.grandtotal}
                />
              </div>
            </div>
        
        </div>
        <div className="Buttonsgroupz">
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[0] }}
            onClick={handleAdd}
            disabled={!isAddEnabled}
          >
            Add
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[1] }}
            onClick={handleEditClick}
            disabled={!isAddEnabled}
          >
            Edit
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[2] }}
            onClick={handlePrevious}
            disabled={!isPreviousEnabled}
          >
            Previous
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[3] }}
            onClick={handleNext}
            disabled={!isNextEnabled}
          >
            Next
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[4] }}
            onClick={handleFirst}
            disabled={!isFirstEnabled}
          >
            First
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[5] }}
            onClick={handleLast}
            disabled={!isLastEnabled}
          >
            Last
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[6] }}
            disabled={!isSearchEnabled}
          >
            Search
          </Button>
          <Button
            className="Buttonz"
            onClick={handleOpen}
            style={{ color: "black", backgroundColor: buttonColors[7] }}
            disabled={!isPrintEnabled}
          >
            Print
          </Button>
          <Button
            className="delete"
            style={{ color: "black", backgroundColor: buttonColors[8] }}
            // onClick={handleDeleteClick}
            disabled={!isDeleteEnabled}
          >
            Delete
          </Button>
          <Button
            onClick={handleExit}
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[9] }}
          >
            Exit
          </Button>
          <Button
            ref={saveButtonRef}
            className="Buttonz"
            // onClick={handleSaveClick}
            disabled={!isSubmitEnabled}
            style={{ color: "black", backgroundColor: buttonColors[10] }}
          >
            Save
          </Button>
        </div>
      </div>
    </div>
  );
};
export default PurchasesReturn;
