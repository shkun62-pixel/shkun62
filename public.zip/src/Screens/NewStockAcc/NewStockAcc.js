// import React, { useState, useEffect,useRef} from "react";
// import {
//   Container,
// } from "@mui/material";
// import Button from "react-bootstrap/Button";
// import { ButtonGroup } from "@mui/material";
// import $ from "jquery";
// import "./NewStockAcc.css";
// import { ToastContainer, toast } from "react-toastify";
// import "react-toastify/dist/ReactToastify.css";
// import DatePicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";
// import axios from "axios";
// import ProductModalAccount from "../Modals/ProductModalAccount";
// import ProductModalCustomer from "../Modals/ProductModalCustomer";
// import { useEditMode } from "../../EditModeContext";
// import { Modal, Box, Autocomplete, TextField,  Typography } from "@mui/material";
// import { CompanyContext } from '../Context/CompanyContext';
// import { useContext } from "react";

// const NewStockAcc = () => {
  
//   const { company } = useContext(CompanyContext);
//     const tenant = company?.databaseName;
  
//     if (!tenant) {
//       // you may want to guard here or show an error state,
//       // since without a tenant you can’t hit the right API
//       console.error("No tenant selected!");
//     }

//    const inputRefs = useRef([]); // Array to hold references for input fields
//   const [formData, setFormData] = useState({
//     Acodes: "",
//     Aheads: "",
//     openwts: "",
//     openpcs: "",
//     Mmopbals: "",
//     Add2s: "",
//     Prate: "",
//     Mrps: "",
//     Cds: "",
//     Srate: "",
//     itax_rate: "",
//     ctax_rate: "",
//     Drate: "",
//     Stax_rate: "",
//     Cess_rate: "",
//     Pack: "",
//     Hsn: "",
//     Joint: "",
//     schemes: "",
//     duedate: "",
//     Rateins: "",
//     Stockins: "",
//     Units: "",
//     TradeName: "",
//     Stkcals: "",
//     Types: "",
//     Stkvals: "",
//     Qpps: "",
//     tariff: "",
//     Inval: "",
//     Rg23c: "",
//     Tcs206: "",
//     Stype: "",
//     T1: false,
//     Psrno:"",
//     PUnitno:"",
//     percentage:"",
//   });
//   const [PurchaseAcc, setPurchaseAcc] = useState([
//     {
//       Pcodess: "",
//       acCode: "",
//     },
//   ]);
//   const [SaleAcc, setSaleAcc] = useState([
//     {
//       Scodess: "",
//       AcCode: "",
//     },
//   ]);

//    // Search options
//    const [openSearch, setOpenSearch] = useState(false); // Modal Visibility
//    const [selectedOption, setSelectedOption] = useState(null); // Selected Item
//    const autoCompleteRef = useRef(null); // Reference for AutoComplete Input
  
//    // Fetch data from API when component mounts
//    useEffect(() => {
//      axios
//        .get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/stockmaster`)
//        .then((response) => setData2(response.data))
//        .catch((error) => console.error("Error fetching data:", error));
//    }, []);
  
//    // Open Modal and Set Focus to Autocomplete
//    const handleOpen = () => {
//      setOpenSearch(true);
//      setTimeout(() => {
//        if (autoCompleteRef.current) {
//          autoCompleteRef.current.focus(); // Focus Autocomplete
//        }
//      }, 100); // Delay to ensure modal opens first
//    };
  
//    // Close Modal & Clear Selection
//    const handleCloseSearch = () => {
//      setSelectedOption(null); // Reset selection
//      setOpenSearch(false);
//    };
  
//    // Handle ComboBox Selection & Close Modal on Enter
//    const handleSelect = (event, newValue) => {
//      if (newValue) {
//        setFormData(newValue.formData); // Set Selected Data
//        handleCloseSearch(); // Close Modal
//      }
//    };

//   // Modal For Customer
//   React.useEffect(() => {
//     // Fetch products from the API when the component mounts
//     fetchCustomers();
//   }, []);

//  const fetchCustomers = async () => {
//     try {
//       const response = await fetch(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/ledgerAccount`);
//       if (!response.ok) {
//         throw new Error("Failed to fetch products");
//       }
//       const data = await response.json();
//       // Ensure to extract the formData for easier access in the rest of your app
//       const formattedData = data.map(item => ({ ...item.formData, _id: item._id }));
//       setProductsCus(formattedData);
//       setLoadingCus(false);
//     } catch (error) {
//       setErrorCus(error.message);
//       setLoadingCus(false);
//     }
//   };
//   const [productsCus, setProductsCus] = useState([]);
//   const [showModalCus, setShowModalCus] = useState(false);
//   const [selectedItemIndexCus, setSelectedItemIndexCus] = useState(null);
//   const [loadingCus, setLoadingCus] = useState(true);
//   const [errorCus, setErrorCus] = useState(null);
//   const handleItemChangeCus = (index, key, value) => {
//     const updatedItems = [...SaleAcc];
//     updatedItems[index][key] = value;
//     // If the key is 'name', find the corresponding product and set the price
//     if (key === "name") {
//       const selectedProduct = productsCus.find(
//         (product) => product.ahead === value
//       );
//       if (selectedProduct) {
//         updatedItems[index]["Scodess"] = selectedProduct.ahead;
//         updatedItems[index]["AcCode"] = selectedProduct.acode;
//       }
//     }
//     setSaleAcc(updatedItems);
//   };

//   const handleProductSelectCus = (product) => {
//     if (selectedItemIndexCus !== null) {
//       handleItemChangeCus(selectedItemIndexCus, "name", product.ahead);
//       setShowModalCus(false);

//       // Focus back on the input field after selecting the value
//       setTimeout(() => {
//         inputRefs.current[15]?.focus();
//       }, 0);
//     }
//   };
 
//   const openModalForItemCus = (index) => {
//     setSelectedItemIndexCus(index);
//     setShowModalCus(true);
//   };

//   const allFieldsCus = productsCus.reduce((fields, product) => {
//     Object.keys(product).forEach((key) => {
//       if (!fields.includes(key)) {
//         fields.push(key);
//       }
//     });

//     return fields;
//   }, []);

//   // Fetching Account Name
//   React.useEffect(() => {
//     // Fetch products from the API when the component mounts
//     fetchAccountName();
//   }, []);

//   const fetchAccountName = async () => {
//     try {
//       const response = await fetch(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/ledgerAccount`);
//       if (!response.ok) {
//         throw new Error("Failed to fetch products");
//       }
//       const data = await response.json();
//       // Ensure to extract the formData for easier access in the rest of your app
//       const formattedData = data.map(item => ({ ...item.formData, _id: item._id }));
//       setProductsAcc(formattedData);
//       setLoadingAcc(false);
//     } catch (error) {
//       setErrorAcc(error.message);
//       setLoadingAcc(false);
//     }
//   };

//   // Modal For Purchase Account
//   const [productsAcc, setProductsAcc] = useState([]);
//   const [showModalAcc, setShowModalAcc] = useState(false);
//   const [selectedItemIndexAcc, setSelectedItemIndexAcc] = useState(null);
//   const [loadingAcc, setLoadingAcc] = useState(true);
//   const [errorAcc, setErrorAcc] = useState(null);
//   const [pressedKey, setPressedKey] = useState(""); // State to hold the pressed key
//   const handleItemChangeAcc = (index, key, value) => {
//     const updatedItems = [...PurchaseAcc];
//     updatedItems[index][key] = value;
//     // If the key is 'name', find the corresponding product and set the price
//     if (key === "acName") {
//       const selectedProduct = productsAcc.find(
//         (product) => product.ahead === value
//       );
//       if (selectedProduct) {
//         updatedItems[index]["Pcodess"] = selectedProduct.ahead;
//         updatedItems[index]["acCode"] = selectedProduct.acode;
//       }
//     }
//     setPurchaseAcc(updatedItems);
//   };

//   const handleProductSelectAcc = (product) => {
//     if (selectedItemIndexAcc !== null) {
//       handleItemChangeAcc(selectedItemIndexAcc, "acName", product.ahead);
//       setShowModalAcc(false);

//       // Focus back on the input field after selecting the value
//       setTimeout(() => {
//         inputRefs.current[14]?.focus();
//       }, 0);
//     }
//   };
//   const openModalForItemAcc = (index) => {
//     setSelectedItemIndexAcc(index);
//     setShowModalAcc(true);
//   };
//   const allFieldsAcc = productsAcc.reduce((fields, product) => {
//     Object.keys(product).forEach((key) => {
//       if (!fields.includes(key)) {
//         fields.push(key);
//       }
//     });

//     return fields;
//   }, []);

//   const handleOpenModal = (event, index, field) => {
//     if (/^[a-zA-Z]$/.test(event.key) && field === "Pcodess" && isEditMode) {
//       setPressedKey(event.key); // Set the pressed key
//       openModalForItemAcc(index);
//       event.preventDefault(); // Prevent any default action
//     }
//     if (/^[a-zA-Z]$/.test(event.key) && field === "Scodess"&& isEditMode) {
//       setPressedKey(event.key); // Set the pressed key
//       openModalForItemCus(index);
//       event.preventDefault(); // Prevent any default action
//     }
//   };
//   const handleOpenModalBack = (event, index, field) => {
//     if (event.key === "Backspace" && field === "Pcodess") {
//         setSelectedItemIndexAcc(index);
//         setShowModalAcc(true);
//         event.preventDefault();
//     }
//     if (event.key === "Backspace" && field === "Scodess") {
//       setSelectedItemIndexCus(index);
//       setShowModalCus(true);
//       event.preventDefault();
//   }
// };
//    // Api Response
//     const [data, setData] = useState([]);
//     const [data1, setData1] = useState([]);
//     const [data2, setData2] = useState([]);
//     const [index, setIndex] = useState(0);
//     const [isAddEnabled, setIsAddEnabled] = useState(true);
//     const [isSubmitEnabled, setIsSubmitEnabled] = useState(false);
//     const { isEditMode, setIsEditMode } = useEditMode(); // Access the context
//     const [isAbcmode, setIsAbcmode] = useState(false);
//     const [isDisabled, setIsDisabled] = useState(false); // State to track field disablement

//     const fetchData = async () => {
//       try {
//         const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/stockmaster/last`);
//         if (response.status === 200 && response.data.data) {
//           const lastEntry = response.data.data;
//           console.log("LASTENTRY:",lastEntry);
          
//           setFormData(lastEntry.formData);
//           setData1(lastEntry); // Assuming this is meant to hold the full data structure
//           setIndex(lastEntry._id);
//           // Convert cesscode into an array containing one object
//           setPurchaseAcc([{ Pcodess: lastEntry.formData.Pcodess, acCode: lastEntry.formData.acCode }]);
//           setSaleAcc([{ Scodess: lastEntry.formData.Scodess, AcCode: lastEntry.formData.AcCode }]);
//         } else {
//           setDefaults(); // If no data, reset everything
//         }
//       } catch (error) {
//         console.error("Error fetching data", error);
//         setDefaults(); // Reset in case of error
//       }
//     };
    
//     const setDefaults = () => {
//       // Define default empty states here to avoid redundancy and mistakes
//       const emptyData = {
//         Acodes: "",
//         Aheads: "",
//         openwts: "",
//         openpcs: "",
//         Mmopbals: "",
//         Add2s: "",
//         Prate: "",
//         Mrps: "",
//         Cds: "",
//         Srate: "",
//         itax_rate: "",
//         ctax_rate: "",
//         Drate: "",
//         Stax_rate: "",
//         Cess_rate: "",
//         Pack: "",
//         Hsn: "",
//         Joint: "",
//         schemes: "",
//         duedate: "",
//         Rateins: "",
//         Stockins: "",
//         Units: "",
//         TradeName: "",
//         Stkcals: "",
//         Types: "",
//         Stkvals: "",
//         Qpps: "",
//         tariff: "",
//         Inval: "",
//         Rg23c: "",
//         Tcs206: "",
//         Stype: "",
//         T1: false,
//         Psrno:"",
//         PUnitno:"",
//         percentage:"",
//       };
//       const emptyPurchaseACC = [{ cesscode: "", cessAc: "" }];
//       const emptySaleAcc= [{ cgst_code: "", cgst_ac: "" }];
//       setFormData(emptyData);
//       setPurchaseAcc(emptyPurchaseACC);
//       setSaleAcc(emptySaleAcc);
//       setData1({ formData: emptyData, PurchaseAcc: emptyPurchaseACC, SaleAcc: emptySaleAcc});
//       setIndex(0);
//     };

//    useEffect(() => {
//        fetchData(); // Fetch data when component mounts
//        setIsDisabled(true); // Add this line to set isDisabled to true initially
//    }, []); // Empty dependency array ensures it only runs once when component mounts

//   const handleNext = async () => {
//     document.body.style.backgroundColor = 'white';
//     console.log(data1._id)
//     try {
//         if (data1) {
//           const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/stockmaster/next/${data1._id}`);
//             if (response.status === 200 && response.data) {
//                 const nextData = response.data.data;
//                 setData1(response.data.data);
//                 setIndex(index + 1);
//                 setFormData(nextData.formData);
//                 setIsDisabled(true);
//             }
//         }
//     } catch (error) {
//         console.error("Error fetching next record:", error);
//     }
// };

// const handlePrevious = async () => {
//     document.body.style.backgroundColor = 'white';
//     try {
//         if (data1) {
//           const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/stockmaster/previous/${data1._id}`);
//             if (response.status === 200 && response.data) {
//                 console.log(response);
//                 setData1(response.data.data);
//                 const prevData = response.data.data;
//                 setIndex(index - 1);
//                 setFormData(prevData.formData);
//                 setIsDisabled(true);
//             }
//         }
//     } catch (error) {
//         console.error("Error fetching previous record:", error);
//     }
// };

// const handleFirst = async () => {
//     document.body.style.backgroundColor = 'white';
//     try {
//         const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/stockmaster/first`);
//         if (response.status === 200 && response.data) {
//             const firstData = response.data.data;
//             setIndex(0);
//             setFormData(firstData.formData);
//             setData1(response.data.data);
//             setIsDisabled(true);
//         }
//     } catch (error) {
//         console.error("Error fetching first record:", error);
//     }
// };

// const handleLast = async () => {
//     document.body.style.backgroundColor = 'white';
//     try {
//         const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/stockmaster/last`);
//         if (response.status === 200 && response.data) {
//             const lastData = response.data.data;
//             const lastIndex = response.data.length - 1;
//             setIndex(lastIndex);
//             setFormData(lastData.formData);
//             setData1(response.data.data);
//             setIsDisabled(true);
//         }
//     } catch (error) {
//         console.error("Error fetching last record:", error);
//     }
// };

// const handleAdd = async () => {
//     // document.body.style.backgroundColor = '#D5ECF3';
//     try {
//         await fetchData(); // This should set up the state correctly whether data is found or not
//         let lastvoucherno = formData.Acodes ? parseInt(formData.Acodes) + 1 : 1;
//         const newData = {
//           Acodes: lastvoucherno, // Continue from the last voucher number or start new
//           Aheads: "",
//           openwts: "",
//           openpcs: "",
//           Mmopbals: "",
//           Add2s: "",
//           Prate: "",
//           Mrps: "",
//           Cds: "",
//           Srate: "",
//           itax_rate: "",
//           ctax_rate: "",
//           Drate: "",
//           Stax_rate: "",
//           Cess_rate: "",
//           Pack: "",
//           Hsn: "",
//           Joint: "",
//           schemes: "",
//           duedate: "",
//           Rateins: "",
//           Stockins: "",
//           Units: "",
//           TradeName: "",
//           Stkcals: "",
//           Types: "",
//           Stkvals: "",
//           Qpps: "",
//           tariff: "",
//           Inval: "",
//           Rg23c: "",
//           Tcs206: "",
//           Stype: "",
//           T1: false,
//           Psrno:"",
//           PUnitno:"",
//           percentage:"",
//         };
//         setData([...data, newData]);
//         setFormData(newData);
//         setPurchaseAcc([{ Pcodess: "", acCode: "" }]);
//         setSaleAcc([{ Scodess: "", AcCode: "" }]);
//         setIndex(data.length);
//         setIsAddEnabled(false);
//         setIsSubmitEnabled(true);
//         setIsDisabled(false);
//         setIsEditMode(true);
//         if (inputRefs.current[0]) {
//           inputRefs.current[0].focus();
//         }
//     } catch (error) {
//         console.error("Error adding new entry:", error);
//     }
//   };
  
// const handleExit = async () => {
//   document.body.style.backgroundColor = 'white'; // Reset background color
//   setIsAddEnabled(true); // Enable "Add" button
//   setIsSubmitEnabled(false);
//   try {
//       const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/stockmaster/last`); // Fetch the latest data
//       if (response.status === 200 && response.data.data) {
//           // If data is available
//           const lastEntry = response.data.data;
//           const lastIndex = response.data.length - 1;
//           setFormData(lastEntry.formData); // Set form data
//           setData1(response.data.data);
//           setIndex(lastIndex)
//           const updatedPurAcc = lastEntry.PurchaseAcc.map(item => ({
//             ...item, 
//         }));
//         const updatedSaleAcc = lastEntry.SaleAcc.map(item => ({
//           ...item, 
//       }));
//         setPurchaseAcc(updatedPurAcc);
//         setSaleAcc(updatedSaleAcc);
//         setIsDisabled(true); // Disable fields after loading the data
//       } else {
//           // If no data is available, initialize with default values
//           console.log("No data available");
//           const newData = {
//             Acodes: "",
//             Aheads: "",
//             openwts: "",
//             openpcs: "",
//             Mmopbals: "",
//             Add2s: "",
//             Prate: "",
//             Mrps: "",
//             Cds: "",
//             Srate: "",
//             itax_rate: "",
//             ctax_rate: "",
//             Drate: "",
//             Stax_rate: "",
//             Cess_rate: "",
//             Pack: "",
//             Hsn: "",
//             Joint: "",
//             schemes: "",
//             duedate: "",
//             Rateins: "",
//             Stockins: "",
//             Units: "",
//             TradeName: "",
//             Stkcals: "",
//             Types: "",
//             Stkvals: "",
//             Qpps: "",
//             tariff: "",
//             Inval: "",
//             Rg23c: "",
//             Tcs206: "",
//             Stype: "",
//             T1: false,
//             Psrno:"",
//             PUnitno:"",
//             percentage:"",
//           };
//           setFormData(newData); // Set default form data
//           setPurchaseAcc([{
//             Pcodess: "",
//             acCode: "",
//           }]);
//           setSaleAcc([{
//             Scodess: "",
//             AcCode: "",
//           }]);

//           setIsDisabled(true); // Disable fields after loading the default data
//       }
//   } catch (error) {
//       console.error("Error fetching data", error);
//   }
// };

//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };

//   const handleKeyPress = (event, nextInputId) => {
//     if (event.key === "Enter") {
//       const nextInput = document.getElementById(nextInputId);
//       if (nextInput) {
//         nextInput.focus();
//       }
//     }
//   };
//   let a = "Less%";
//   const initialColors = [
//     "#E9967A",
//     "#F0E68C",
//     "#FFDEAD",
//     "#ADD8E6",
//     "#87CEFA",
//     "#FFF0F5",
//     "#FFC0CB",
//     "#D8BFD8",
//     "#DC143C",
//     "#DCDCDC",
//     "#8FBC8F",
//   ];
//   const [buttonColors, setButtonColors] = useState(initialColors); // Initial colors

//   const handleratecal = (event) => {
//     const { value } = event.target; // Get the selected value from the event
//     setFormData((prevState) => ({
//       ...prevState,
//       Rateins: value, // Update the Rateins field in FormData
//     }));
//   };
//   const hanldeclsStock = (event) => {
//     const { value } = event.target; // Get the selected value from the event
//     setFormData((prevState) => ({
//       ...prevState,
//       Stockins: value, // Update the Rateins field in FormData
//     }));
//   };
//   const handleqtyunit = (event) => {
//     const { value } = event.target; // Get the selected value from the event
//     setFormData((prevState) => ({
//       ...prevState,
//       Units: value, // Update the Rateins field in FormData
//     }));
//   };
//   const handleportal = (event) => {
//     const { value } = event.target; // Get the selected value from the event
//     setFormData((prevState) => ({
//       ...prevState,
//       TradeName: value, // Update the Rateins field in FormData
//     }));
//   };
//   const handlestockCal = (event) => {
//     const { value } = event.target; // Get the selected value from the event
//     setFormData((prevState) => ({
//       ...prevState,
//       Stkcals: value, // Update the Rateins field in FormData
//     }));
//   };
//   const handleGoods = (event) => {
//     const { value } = event.target; // Get the selected value from the event
//     setFormData((prevState) => ({
//       ...prevState,
//       Types: value, // Update the Rateins field in FormData
//     }));
//   };
//   const handlestkValuation = (event) => {
//     const { value } = event.target; // Get the selected value from the event
//     setFormData((prevState) => ({
//       ...prevState,
//       Stkvals: value, // Update the Rateins field in FormData
//     }));
//   };
//   const handleselection = (event) => {
//     const { value } = event.target; // Get the selected value from the event
//     setFormData((prevState) => ({
//       ...prevState,
//       Tcs206: value, // Update the Rateins field in FormData
//     }));
//   };
//   const handlegsttype = (event) => {
//     const { value } = event.target; // Get the selected value from the event
//     setFormData((prevState) => ({
//       ...prevState,
//       Stype: value, // Update the Rateins field in FormData
//     }));
//   };

//  // Handle number input validation
//  const handleNumberChange = (event) => {
//   const { name, value } = event.target;
//   const numberValue = value.replace(/[^0-9.]/g, ""); // Allow only numbers and decimal
//   const validNumberValue =
//     numberValue.split(".").length > 2
//       ? numberValue.replace(/\.{2,}/g, "").replace(/(.*)\./g, "$1.")
//       : numberValue;

//   setFormData((prevState) => ({
//     ...prevState,
//     [name]: validNumberValue,
//   }));

//   // If Mrps or Cds is changed, recalculate Srate
//   if (name === "Mrps" || name === "Cds") {
//     if (validNumberValue) {
//       calculateSrate(name === "Mrps" ? validNumberValue : formData.Mrps, name === "Cds" ? validNumberValue : formData.Cds);
//     }
//   }
// };

// // Function to calculate and set Srate
// const calculateSrate = (mrps, cds) => {
//   const mrpsValue = parseFloat(mrps);
//   const cdsValue = parseFloat(cds);

//   if (!isNaN(mrpsValue) && !isNaN(cdsValue)) {
//     const discount = (cdsValue / 100) * mrpsValue;
//     const saleRate = mrpsValue - discount;
//     setFormData((prevState) => ({
//       ...prevState,
//       Srate: saleRate.toFixed(3), // Set the calculated sale rate with 2 decimal places
//     }));
//   }
// };

// const handleSrateChange = (event) => {
//   const { value } = event.target;
//   setFormData((prevState) => ({
//     ...prevState,
//     Srate: value, // Allow manual entry in the Srate field
//   }));
// };

// const handleSaveClick = async () => {
//   document.body.style.backgroundColor = "white";
//   let isDataSaved = false; 

//   // Check if formData.Aheads is empty
//   if (!formData.Aheads || formData.Aheads.trim() === "") {
//     toast.error("Name cannot be empty!", { position: "top-center" });
//     return; // Prevent the save operation
//   }

//   const userConfirmed = window.confirm("Are you sure you want to save the data?");
//   if (!userConfirmed) return;

//   const prepareData = () => ({
//     _id: formData._id,
//     formData: {
//       ...formData,
//       Pcodess: PurchaseAcc.length > 0 ? PurchaseAcc[0].Pcodess : "",
//       acCode: PurchaseAcc.length > 0 ? PurchaseAcc[0].acCode : "",
//       Scodess: SaleAcc.length > 0 ? SaleAcc[0].Scodess : "",
//       AcCode: SaleAcc.length > 0 ? SaleAcc[0].AcCode : "",
//     },
//   });

//   try {
//     const combinedData = prepareData();
//     console.log("Combined Data:", combinedData);
//     const apiEndpoint = `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/stockmaster${isAbcmode ? `/${data1._id}` : ""}`;
//     const method = isAbcmode ? "put" : "post";
//     const response = await axios({ method, url: apiEndpoint, data: combinedData });

//     if (response.status === 200 || response.status === 201) {
//       // fetchData();
//       isDataSaved = true;
//     }
//   } catch (error) {
//     console.error("Error saving data:", error);
//     toast.error("Failed to save data. Please try again.", { position: "top-center" });
//   } finally {
//     setIsSubmitEnabled(false);
//     isDataSaved ? setIsAddEnabled(true) : setIsAddEnabled(false);
//     setIsDisabled(!isDataSaved);
//     setIsEditMode(!isDataSaved);

//     const toastMsg = isDataSaved ? "Data Saved Successfully!" : "Failed to save data.";
//     if (isDataSaved) {
//       toast.success(toastMsg, { position: "top-center" });
//     }
//   }
// };

// // const handleSaveClick = async () => {
// //     document.body.style.backgroundColor = "white";
// //     let isDataSaved = false; 
// //     const userConfirmed = window.confirm("Are you sure you want to save the data?");
// //     if (!userConfirmed) return;
// //     const prepareData = () => ({
// //       _id: formData._id,
// //       formData: {
// //         ...formData,
// //         Pcodess: PurchaseAcc.length > 0 ? PurchaseAcc[0].Pcodess : '',
// //         acCode: PurchaseAcc.length > 0 ? PurchaseAcc[0].acCode : '',
// //         Scodess: SaleAcc.length > 0 ? SaleAcc[0].Scodess : '',
// //         AcCode: SaleAcc.length > 0 ? SaleAcc[0].AcCode : '',
// //       }
// //     });

// //     try {
// //       const combinedData = prepareData();
// //       console.log("Combined Data:", combinedData);
// //       const apiEndpoint = `http://103.168.19.65:3012/auth/stockmaster${isAbcmode ? `/${data1._id}` : ""}`;
// //       const method = isAbcmode ? "put" : "post";
// //       const response = await axios({ method, url: apiEndpoint, data: combinedData });

// //       if (response.status === 200 || response.status === 201) {
// //         fetchData();
// //         isDataSaved = true;
// //       }
// //     } catch (error) {
// //       console.error("Error saving data:", error);
// //       toast.error("Failed to save data. Please try again.", { position: "top-center" });
// //     } finally {
// //       setIsSubmitEnabled(false);
// //       isDataSaved ? setIsAddEnabled(true) : setIsAddEnabled(false);
// //       setIsDisabled(!isDataSaved);
// //       setIsEditMode(!isDataSaved);
// //       const toastMsg = isDataSaved ? "Data Saved Successfully!" : "Failed to save data.";
// //       toast.success(toastMsg, { position: "top-center" });
// //     }
// // };

//   const handleDeleteClick = async (id) => {
//     if (!id) {
//       toast.error("Invalid ID. Please select an item to delete.", {
//         position: "top-center",
//       });
//       return;
//     }
//     const userConfirmed = window.confirm(
//       "Are you sure you want to delete this item?"
//     );
//     if (!userConfirmed) return;
//     try {
//       const apiEndpoint = `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/stockmaster/${data1._id}`;
//       const response = await axios.delete(apiEndpoint);

//       if (response.status === 200) {
//         toast.success("Data deleted successfully!", { position: "top-center" });
//         fetchData(); // Refresh the data after successful deletion
//       } else {
//         throw new Error(`Failed to delete data: ${response.statusText}`);
//       }
//     } catch (error) {
//       console.error("Error deleting data:", error);
//       toast.error(`Failed to delete data. Error: ${error.message}`, {
//         position: "top-center",
//       });
//     } finally {
   
//     }
//   };
// const handleEditClick = () => {
//   // document.body.style.backgroundColor = '#F3F2C8';
//   setIsDisabled(false);
//   setIsEditMode(true);
//   setIsSubmitEnabled(true);
//   setIsAbcmode(true);
//   if (inputRefs.current[0]) {
//     inputRefs.current[0].focus();
//   }
// };

//   const handleChangevalues = (event) => {
//     const { name, value } = event.target;
//     setFormData((prevState) => ({
//       ...prevState,
//       [name]: value,
//     }));

//     // Calculate CGST and SGST
//     if (name === "itax_rate") {
//       const gstValue = parseFloat(value);
//       if (!isNaN(gstValue)) {
//         const cgstValue = gstValue / 2;
//         const sgstValue = gstValue / 2;
//         setFormData((prevState) => ({
//           ...prevState,
//           ctax_rate: cgstValue.toFixed(3),
//           Stax_rate: sgstValue.toFixed(3),
//         }));
//       }
//     }
//   };
//   const [expiredDate, setexpiredDate] = useState(null);
//   useEffect(() => {
//     if (formData.duedate) {
//       setexpiredDate(new Date(formData.duedate));
//     } else {
//       const today = new Date();
//       setexpiredDate(today);
//       setFormData({ ...formData, duedate: today });
//     }
//   }, [formData.duedate, setFormData]);
//   const handleDateChange = (date) => {
//     setexpiredDate(date);
//     setFormData({ ...formData, duedate: date });
//   };

//  // Handle Enter key to move focus to the next enabled input
//  const handleKeyDown = (e, index) => {
//   if (e.key === "Enter") {
//     e.preventDefault(); // Prevent default behavior
//     let nextIndex = index + 1;

//     // Find the next input that is not disabled
//     while (inputRefs.current[nextIndex] && inputRefs.current[nextIndex].disabled) {
//       nextIndex += 1;
//     }

//     const nextInput = inputRefs.current[nextIndex];
//     if (nextInput) {
//       nextInput.focus(); // Focus the next enabled input field
//     }
//   }
// };
//  const handleNumericValue = (event) => {
//       const { id, value } = event.target;
//       // Allow only numeric values, including optional decimal points
//       if (/^\d*\.?\d*$/.test(value) || value === '') {
//         setFormData((prevData) => ({
//           ...prevData,
//           [id]: value,
//         }));
//       }
//     };

//     const handleChangeCheckBox = (e) => {
//       const { name, type, value, checked } = e.target;
  
//       setFormData((prev) => ({
//         ...prev,
//         [name]: type === "checkbox" ? checked : value, // Update based on type
//       }));
//     };

//     const handleRateBlur = (field) => {
//       const decimalPlaces = 3; // Default to 3 decimal places if rateValue is undefined
//       let value = parseFloat(formData[field]);
    
//       if (isNaN(value)) {
//         setFormData((prev) => ({ ...prev, [field]: "" })); // Keep empty if NaN
//       } else {
//         setFormData((prev) => ({ ...prev, [field]: value.toFixed(decimalPlaces) }));
//       }
//     };

//   return (
//     <div style={{padding:10}}>
//       <h1
//         className="heading"
//         style={{ fontWeight: 700, marginTop: -35, letterSpacing: 5 }}
//       >
//         STOCK ITEM MENU
//       </h1>
//       <div className="Main2" style={{padding:10}}>
//         <div>
//           <ToastContainer style={{ width: "30%" }} />
//         </div>
//             <div className="MainDiv">
//               {/* First Half Screen */}
//               <div className="FirstHalf">
//                 <div>
//                   <div style={{ display: "flex", flexDirection: "row" }}>
//                     <text>Accode:</text>
//                     <input
//                       className="ACCcoDE"
//                       readOnly={!isEditMode || isDisabled}
//                       type="text"
//                       name="Acodes"
//                       value={formData.Acodes}
//                       onChange={handleChange}
//                       onKeyPress={(event) => handleKeyPress(event, "gstNo")}
//                     />
//                   </div>
//                   <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
//                     <text>Name:</text>
//                     <input
//                        readOnly={!isEditMode || isDisabled}
//                       className="ItemName"
//                       size="small"
//                       type="text"
//                       name="Aheads"
//                       value={formData.Aheads}
//                       ref={(el) => (inputRefs.current[0] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 0)} // Handle Enter key
//                       onChange={handleChange}
//                       maxLength={75}
//                     />
//                   </div>
//                   <div style={{display: "flex",flexDirection: "row",marginTop:5}}>
//                     <text>Op.StockInQty:</text>
//                     <input
//                       className="OpSTOCK"
//                       readOnly={!isEditMode || isDisabled}
//                       size="small"
//                       fullWidth
//                       label="openwts"
//                       value={formData.openwts}
//                       ref={(el) => (inputRefs.current[1] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 1)} // Handle Enter key
//                       name="openwts"
//                       onChange={handleNumberChange}
//                       maxLength={10}
//                       onBlur={() => handleRateBlur("openwts")}
//                     />
//                     <input
//                       value={"Box/Pc"}
//                       style={{
//                         width: 65,
//                         color:'black',
//                         textAlign: "center",
//                         marginLeft: 2,
//                         backgroundColor: "skyblue",
//                       }}
//                       disabled
//                     />
//                     <div>
//                       <input
//                         className="openpcs"
//                         readOnly={!isEditMode || isDisabled}
//                         size="small"
//                         fullWidth
//                         label="openpcs"
//                         value={formData.openpcs}
//                          ref={(el) => (inputRefs.current[2] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 2)} // Handle Enter key
//                         name="openpcs"
//                         onChange={handleNumberChange}
//                         maxLength={10}
//                         onBlur={() => handleRateBlur("openpcs")}
//                       />
//                     </div>
//                   </div>
//                   <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
//                     <text>Op.Stock in Rs:</text>
//                     <input
//                       className="OpStockRS"
//                       readOnly={!isEditMode || isDisabled}
//                       size="small"
//                       fullWidth
//                       label="Mmopbals"
//                       name="Mmopbals"
//                       value={formData.Mmopbals}
//                       onChange={handleNumberChange}
//                        ref={(el) => (inputRefs.current[3] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 3)} // Handle Enter key
//                       maxLength={10}
//                       onBlur={() => handleRateBlur("Mmopbals")}
//                     />
//                   </div>
//                   <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
//                     <text>Group Name:</text>
//                     <input
//                       className="GroupNAME"
//                       readOnly={!isEditMode || isDisabled}
//                       size="small"
//                       label="Add2s"
//                       name="Add2s"
//                       value={formData.Add2s}
//                       onChange={handleChange}
//                       ref={(el) => (inputRefs.current[4] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 4)} // Handle Enter key
//                     />
//                   </div>
//                   <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
//                     <text>PurchaseRate:</text>
//                     <input
//                       className="PurchaseRATE"
//                       readOnly={!isEditMode || isDisabled}
//                       size="small"
//                       label="Prate"
//                       name="Prate"
//                       value={formData.Prate}
//                       onChange={handleNumberChange}
//                       ref={(el) => (inputRefs.current[5] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 5)} // Handle Enter key
//                       maxLength={10}
//                       onBlur={() => handleRateBlur("Prate")}
//                     />
//                   </div>
//                   <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
//           <text>M.R.P:</text>
//           <input
//             className="MRP"
//             size="small"
//             label="Mrps"
//             name="Mrps"
//             value={formData.Mrps}
//             onChange={handleNumberChange}
//             ref={(el) => (inputRefs.current[6] = el)} // Assign ref
//             onKeyDown={(e) => handleKeyDown(e, 6)} // Handle Enter key
//             maxLength={10}
//             onBlur={() => handleRateBlur("Mrps")}
//           />
//           <input
//             value={a}
//             style={{
//               width: 75,
//               textAlign: "center",
//               marginLeft: 2,
//               backgroundColor: "skyblue",
//               color:"black"
//             }}
//             disabled
//           />
//           <input
//             className="Cds"
//             size="small"
//             label="Cds"
//             name="Cds"
//             value={formData.Cds}
//             onChange={handleNumberChange}
//             ref={(el) => (inputRefs.current[7] = el)} // Assign ref
//             onKeyDown={(e) => handleKeyDown(e, 7)} // Handle Enter key
//             maxLength={10}
//             onBlur={() => handleRateBlur("Cds")}
//           />
//         </div>

//         <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
//           <text>SaleRate:</text>
//           <input
//             className="SaleRATE"
//             size="small"
//             fullWidth
//             label="Srate"
//             name="Srate"
//             value={formData.Srate}
//             onChange={handleSrateChange} // Allow manual entry in Srate
//             ref={(el) => (inputRefs.current[8] = el)} // Assign ref
//             onKeyDown={(e) => handleKeyDown(e, 8)} // Handle Enter key
//             maxLength={10}
//             onBlur={() => handleRateBlur("Srate")}
//           />
//           <text style={{ marginTop: 5 }}>TotalGST@:</text>
//           <input
//             className="TotalGST"
//             size="small"
//             fullWidth
//             label="itax_rate"
//             name="itax_rate"
//             value={formData.itax_rate}
//             onChange={handleChangevalues}
//             ref={(el) => (inputRefs.current[9] = el)} // Assign ref
//             onKeyDown={(e) => handleKeyDown(e, 9)} // Handle Enter key
//             maxLength={4}
//             onBlur={() => handleRateBlur("itax_rate")}
//           />
//         </div>
//                   <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
//                     <text>C.GST@:</text>
//                     <input
//                       className="ItemCgst"
//                       readOnly
//                       size="small"
//                       label="ctax_rate"
//                       name="ctax_rate"
//                       value={formData.ctax_rate}
//                       disabled
//                       ref={(el) => (inputRefs.current[10] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 10)} // Handle Enter key
//                       maxLength={10}
//                       onBlur={() => handleRateBlur("ctax_rate")}
//                     />
//                     <input
//                       value={"Cess Qty"}
//                       style={{
//                         width: 65,
//                         textAlign: "center",
//                         marginLeft: 2,
//                         backgroundColor: "skyblue",
//                         color:'black'
//                       }}
//                       disabled
//                     />
//                     <input
//                       className="Drate"
//                       readOnly={!isEditMode || isDisabled}
//                       size="small"
//                       label="Drate"
//                       name="Drate"
//                       value={formData.Drate}
//                       onChange={handleNumberChange}
//                       ref={(el) => (inputRefs.current[11] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 11)} // Handle Enter key
//                       maxLength={10}
//                       onBlur={() => handleRateBlur("Drate")}
//                     />
//                   </div>
//                   <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
//                     <text>S.GST@:</text>
//                     <input
//                       className="ItemSgst"
//                       readOnly
//                       size="small"
//                       label="Stax_rate"
//                       name="Stax_rate"
//                       value={formData.Stax_rate}
//                       disabled
//                       ref={(el) => (inputRefs.current[12] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 12)} // Handle Enter key
//                       maxLength={10}
//                       onBlur={() => handleRateBlur("Stax_rate")}
//                     />
//                     <input
//                       value={"Cess @"}
//                       style={{
//                         width: 65,
//                         textAlign: "center",
//                         marginLeft: 2,
//                         backgroundColor: "skyblue",
//                         color:'black'
//                       }}
//                       disabled
//                     />
//                     <input
//                       className="Cess_rate"
//                       readOnly={!isEditMode || isDisabled}
//                       size="small"
//                       label="Cess_rate"
//                       name="Cess_rate"
//                       value={formData.Cess_rate}
//                       onChange={handleNumberChange}
//                       ref={(el) => (inputRefs.current[13] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 13)} // Handle Enter key
//                       maxLength={10}
//                       onBlur={() => handleRateBlur("Cess_rate")}
//                     />
//                   </div>
//                   <div>
//                     {PurchaseAcc.map((item, index) => (
//                       <div key={item.Pcodess}>
//                         <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
//                           <text>PurchaseA/c:</text>
//                           <input
//                     className="PurchaseACC"
//                     readOnly={!isEditMode || isDisabled}
//                     value={item.Pcodess || ''}
//                     onChange={(e) => {
//                       const newPur = [...PurchaseAcc];
//                       newPur[index].Pcodess = e.target.value;
//                       setPurchaseAcc(newPur);
//                     }}
//                     ref={(el) => (inputRefs.current[14] = el)} // Assign ref
//                     onKeyDown={(e) => {
//                       handleOpenModal(e, index, "Pcodess");
//                       handleKeyDown(e, 14)
//                       handleOpenModalBack(e, index, "Pcodess");
//                     }}
//                   />
//                           {/* <input
//                             className="PurchaseACC"
//                             readOnly={!isEditMode || isDisabled}
//                             id="Pcodess"
//                             value={item.Pcodess}
//                             // onClick={() => openModalForItemAcc(index)}
//                              ref={(el) => (inputRefs.current[14] = el)} // Assign ref
//                             onKeyDown={(e) => {
//                               handleOpenModal(e, index, "Pcodess");
//                               handleKeyDown(e, 14)
//                             }}
//                           /> */}
//                         </div>
//                       </div>
//                     ))}
//                     {showModalAcc && (
//                       <ProductModalAccount
//                         allFieldsAcc={allFieldsAcc}
//                         productsAcc={productsAcc}
//                         onSelectAcc={handleProductSelectAcc}
//                         onCloseAcc={() => setShowModalAcc(false)}
//                         initialKey={pressedKey} // Pass the pressed key to the modal
//                       />
//                     )}
//                   </div>
//                   <div>
//                     {SaleAcc.map((item, index) => (
//                       <div key={item.Scodess}>
//                         <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
//                           <text>SaleA/c:</text>
//                           <input
//                     className="SaleACC"
//                     readOnly={!isEditMode || isDisabled}
//                     value={item.Scodess || ''}
//                     onChange={(e) => {
//                       const newSale = [...SaleAcc];
//                       newSale[index].Scodess = e.target.value;
//                       setSaleAcc(newSale);
//                     }}
//                     ref={(el) => (inputRefs.current[15] = el)} // Assign ref
//                             onKeyDown={(e) => {
//                               handleOpenModal(e, index, "Scodess");
//                                handleKeyDown(e, 15)
//                                handleOpenModalBack(e, index, "Scodess");
//                             }}
//                   />
//                           {/* <input
//                             className="SaleACC"
//                             readOnly={!isEditMode || isDisabled}
//                             id="Scodess"
//                             value={item.Scodess}
//                             ref={(el) => (inputRefs.current[15] = el)} // Assign ref
//                             onKeyDown={(e) => {
//                               handleOpenModal(e, index, "Scodess");
//                                handleKeyDown(e, 15)
//                             }}
//                           /> */}
//                         </div>
//                       </div>
//                     ))}
//                     {showModalCus && (
//                       <ProductModalCustomer
//                         allFields={allFieldsCus}
//                         products={productsCus}
//                         onSelect={handleProductSelectCus}
//                         onClose={() => setShowModalCus(false)}
//                         initialKey={pressedKey} // Pass the pressed key to the modal
//                       />
//                     )}
//                   </div>
//                   <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
//                     <text>Size:</text>
//                     <input
//                       className="SIZE"
//                       readOnly={!isEditMode || isDisabled}
//                       size="small"
//                       label="Pack"
//                       name="Pack"
//                       value={formData.Pack}
//                       onChange={handleChange}
//                       ref={(el) => (inputRefs.current[16] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 16)} // Handle Enter key
//                       maxLength={12}
//                     />
//                   </div>
//                   <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
//                     <text>HSNCode:</text>
//                     <input
//                       className="HSNCode"
//                       readOnly={!isEditMode || isDisabled}
//                       size="small"
//                       label="Hsn"
//                       id="Hsn"
//                       value={formData.Hsn}
//                       onChange={handleNumericValue}
//                       ref={(el) => (inputRefs.current[17] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 17)} // Handle Enter key
//                       maxLength={8}
//                     />
//                   </div>
//                 </div>
//               </div>
//               {/* Second Half Screen */}
//               <div className="SecondHalf">   
//                     <div
//                       style={{
//                         display: "flex",
//                         flexDirection: "row",
//                         marginTop: 1,
//                       }}
//                     >
//                       <text style={{ marginTop: 5 }}>Scheme@:</text>
//                       <input
//                         className="Scheme"
//                         readOnly={!isEditMode || isDisabled}
//                         size="small"
//                         label="schemes"
//                         name="schemes"
//                         value={formData.schemes}
//                         onChange={handleNumberChange}
//                         ref={(el) => (inputRefs.current[18] = el)} // Assign ref
//                         onKeyDown={(e) => handleKeyDown(e, 18)} // Handle Enter key
//                         maxLength={4}
//                         onBlur={() => handleRateBlur("schemes")}
//                       />
//                       <input
//                         value={"ExpireDate"}
//                         style={{
//                           width: 78,
//                           textAlign: "center",
//                           marginLeft: 2,
//                           backgroundColor: "skyblue",
//                           color:"black"
//                         }}
//                         disabled
//                       />
//                      <DatePicker
//                     id="duedate"
//                     value={formData.duedate}
//                     className="duedatepicker"
//                     selected={expiredDate}
//                     onChange={handleDateChange}
//                     readOnly={!isEditMode || isDisabled}
//                     placeholderText="DueDate"
//                     dateFormat="dd/MM/yyyy" 
//                   />
//                     </div>
//                     <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
//                       <text>Rate Calculate:</text>
//                       <select
//                         className="SelectField"
//                         readOnly={!isEditMode || isDisabled}
//                         name="Rateins"
//                         style={{
//                           color: "black",
//                           width: "70%",
//                           marginLeft:13
//                         }}
//                         value={formData.Rateins}
//                         onChange={handleratecal}
//                         displayEmpty
//                         inputProps={{ "aria-label": "Without label" }}
//                         ref={(el) => (inputRefs.current[19] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 19)} // Handle Enter key
//                       >
//                         <option value=""></option>
//                         <option value="Default">Default</option>
//                         <option value="Wt/Qty">Wt/Qty</option>
//                         <option value="Pc/Pkgs">Pc/Pkgs</option>
//                         <option value="Specific">Specific</option>
//                       </select>
//                     </div>
//                     <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
//                       <text>Cls Stock in:</text>
//                       <select
//                         className="SelectField"
//                         readOnly={!isEditMode || isDisabled}
//                         name="Stockins"
//                         style={{
//                           width: "70%",
//                           color: "black",
//                           marginLeft:35
//                         }}
//                         value={formData.Stockins}
//                         onChange={hanldeclsStock}
//                         displayEmpty
//                         inputProps={{ "aria-label": "Without label" }}
//                          ref={(el) => (inputRefs.current[20] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 20)} // Handle Enter key
//                       >
//                         <option value=""></option>
//                         <option value={"Wt/Qty"}>Wt/Qty</option>
//                         <option value={"Pieces/Case"}>Pieces/Case</option>
//                         <option value={"Default"}>Default</option>
//                       </select>
//                     </div>
//                     <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
//                       <text>Qty in Units:</text>
//                       <select
//                         className="SelectField"
//                         readOnly={!isEditMode || isDisabled}
//                         name="Units"
//                         style={{
//                           width: "70%",
//                           color: "black",
//                           marginLeft:32
//                         }}
//                         value={formData.Units}
//                         onChange={handleqtyunit}
//                         displayEmpty
//                         inputProps={{ "aria-label": "Without label" }}
//                          ref={(el) => (inputRefs.current[21] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 21)} // Handle Enter key
//                       >
//                         <option value=""></option>
//                         <option value="M.Tons">M.Tons</option>
//                         <option value="Qtls">Qtls</option>
//                         <option value="Kg.">Kg.</option>
//                         <option value="Ltrs">Ltrs</option>
//                         <option value="Case">Case</option>
//                         <option value="Box">Box</option>
//                         <option value="Packets">Packets</option>
//                         <option value="Pcs">Pcs</option>
//                         <option value="Pair">Pair</option>
//                         <option value="Dozen">Dozen</option>
//                         <option value="Lari">Lari</option>
//                       </select>
//                     </div>
//                     <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
//                       <text>Portal UOM:</text>
//                       <select
//                         className="SelectField"
//                         readOnly={!isEditMode || isDisabled}
//                         name="TradeName"
//                         style={{
//                           width: "70%",
//                           color: "black",
//                           marginLeft:34
//                         }}
//                         value={formData.TradeName}
//                         onChange={handleportal}
//                         displayEmpty
//                         inputProps={{ "aria-label": "Without label" }}
//                          ref={(el) => (inputRefs.current[22] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 22)} // Handle Enter key
//                       >
//                         <option value=""></option>
//                         <option value="TUB-TUBES">TUB-TUBES</option>
//                         <option value="UGS-US GALLONS">UGS-US GALLONS</option>
//                         <option value="UNT-UNITS">UNT-UNITS</option>
//                         <option value="YDS-YARDS">YDS-YARDS</option>
//                         <option value="OTH-OTHERS">OTH-OTHERS</option>
//                         <option value="LTR-LITRES">LTR-LITRES</option>
//                         <option value="TON-TONNES">TON-TONNES</option>
//                         <option value="THD-THOUSAND">THD-THOUSAND</option>
//                         <option value="TGM-TEN GROSS">TGM-TEN GROSS</option>
//                         <option value="TBS-TABLETS">TBS-TABLETS</option>
//                         <option value="SQY-SQUARE YARDS">
//                           SQY-SQUARE YARDS
//                         </option>
//                         <option value="SQM-SQUARE METERS">
//                           SQM-SQUARE METERS
//                         </option>
//                         <option value="SQF-SQUARE-FEET">SQF-SQUARE-FEET</option>
//                         <option value="SET-SETS">SET-SETS</option>
//                         <option value="ROL-ROLLS">ROL-ROLLS</option>
//                         <option value="QTL-QUINTAL">QTL-QUINTAL</option>
//                         <option value="PRS-PAIRS">PRS-PAIRS</option>
//                         <option value="PCS-PIECES">PCS-PIECES</option>
//                         <option value="PAC-PACKS">PAC-PACKS</option>
//                         <option value="NOS-NUMBERS">NOS-NUMBERS</option>
//                         <option value="MTS-METRIC TON">MTS-METRIC TON</option>
//                         <option value="MTR-METERS">MTR-METERS</option>
//                         <option value="MLT-MILILITRE">MLT-MILILITRE</option>
//                         <option value="KME-KILOMETRE">KME-KILOMETRE</option>
//                         <option value="KLR-KILOLITRE">KLR-KILOLITRE</option>
//                         <option value="KGS-KILOGRAMS">KGS-KILOGRAMS</option>
//                         <option value="GYD-GROSS YARDS">GYD-GROSS YARDS</option>
//                         <option value="GRS-GROSS">GRS-GROSS</option>
//                         <option value="GMS-GRAMMES">GMS-GRAMMES</option>
//                         <option value="GGK-GREAT GROSS">GGK-GREAT GROSS</option>
//                         <option value="DRM-DRUMS">DRM-DRUMS</option>
//                         <option value="DOZ-DOZENS">DOZ-DOZENS</option>
//                         <option value="CTN-CARTONS">CTN-CARTONS</option>
//                         <option value="CMS-CENTIMETERS">CMS-CENTIMETERS</option>
//                         <option value="CCM-CUBIC CENTIMETERS">
//                           CCM-CUBIC CENTIMETERS
//                         </option>
//                         <option value="CBM-CUBIC METERS">
//                           CBM-CUBIC METERS
//                         </option>
//                         <option value="CAN-CANS">CAN-CANS</option>
//                         <option value="BUN-BUNCHES">BUN-BUNCHES</option>
//                         <option value="BTL-BOTTLES">BTL-BOTTLES</option>
//                         <option value="BOX-BOX">BOX-BOX</option>
//                         <option value="BAG-BAGS">BAG-BAGS</option>
//                         <option value="BAL-BALE">BAL-BALE</option>
//                         <option value="BDL-BUNDLES">BDL-BUNDLES</option>
//                         <option value="BKL-BUCKLES">BKL-BUCKLES</option>
//                         <option value="BOU-BILLION OF UNITS">
//                           BOU-BILLION OF UNITS
//                         </option>
//                       </select>
//                     </div>
//                     <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
//                       <text>Stock Calculate:</text>
//                       <select
//                         className="SelectField"
//                         readOnly={!isEditMode || isDisabled}
//                         name="Stkcals"
//                         style={{
//                           width: "70%",
//                           color: "black",
//                           marginLeft:9
//                         }}
//                         value={formData.Stkcals}
//                         onChange={handlestockCal}
//                         displayEmpty
//                         inputProps={{ "aria-label": "Without label" }}
//                          ref={(el) => (inputRefs.current[23] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 23)} // Handle Enter key
//                       >
//                         <option value=""></option>
//                         <option value={"Wt/Qty"}>Wt/Qty</option>
//                         <option value={"Pc/Packet"}>Pc/Packet</option>
//                         <option value={"Default"}>Default</option>
//                         <option value={"Wt/Qty Fix"}>Wt/Qty Fix</option>
//                         <option value={"Pc/Packet Fix"}>Pc/Packet Fix</option>
//                       </select>
//                     </div>
//                     <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
//                       <text>Types of Goods:</text>
//                       <select
//                         className="SelectField"
//                         readOnly={!isEditMode || isDisabled}
//                         name="Types"
//                         style={{
//                           width: "70%",
//                           color: "black",
//                           marginLeft:8
//                         }}
//                         value={formData.Types}
//                         onChange={handleGoods}
//                         displayEmpty
//                         inputProps={{ "aria-label": "Without label" }}
//                         ref={(el) => (inputRefs.current[24] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 24)} // Handle Enter key
//                       >
//                         <option value=""></option>
//                         <option value={"Raw Material"}>Raw Material</option>
//                         <option value={"Finished Product"}>
//                           Finished Product
//                         </option>
//                         <option value={"Semi-Finished Product"}>
//                           Semi-Finished Product
//                         </option>
//                         <option value={"Bye Product"}>Bye Product</option>
//                         <option value={"Wastage"}>Wastage</option>
//                         <option value={"Consumable"}>Consumable</option>
//                         <option value={"Other Goods"}>Other Goods</option>
//                       </select>
//                     </div>
//                     <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
//                       <text>Stk Valuation:</text>
//                       <select
//                         className="SelectField"
//                         readOnly={!isEditMode || isDisabled}
//                         name="Stkvals"
//                         style={{
//                           width: "70%",
//                           color: "black",
//                           marginLeft:24
//                         }}
//                         value={formData.Stkvals}
//                         onChange={handlestkValuation}
//                         displayEmpty
//                         inputProps={{ "aria-label": "Without label" }}
//                          ref={(el) => (inputRefs.current[25] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 25)} // Handle Enter key
//                       >
//                         <option value=""></option>
//                         <option value={"Purchase Rate"}>Purchase Rate</option>
//                         <option value={"Sale Rate"}>Sale Rate</option>
//                         <option value={"None"}>None</option>
//                       </select>
//                     </div>
//                     <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
//                       <text style={{ marginTop: 5 }}>Qty Per Pc/Case:</text>
//                       <input
//                         className="QtyPerCase"
//                         readOnly={!isEditMode || isDisabled}
//                         size="small"
//                         label="Qpps"
//                         name="Qpps"
//                         value={formData.Qpps}
//                         onChange={handleNumberChange}
//                         ref={(el) => (inputRefs.current[26] = el)} // Assign ref
//                         onKeyDown={(e) => handleKeyDown(e, 26)} // Handle Enter key
//                         maxLength={8}
//                         onBlur={() => handleRateBlur("Qpps")}
//                       />
//                       <input
//                         value={"Tariff"}
//                         style={{
//                           width: 60,
//                           textAlign: "center",
//                           marginLeft: 2,
//                           backgroundColor: "skyblue",
//                           color:'black'
//                         }}
//                         disabled
//                       />
//                       <input
//                         className="tariff"
//                         readOnly={!isEditMode || isDisabled}
//                         size="small"
//                         label="tariff"
//                         name="tariff"
//                         value={formData.tariff}
//                         onChange={handleNumberChange}
//                         ref={(el) => (inputRefs.current[27] = el)} // Assign ref
//                         onKeyDown={(e) => handleKeyDown(e, 27)} // Handle Enter key
//                         maxLength={8}
//                         onBlur={() => handleRateBlur("tariff")}
//                       />{" "}
//                     </div>
//                     <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
//                       <text>Min.Stock Level:</text>
//                       <input
//                         className="MinSTK"
//                         readOnly={!isEditMode || isDisabled}
//                         size="small"
//                         label="Inval"
//                         name="Inval"
//                         value={formData.Inval}
//                         onChange={handleNumberChange}
//                         ref={(el) => (inputRefs.current[28] = el)} // Assign ref
//                         onKeyDown={(e) => handleKeyDown(e, 28)} // Handle Enter key
//                         maxLength={8}
//                         onBlur={() => handleRateBlur("Inval")}
//                       />
//                       <input
//                         className="Rg23c"
//                         readOnly={!isEditMode || isDisabled}
//                         size="small"
//                         fullWidth
//                         label="Rg23c"
//                         name="Rg23c"
//                         value={formData.Rg23c}
//                         onChange={handleNumberChange}
//                         ref={(el) => (inputRefs.current[29] = el)} // Assign ref
//                         onKeyDown={(e) => handleKeyDown(e, 29)} // Handle Enter key
//                         maxLength={8}
//                         onBlur={() => handleRateBlur("Rg23c")}
//                       />
//                     </div>
//                     <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
//                       <text>206C(1H)/194Q</text>
//                       <select
//                         className="SelectField"
//                         readOnly={!isEditMode || isDisabled}
//                         name="Tcs206"
//                         style={{
//                           width: "70%",
//                           color: "black",
//                           marginLeft:10
//                         }}
//                         value={formData.Tcs206}
//                         onChange={handleselection}
//                         displayEmpty
//                         inputProps={{ "aria-label": "Without label" }}
//                          ref={(el) => (inputRefs.current[30] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 30)} // Handle Enter key
//                       >
//                         <option value=""></option>
//                         <option value={"Yes"}>Yes</option>
//                         <option value={"No"}>NO</option>
//                         <option value={"NA"}>NA</option>
//                       </select>
//                     </div>
//                     <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
//                       <text>GST Type:</text>
//                       <select
//                         className="SelectField"
//                         readOnly={!isEditMode || isDisabled}
//                         name="Stype"
//                         style={{
//                           width: "70%",
//                           color: "black",
//                           marginLeft:53
//                         }}
//                         value={formData.Stype}
//                         onChange={handlegsttype}
//                         displayEmpty
//                         inputProps={{ "aria-label": "Without label" }}
//                          ref={(el) => (inputRefs.current[31] = el)} // Assign ref
//                       onKeyDown={(e) => handleKeyDown(e, 31)} // Handle Enter key
//                       >
//                         <option value=""></option>
//                         <option value={"Taxable"}>Taxable</option>
//                         <option value={"Free Tax"}>Free Tax</option>
//                         <option value={"Non GST"}>Non GST</option>
//                         <option value={"Services"}>Services</option>
//                         <option value={"Exempted"}>Exempted</option>
//                         <option value={"X-Not Sale"}>X-Not Sale</option>
//                       </select>
//                     </div>
//                 {/* Section 3 */}
//               </div>
//               <div className="ThirdHalf">
//                 <div style={{display:'flex',flexDirection:'row'}}>
//                 <input
//                 disabled={!isEditMode || isDisabled}
//                 style={{marginLeft:"2x0%"}}
//                 type="checkbox"
//                 name="T1"
//                 checked={formData.T1}
//                 onChange={handleChangeCheckBox}
//                 className="custom-checkbox"
//                 />
//                 <text style={{marginLeft:"2%"}}>Add to Production Card</text>
//                 </div>
//                 {formData.T1 && (
//                 <>
//                 <div style={{display:'flex',flexDirection:'row',marginTop:10}}>
//                 <text>Production Sr.No</text>
//                 <input
//                 readOnly={!isEditMode || isDisabled}
//                 className="Psrno"
//                 id="Psrno"
//                 value={formData.Psrno}
//                 onChange={handleNumericValue}
//                 />
//                 </div>
//                 <div style={{display:'flex',flexDirection:'row',marginTop:5}}>
//                 <text>Unit.No</text>
//                 <input
//                 readOnly={!isEditMode || isDisabled}
//                 className="PUnitno"
//                 id="PUnitno"
//                 value={formData.PUnitno}
//                 onChange={handleNumericValue}
//                 />
//                 </div>
//                 <div style={{display:'flex',flexDirection:'row',marginTop:5}}>
//                 <text>Percentage</text>
//                 <input
//                 readOnly={!isEditMode || isDisabled}
//                 className="percentage"
//                 id="percentage"
//                 value={formData.percentage}
//                 onChange={handleNumericValue}
//                 onBlur={() => handleRateBlur("percentage")}
//                 />
//                 </div>
//                 </>
//                 )}
//               </div>
//             </div>
//         <div
//           className="Buttonsgroupz"
//         >
//           <Button
//             className="Buttonz"
//             style={{ color: "black", backgroundColor: buttonColors[0] }}
//             onClick={handleAdd}
//             disabled={!isAddEnabled}
//           >
//             Add
//           </Button>
//           <Button
//             disabled={!isAddEnabled}
//             className="Buttonz"
//             style={{ color: "black", backgroundColor: buttonColors[1] }}
//             onClick={handleEditClick}
//           >
//             Edit
//           </Button>
//           <Button
//             className="Buttonz"
//             style={{ color: "black", backgroundColor: buttonColors[2] }}
//             onClick={handlePrevious}
//             disabled={index === 0}
//           >
//             Previous
//           </Button>
//           <Button
//             className="Buttonz"
//             style={{ color: "black", backgroundColor: buttonColors[3] }}
//             onClick={handleNext}
//             disabled={index === data.length - 1}
//           >
//             Next
//           </Button>
//           <Button
//             className="Buttonz"
//             style={{ color: "black", backgroundColor: buttonColors[4] }}
//             onClick={handleFirst}
//             disabled={index === 0}
//           >
//             First
//           </Button>
//           <Button
//             className="Buttonz"
//             style={{ color: "black", backgroundColor: buttonColors[5] }}
//             onClick={handleLast}
//             disabled={index === data.length - 1}
//           >
//             Last
//           </Button>
//           <Button
//             className="Buttonz"
//             style={{ color: "black", backgroundColor: buttonColors[6] }}
//             onClick={handleOpen}
//           >
//             Search
//           </Button>
//             <Modal open={openSearch} onClose={handleCloseSearch}>
//             <Box
//               sx={{
//                 position: "absolute",
//                 top: "50%",
//                 left: "50%",
//                 transform: "translate(-50%, -50%)",
//                 width: 400,
//                 bgcolor: "background.paper",
//                 boxShadow: 24,
//                 p: 4,
//                 borderRadius: 2,
//               }}
//             >
//               <Typography variant="h6" mb={2}>
//                 Select Ledger Account
//               </Typography>
//               <Autocomplete
//                 fullWidth
//                 options={data2}
//                 getOptionLabel={(option) =>option?.formData?.Aheads || ""} // Display Name
//                 value={selectedOption}
//                 onChange={handleSelect} // Handle selection
//                 renderInput={(params) => (
//                   <TextField
//                     {...params}
//                     variant="outlined"
//                     label="Search and Select"
//                     inputRef={autoCompleteRef} // Set focus on open
//                   />
//                 )}
//               />
//             </Box>
//            </Modal>
//           <Button
//             className="Buttonz"
//             style={{ color: "black", backgroundColor: buttonColors[7] }}
//           >
//             Print
//           </Button>
//           <Button
//             className="Buttonz"
//             style={{ color: "black", backgroundColor: buttonColors[8] }}
//             onClick={handleDeleteClick}
//           >
//             Delete
//           </Button>
//           <Button
//             className="Buttonz"
//             style={{ color: "black", backgroundColor: buttonColors[9] }}
//             onClick={handleExit}
//           >
//             Exit
//           </Button>
//           <div>
//             <Button
//               ref={(el) => (inputRefs.current[32] = el)} // Assign ref
//               onKeyDown={(e) => handleKeyDown(e, 32)} // Handle Enter key
//               className="Buttonz"
//               onClick={handleSaveClick}
//               disabled={!isSubmitEnabled}
//               style={{ color: "black", backgroundColor: buttonColors[10] }}
//               // onClick={handleSubmit} disabled={!isSubmitEnabled}
//             >
//               Save
//             </Button>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default NewStockAcc;


import React, { useState, useEffect,useRef} from "react";
import {
  Container,
} from "@mui/material";
import Button from "react-bootstrap/Button";
import { ButtonGroup } from "@mui/material";
import $ from "jquery";
import "./NewStockAcc.css";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import axios from "axios";
import ProductModalAccount from "../Modals/ProductModalAccount";
import ProductModalCustomer from "../Modals/ProductModalCustomer";
import { useEditMode } from "../../EditModeContext";
import { Modal, Box, Autocomplete, TextField,  Typography } from "@mui/material";
import { CompanyContext } from '../Context/CompanyContext';
import { useContext } from "react";

const NewStockAcc = ({ onSaveSuccess, onEscClose }) => {
  
  const { company } = useContext(CompanyContext);
    const tenant = company?.databaseName;
  
    if (!tenant) {
      // you may want to guard here or show an error state,
      // since without a tenant you can’t hit the right API
      console.error("No tenant selected!");
    }

   const inputRefs = useRef([]); // Array to hold references for input fields
   useEffect(() => {
    const handleEsc = (e) => {
      if (e.key === "Escape") {
        if (typeof onEscClose === "function") {
          onEscClose();
        }
      }
    };
  
    document.addEventListener("keydown", handleEsc);
    return () => document.removeEventListener("keydown", handleEsc);
  }, [onEscClose]);
  
  const [formData, setFormData] = useState({
    Acodes: "",
    Aheads: "",
    openwts: "",
    openpcs: "",
    Mmopbals: "",
    Add2s: "",
    Prate: "",
    Mrps: "",
    Cds: "",
    Srate: "",
    itax_rate: "",
    ctax_rate: "",
    Drate: "",
    Stax_rate: "",
    Cess_rate: "",
    Pack: "",
    Hsn: "",
    Joint: "",
    schemes: "",
    duedate: "",
    Rateins: "",
    Stockins: "",
    Units: "",
    TradeName: "",
    Stkcals: "",
    Types: "",
    Stkvals: "",
    Qpps: "",
    tariff: "",
    Inval: "",
    Rg23c: "",
    Tcs206: "",
    Stype: "",
    T1: false,
    Psrno:"",
    PUnitno:"",
    percentage:"",
  });
  const [PurchaseAcc, setPurchaseAcc] = useState([
    {
      Pcodess: "",
      acCode: "",
    },
  ]);
  const [SaleAcc, setSaleAcc] = useState([
    {
      Scodess: "",
      AcCode: "",
    },
  ]);

   // Search options
   const [openSearch, setOpenSearch] = useState(false); // Modal Visibility
   const [selectedOption, setSelectedOption] = useState(null); // Selected Item
   const autoCompleteRef = useRef(null); // Reference for AutoComplete Input
  
   // Fetch data from API when component mounts
   useEffect(() => {
     axios
       .get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/stockmaster`)
       .then((response) => setData2(response.data))
       .catch((error) => console.error("Error fetching data:", error));
   }, []);
  
   // Open Modal and Set Focus to Autocomplete
   const handleOpen = () => {
     setOpenSearch(true);
     setTimeout(() => {
       if (autoCompleteRef.current) {
         autoCompleteRef.current.focus(); // Focus Autocomplete
       }
     }, 100); // Delay to ensure modal opens first
   };
  
   // Close Modal & Clear Selection
   const handleCloseSearch = () => {
     setSelectedOption(null); // Reset selection
     setOpenSearch(false);
   };
  
   // Handle ComboBox Selection & Close Modal on Enter
   const handleSelect = (event, newValue) => {
     if (newValue) {
       setFormData(newValue.formData); // Set Selected Data
       handleCloseSearch(); // Close Modal
     }
   };

  // Modal For Customer
  React.useEffect(() => {
    // Fetch products from the API when the component mounts
    fetchCustomers();
  }, []);

 const fetchCustomers = async () => {
    try {
      const response = await fetch(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/ledgerAccount`);
      if (!response.ok) {
        throw new Error("Failed to fetch products");
      }
      const data = await response.json();
      // Ensure to extract the formData for easier access in the rest of your app
      const formattedData = data.map(item => ({ ...item.formData, _id: item._id }));
      setProductsCus(formattedData);
      setLoadingCus(false);
    } catch (error) {
      setErrorCus(error.message);
      setLoadingCus(false);
    }
  };
  const [productsCus, setProductsCus] = useState([]);
  const [showModalCus, setShowModalCus] = useState(false);
  const [selectedItemIndexCus, setSelectedItemIndexCus] = useState(null);
  const [loadingCus, setLoadingCus] = useState(true);
  const [errorCus, setErrorCus] = useState(null);
  const handleItemChangeCus = (index, key, value) => {
    const updatedItems = [...SaleAcc];
    updatedItems[index][key] = value;
    // If the key is 'name', find the corresponding product and set the price
    if (key === "name") {
      const selectedProduct = productsCus.find(
        (product) => product.ahead === value
      );
      if (selectedProduct) {
        updatedItems[index]["Scodess"] = selectedProduct.ahead;
        updatedItems[index]["AcCode"] = selectedProduct.acode;
      }
    }
    setSaleAcc(updatedItems);
  };

  const handleProductSelectCus = (product) => {
    if (selectedItemIndexCus !== null) {
      handleItemChangeCus(selectedItemIndexCus, "name", product.ahead);
      setShowModalCus(false);

      // Focus back on the input field after selecting the value
      setTimeout(() => {
        inputRefs.current[15]?.focus();
      }, 0);
    }
  };
 
  const openModalForItemCus = (index) => {
    setSelectedItemIndexCus(index);
    setShowModalCus(true);
  };

  const allFieldsCus = productsCus.reduce((fields, product) => {
    Object.keys(product).forEach((key) => {
      if (!fields.includes(key)) {
        fields.push(key);
      }
    });

    return fields;
  }, []);

  // Fetching Account Name
  React.useEffect(() => {
    // Fetch products from the API when the component mounts
    fetchAccountName();
  }, []);

  const fetchAccountName = async () => {
    try {
      const response = await fetch(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/ledgerAccount`);
      if (!response.ok) {
        throw new Error("Failed to fetch products");
      }
      const data = await response.json();
      // Ensure to extract the formData for easier access in the rest of your app
      const formattedData = data.map(item => ({ ...item.formData, _id: item._id }));
      setProductsAcc(formattedData);
      setLoadingAcc(false);
    } catch (error) {
      setErrorAcc(error.message);
      setLoadingAcc(false);
    }
  };

  // Modal For Purchase Account
  const [productsAcc, setProductsAcc] = useState([]);
  const [showModalAcc, setShowModalAcc] = useState(false);
  const [selectedItemIndexAcc, setSelectedItemIndexAcc] = useState(null);
  const [loadingAcc, setLoadingAcc] = useState(true);
  const [errorAcc, setErrorAcc] = useState(null);
  const [pressedKey, setPressedKey] = useState(""); // State to hold the pressed key
  const handleItemChangeAcc = (index, key, value) => {
    const updatedItems = [...PurchaseAcc];
    updatedItems[index][key] = value;
    // If the key is 'name', find the corresponding product and set the price
    if (key === "acName") {
      const selectedProduct = productsAcc.find(
        (product) => product.ahead === value
      );
      if (selectedProduct) {
        updatedItems[index]["Pcodess"] = selectedProduct.ahead;
        updatedItems[index]["acCode"] = selectedProduct.acode;
      }
    }
    setPurchaseAcc(updatedItems);
  };

  const handleProductSelectAcc = (product) => {
    if (selectedItemIndexAcc !== null) {
      handleItemChangeAcc(selectedItemIndexAcc, "acName", product.ahead);
      setShowModalAcc(false);

      // Focus back on the input field after selecting the value
      setTimeout(() => {
        inputRefs.current[14]?.focus();
      }, 0);
    }
  };
  const openModalForItemAcc = (index) => {
    setSelectedItemIndexAcc(index);
    setShowModalAcc(true);
  };
  const allFieldsAcc = productsAcc.reduce((fields, product) => {
    Object.keys(product).forEach((key) => {
      if (!fields.includes(key)) {
        fields.push(key);
      }
    });

    return fields;
  }, []);

  const handleOpenModal = (event, index, field) => {
    if (/^[a-zA-Z]$/.test(event.key) && field === "Pcodess" && isEditMode) {
      setPressedKey(event.key); // Set the pressed key
      openModalForItemAcc(index);
      event.preventDefault(); // Prevent any default action
    }
    if (/^[a-zA-Z]$/.test(event.key) && field === "Scodess"&& isEditMode) {
      setPressedKey(event.key); // Set the pressed key
      openModalForItemCus(index);
      event.preventDefault(); // Prevent any default action
    }
  };
  const handleOpenModalBack = (event, index, field) => {
    if (event.key === "Backspace" && field === "Pcodess") {
        setSelectedItemIndexAcc(index);
        setShowModalAcc(true);
        event.preventDefault();
    }
    if (event.key === "Backspace" && field === "Scodess") {
      setSelectedItemIndexCus(index);
      setShowModalCus(true);
      event.preventDefault();
  }
};
   // Api Response
    const [data, setData] = useState([]);
    const [data1, setData1] = useState([]);
    const [data2, setData2] = useState([]);
    const [index, setIndex] = useState(0);
    const [isAddEnabled, setIsAddEnabled] = useState(true);
    const [isSubmitEnabled, setIsSubmitEnabled] = useState(false);
    const { isEditMode, setIsEditMode } = useEditMode(); // Access the context
    const [isAbcmode, setIsAbcmode] = useState(false);
    const [isDisabled, setIsDisabled] = useState(false); // State to track field disablement

    const fetchData = async () => {
      try {
        const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/stockmaster/last`);
        if (response.status === 200 && response.data.data) {
          const lastEntry = response.data.data;
          console.log("LASTENTRY:",lastEntry);
          
          setFormData(lastEntry.formData);
          setData1(lastEntry); // Assuming this is meant to hold the full data structure
          setIndex(lastEntry._id);
          // Convert cesscode into an array containing one object
          setPurchaseAcc([{ Pcodess: lastEntry.formData.Pcodess, acCode: lastEntry.formData.acCode }]);
          setSaleAcc([{ Scodess: lastEntry.formData.Scodess, AcCode: lastEntry.formData.AcCode }]);
        } else {
          setDefaults(); // If no data, reset everything
        }
      } catch (error) {
        console.error("Error fetching data", error);
        setDefaults(); // Reset in case of error
      }
    };
    
    const setDefaults = () => {
      // Define default empty states here to avoid redundancy and mistakes
      const emptyData = {
        Acodes: "",
        Aheads: "",
        openwts: "",
        openpcs: "",
        Mmopbals: "",
        Add2s: "",
        Prate: "",
        Mrps: "",
        Cds: "",
        Srate: "",
        itax_rate: "",
        ctax_rate: "",
        Drate: "",
        Stax_rate: "",
        Cess_rate: "",
        Pack: "",
        Hsn: "",
        Joint: "",
        schemes: "",
        duedate: "",
        Rateins: "",
        Stockins: "",
        Units: "",
        TradeName: "",
        Stkcals: "",
        Types: "",
        Stkvals: "",
        Qpps: "",
        tariff: "",
        Inval: "",
        Rg23c: "",
        Tcs206: "",
        Stype: "",
        T1: false,
        Psrno:"",
        PUnitno:"",
        percentage:"",
      };
      const emptyPurchaseACC = [{ cesscode: "", cessAc: "" }];
      const emptySaleAcc= [{ cgst_code: "", cgst_ac: "" }];
      setFormData(emptyData);
      setPurchaseAcc(emptyPurchaseACC);
      setSaleAcc(emptySaleAcc);
      setData1({ formData: emptyData, PurchaseAcc: emptyPurchaseACC, SaleAcc: emptySaleAcc});
      setIndex(0);
    };

   useEffect(() => {
       fetchData(); // Fetch data when component mounts
       setIsDisabled(true); // Add this line to set isDisabled to true initially
   }, []); // Empty dependency array ensures it only runs once when component mounts

  const handleNext = async () => {
    document.body.style.backgroundColor = 'white';
    console.log(data1._id)
    try {
        if (data1) {
          const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/stockmaster/next/${data1._id}`);
            if (response.status === 200 && response.data) {
                const nextData = response.data.data;
                setData1(response.data.data);
                setIndex(index + 1);
                setFormData(nextData.formData);
                setIsDisabled(true);
            }
        }
    } catch (error) {
        console.error("Error fetching next record:", error);
    }
};

const handlePrevious = async () => {
    document.body.style.backgroundColor = 'white';
    try {
        if (data1) {
          const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/stockmaster/previous/${data1._id}`);
            if (response.status === 200 && response.data) {
                console.log(response);
                setData1(response.data.data);
                const prevData = response.data.data;
                setIndex(index - 1);
                setFormData(prevData.formData);
                setIsDisabled(true);
            }
        }
    } catch (error) {
        console.error("Error fetching previous record:", error);
    }
};

const handleFirst = async () => {
    document.body.style.backgroundColor = 'white';
    try {
        const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/stockmaster/first`);
        if (response.status === 200 && response.data) {
            const firstData = response.data.data;
            setIndex(0);
            setFormData(firstData.formData);
            setData1(response.data.data);
            setIsDisabled(true);
        }
    } catch (error) {
        console.error("Error fetching first record:", error);
    }
};

const handleLast = async () => {
    document.body.style.backgroundColor = 'white';
    try {
        const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/stockmaster/last`);
        if (response.status === 200 && response.data) {
            const lastData = response.data.data;
            const lastIndex = response.data.length - 1;
            setIndex(lastIndex);
            setFormData(lastData.formData);
            setData1(response.data.data);
            setIsDisabled(true);
        }
    } catch (error) {
        console.error("Error fetching last record:", error);
    }
};

const handleAdd = async () => {
    // document.body.style.backgroundColor = '#D5ECF3';
    try {
        await fetchData(); // This should set up the state correctly whether data is found or not
        let lastvoucherno = formData.Acodes ? parseInt(formData.Acodes) + 1 : 1;
        const newData = {
          Acodes: lastvoucherno, // Continue from the last voucher number or start new
          Aheads: "",
          openwts: "",
          openpcs: "",
          Mmopbals: "",
          Add2s: "",
          Prate: "",
          Mrps: "",
          Cds: "",
          Srate: "",
          itax_rate: "",
          ctax_rate: "",
          Drate: "",
          Stax_rate: "",
          Cess_rate: "",
          Pack: "",
          Hsn: "",
          Joint: "",
          schemes: "",
          duedate: "",
          Rateins: "",
          Stockins: "",
          Units: "",
          TradeName: "",
          Stkcals: "",
          Types: "",
          Stkvals: "",
          Qpps: "",
          tariff: "",
          Inval: "",
          Rg23c: "",
          Tcs206: "",
          Stype: "",
          T1: false,
          Psrno:"",
          PUnitno:"",
          percentage:"",
        };
        setData([...data, newData]);
        setFormData(newData);
        setPurchaseAcc([{ Pcodess: "", acCode: "" }]);
        setSaleAcc([{ Scodess: "", AcCode: "" }]);
        setIndex(data.length);
        setIsAddEnabled(false);
        setIsSubmitEnabled(true);
        setIsDisabled(false);
        setIsEditMode(true);
        if (inputRefs.current[0]) {
          inputRefs.current[0].focus();
        }
    } catch (error) {
        console.error("Error adding new entry:", error);
    }
  };
  
const handleExit = async () => {
  document.body.style.backgroundColor = 'white'; // Reset background color
  setIsAddEnabled(true); // Enable "Add" button
  setIsSubmitEnabled(false);
  try {
      const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/stockmaster/last`); // Fetch the latest data
      if (response.status === 200 && response.data.data) {
          // If data is available
          const lastEntry = response.data.data;
          const lastIndex = response.data.length - 1;
          setFormData(lastEntry.formData); // Set form data
          setData1(response.data.data);
          setIndex(lastIndex)
          const updatedPurAcc = lastEntry.PurchaseAcc.map(item => ({
            ...item, 
        }));
        const updatedSaleAcc = lastEntry.SaleAcc.map(item => ({
          ...item, 
      }));
        setPurchaseAcc(updatedPurAcc);
        setSaleAcc(updatedSaleAcc);
        setIsDisabled(true); // Disable fields after loading the data
      } else {
          // If no data is available, initialize with default values
          console.log("No data available");
          const newData = {
            Acodes: "",
            Aheads: "",
            openwts: "",
            openpcs: "",
            Mmopbals: "",
            Add2s: "",
            Prate: "",
            Mrps: "",
            Cds: "",
            Srate: "",
            itax_rate: "",
            ctax_rate: "",
            Drate: "",
            Stax_rate: "",
            Cess_rate: "",
            Pack: "",
            Hsn: "",
            Joint: "",
            schemes: "",
            duedate: "",
            Rateins: "",
            Stockins: "",
            Units: "",
            TradeName: "",
            Stkcals: "",
            Types: "",
            Stkvals: "",
            Qpps: "",
            tariff: "",
            Inval: "",
            Rg23c: "",
            Tcs206: "",
            Stype: "",
            T1: false,
            Psrno:"",
            PUnitno:"",
            percentage:"",
          };
          setFormData(newData); // Set default form data
          setPurchaseAcc([{
            Pcodess: "",
            acCode: "",
          }]);
          setSaleAcc([{
            Scodess: "",
            AcCode: "",
          }]);

          setIsDisabled(true); // Disable fields after loading the default data
      }
  } catch (error) {
      console.error("Error fetching data", error);
  }
};

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleKeyPress = (event, nextInputId) => {
    if (event.key === "Enter") {
      const nextInput = document.getElementById(nextInputId);
      if (nextInput) {
        nextInput.focus();
      }
    }
  };
  let a = "Less%";
  const initialColors = [
    "#E9967A",
    "#F0E68C",
    "#FFDEAD",
    "#ADD8E6",
    "#87CEFA",
    "#FFF0F5",
    "#FFC0CB",
    "#D8BFD8",
    "#DC143C",
    "#DCDCDC",
    "#8FBC8F",
  ];
  const [buttonColors, setButtonColors] = useState(initialColors); // Initial colors

  const handleratecal = (event) => {
    const { value } = event.target; // Get the selected value from the event
    setFormData((prevState) => ({
      ...prevState,
      Rateins: value, // Update the Rateins field in FormData
    }));
  };
  const hanldeclsStock = (event) => {
    const { value } = event.target; // Get the selected value from the event
    setFormData((prevState) => ({
      ...prevState,
      Stockins: value, // Update the Rateins field in FormData
    }));
  };
  const handleqtyunit = (event) => {
    const { value } = event.target; // Get the selected value from the event
    setFormData((prevState) => ({
      ...prevState,
      Units: value, // Update the Rateins field in FormData
    }));
  };
  const handleportal = (event) => {
    const { value } = event.target; // Get the selected value from the event
    setFormData((prevState) => ({
      ...prevState,
      TradeName: value, // Update the Rateins field in FormData
    }));
  };
  const handlestockCal = (event) => {
    const { value } = event.target; // Get the selected value from the event
    setFormData((prevState) => ({
      ...prevState,
      Stkcals: value, // Update the Rateins field in FormData
    }));
  };
  const handleGoods = (event) => {
    const { value } = event.target; // Get the selected value from the event
    setFormData((prevState) => ({
      ...prevState,
      Types: value, // Update the Rateins field in FormData
    }));
  };
  const handlestkValuation = (event) => {
    const { value } = event.target; // Get the selected value from the event
    setFormData((prevState) => ({
      ...prevState,
      Stkvals: value, // Update the Rateins field in FormData
    }));
  };
  const handleselection = (event) => {
    const { value } = event.target; // Get the selected value from the event
    setFormData((prevState) => ({
      ...prevState,
      Tcs206: value, // Update the Rateins field in FormData
    }));
  };
  const handlegsttype = (event) => {
    const { value } = event.target; // Get the selected value from the event
    setFormData((prevState) => ({
      ...prevState,
      Stype: value, // Update the Rateins field in FormData
    }));
  };

 // Handle number input validation
 const handleNumberChange = (event) => {
  const { name, value } = event.target;
  const numberValue = value.replace(/[^0-9.]/g, ""); // Allow only numbers and decimal
  const validNumberValue =
    numberValue.split(".").length > 2
      ? numberValue.replace(/\.{2,}/g, "").replace(/(.*)\./g, "$1.")
      : numberValue;

  setFormData((prevState) => ({
    ...prevState,
    [name]: validNumberValue,
  }));

  // If Mrps or Cds is changed, recalculate Srate
  if (name === "Mrps" || name === "Cds") {
    if (validNumberValue) {
      calculateSrate(name === "Mrps" ? validNumberValue : formData.Mrps, name === "Cds" ? validNumberValue : formData.Cds);
    }
  }
};

// Function to calculate and set Srate
const calculateSrate = (mrps, cds) => {
  const mrpsValue = parseFloat(mrps);
  const cdsValue = parseFloat(cds);

  if (!isNaN(mrpsValue) && !isNaN(cdsValue)) {
    const discount = (cdsValue / 100) * mrpsValue;
    const saleRate = mrpsValue - discount;
    setFormData((prevState) => ({
      ...prevState,
      Srate: saleRate.toFixed(3), // Set the calculated sale rate with 2 decimal places
    }));
  }
};

const handleSrateChange = (event) => {
  const { value } = event.target;
  setFormData((prevState) => ({
    ...prevState,
    Srate: value, // Allow manual entry in the Srate field
  }));
};

const handleSaveClick = async () => {
  document.body.style.backgroundColor = "white";
  let isDataSaved = false; 

  // Check if formData.Aheads is empty
  if (!formData.Aheads || formData.Aheads.trim() === "") {
    toast.error("Name cannot be empty!", { position: "top-center" });
    return; // Prevent the save operation
  }

  const userConfirmed = window.confirm("Are you sure you want to save the data?");
  if (!userConfirmed) return;

  const prepareData = () => ({
    _id: formData._id,
    formData: {
      ...formData,
      Pcodess: PurchaseAcc.length > 0 ? PurchaseAcc[0].Pcodess : "",
      acCode: PurchaseAcc.length > 0 ? PurchaseAcc[0].acCode : "",
      Scodess: SaleAcc.length > 0 ? SaleAcc[0].Scodess : "",
      AcCode: SaleAcc.length > 0 ? SaleAcc[0].AcCode : "",
    },
  });

  try {
    const combinedData = prepareData();
    console.log("Combined Data:", combinedData);
    const apiEndpoint = `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/stockmaster${isAbcmode ? `/${data1._id}` : ""}`;
    const method = isAbcmode ? "put" : "post";
    const response = await axios({ method, url: apiEndpoint, data: combinedData });

    if (response.status === 200 || response.status === 201) {
      // fetchData();
      isDataSaved = true;
    }
  } catch (error) {
    console.error("Error saving data:", error);
    toast.error("Failed to save data. Please try again.", { position: "top-center" });
  } finally {
    setIsSubmitEnabled(false);
    isDataSaved ? setIsAddEnabled(true) : setIsAddEnabled(false);
    setIsDisabled(!isDataSaved);
    setIsEditMode(!isDataSaved);

    const toastMsg = isDataSaved ? "Data Saved Successfully!" : "Failed to save data.";
    if (isDataSaved) {
      toast.success(toastMsg, { position: "top-center" });
    }
  }
};

// const handleSaveClick = async () => {
//     document.body.style.backgroundColor = "white";
//     let isDataSaved = false; 
//     const userConfirmed = window.confirm("Are you sure you want to save the data?");
//     if (!userConfirmed) return;
//     const prepareData = () => ({
//       _id: formData._id,
//       formData: {
//         ...formData,
//         Pcodess: PurchaseAcc.length > 0 ? PurchaseAcc[0].Pcodess : '',
//         acCode: PurchaseAcc.length > 0 ? PurchaseAcc[0].acCode : '',
//         Scodess: SaleAcc.length > 0 ? SaleAcc[0].Scodess : '',
//         AcCode: SaleAcc.length > 0 ? SaleAcc[0].AcCode : '',
//       }
//     });

//     try {
//       const combinedData = prepareData();
//       console.log("Combined Data:", combinedData);
//       const apiEndpoint = `http://103.168.19.65:3012/auth/stockmaster${isAbcmode ? `/${data1._id}` : ""}`;
//       const method = isAbcmode ? "put" : "post";
//       const response = await axios({ method, url: apiEndpoint, data: combinedData });

//       if (response.status === 200 || response.status === 201) {
//         fetchData();
//         isDataSaved = true;
//       }
//     } catch (error) {
//       console.error("Error saving data:", error);
//       toast.error("Failed to save data. Please try again.", { position: "top-center" });
//     } finally {
//       setIsSubmitEnabled(false);
//       isDataSaved ? setIsAddEnabled(true) : setIsAddEnabled(false);
//       setIsDisabled(!isDataSaved);
//       setIsEditMode(!isDataSaved);
//       const toastMsg = isDataSaved ? "Data Saved Successfully!" : "Failed to save data.";
//       toast.success(toastMsg, { position: "top-center" });
//     }
// };

  const handleDeleteClick = async (id) => {
    if (!id) {
      toast.error("Invalid ID. Please select an item to delete.", {
        position: "top-center",
      });
      return;
    }
    const userConfirmed = window.confirm(
      "Are you sure you want to delete this item?"
    );
    if (!userConfirmed) return;
    try {
      const apiEndpoint = `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/stockmaster/${data1._id}`;
      const response = await axios.delete(apiEndpoint);

      if (response.status === 200) {
        toast.success("Data deleted successfully!", { position: "top-center" });
        fetchData(); // Refresh the data after successful deletion
      } else {
        throw new Error(`Failed to delete data: ${response.statusText}`);
      }
    } catch (error) {
      console.error("Error deleting data:", error);
      toast.error(`Failed to delete data. Error: ${error.message}`, {
        position: "top-center",
      });
    } finally {
   
    }
  };
const handleEditClick = () => {
  // document.body.style.backgroundColor = '#F3F2C8';
  setIsDisabled(false);
  setIsEditMode(true);
  setIsSubmitEnabled(true);
  setIsAbcmode(true);
  if (inputRefs.current[0]) {
    inputRefs.current[0].focus();
  }
};

  const handleChangevalues = (event) => {
    const { name, value } = event.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));

    // Calculate CGST and SGST
    if (name === "itax_rate") {
      const gstValue = parseFloat(value);
      if (!isNaN(gstValue)) {
        const cgstValue = gstValue / 2;
        const sgstValue = gstValue / 2;
        setFormData((prevState) => ({
          ...prevState,
          ctax_rate: cgstValue.toFixed(3),
          Stax_rate: sgstValue.toFixed(3),
        }));
      }
    }
  };
  const [expiredDate, setexpiredDate] = useState(null);
  useEffect(() => {
    if (formData.duedate) {
      setexpiredDate(new Date(formData.duedate));
    } else {
      const today = new Date();
      setexpiredDate(today);
      setFormData({ ...formData, duedate: today });
    }
  }, [formData.duedate, setFormData]);
  const handleDateChange = (date) => {
    setexpiredDate(date);
    setFormData({ ...formData, duedate: date });
  };

 // Handle Enter key to move focus to the next enabled input
 const handleKeyDown = (e, index) => {
  if (e.key === "Enter") {
    e.preventDefault(); // Prevent default behavior
    let nextIndex = index + 1;

    // Find the next input that is not disabled
    while (inputRefs.current[nextIndex] && inputRefs.current[nextIndex].disabled) {
      nextIndex += 1;
    }

    const nextInput = inputRefs.current[nextIndex];
    if (nextInput) {
      nextInput.focus(); // Focus the next enabled input field
    }
  }
};
 const handleNumericValue = (event) => {
      const { id, value } = event.target;
      // Allow only numeric values, including optional decimal points
      if (/^\d*\.?\d*$/.test(value) || value === '') {
        setFormData((prevData) => ({
          ...prevData,
          [id]: value,
        }));
      }
    };

    const handleChangeCheckBox = (e) => {
      const { name, type, value, checked } = e.target;
  
      setFormData((prev) => ({
        ...prev,
        [name]: type === "checkbox" ? checked : value, // Update based on type
      }));
    };

    const handleRateBlur = (field) => {
      const decimalPlaces = 3; // Default to 3 decimal places if rateValue is undefined
      let value = parseFloat(formData[field]);
    
      if (isNaN(value)) {
        setFormData((prev) => ({ ...prev, [field]: "" })); // Keep empty if NaN
      } else {
        setFormData((prev) => ({ ...prev, [field]: value.toFixed(decimalPlaces) }));
      }
    };

  return (
    <div style={{padding:10}}>
      <h1
        className="heading"
        style={{ fontWeight: 700, marginTop: -35, letterSpacing: 5 }}
      >
        STOCK ITEM MENU
      </h1>
      <div className="Main2" style={{padding:10}}>
        <div>
          <ToastContainer style={{ width: "30%" }} />
        </div>
            <div className="MainDiv">
              {/* First Half Screen */}
              <div className="FirstHalf">
                <div>
                  <div style={{ display: "flex", flexDirection: "row" }}>
                    <text>Accode:</text>
                    <input
                      className="ACCcoDE"
                      readOnly={!isEditMode || isDisabled}
                      type="text"
                      name="Acodes"
                      value={formData.Acodes}
                      onChange={handleChange}
                      onKeyPress={(event) => handleKeyPress(event, "gstNo")}
                    />
                  </div>
                  <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
                    <text>Name:</text>
                    <input
                       readOnly={!isEditMode || isDisabled}
                      className="ItemName"
                      size="small"
                      type="text"
                      name="Aheads"
                      value={formData.Aheads}
                      ref={(el) => (inputRefs.current[0] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 0)} // Handle Enter key
                      onChange={handleChange}
                      maxLength={75}
                    />
                  </div>
                  <div style={{display: "flex",flexDirection: "row",marginTop:5}}>
                    <text>Op.StockInQty:</text>
                    <input
                      className="OpSTOCK"
                      readOnly={!isEditMode || isDisabled}
                      size="small"
                      fullWidth
                      label="openwts"
                      value={formData.openwts}
                      ref={(el) => (inputRefs.current[1] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 1)} // Handle Enter key
                      name="openwts"
                      onChange={handleNumberChange}
                      maxLength={10}
                      onBlur={() => handleRateBlur("openwts")}
                    />
                    <input
                      value={"Box/Pc"}
                      style={{
                        width: 65,
                        color:'black',
                        textAlign: "center",
                        marginLeft: 2,
                        backgroundColor: "skyblue",
                      }}
                      disabled
                    />
                    <div>
                      <input
                        className="openpcs"
                        readOnly={!isEditMode || isDisabled}
                        size="small"
                        fullWidth
                        label="openpcs"
                        value={formData.openpcs}
                         ref={(el) => (inputRefs.current[2] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 2)} // Handle Enter key
                        name="openpcs"
                        onChange={handleNumberChange}
                        maxLength={10}
                        onBlur={() => handleRateBlur("openpcs")}
                      />
                    </div>
                  </div>
                  <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
                    <text>Op.Stock in Rs:</text>
                    <input
                      className="OpStockRS"
                      readOnly={!isEditMode || isDisabled}
                      size="small"
                      fullWidth
                      label="Mmopbals"
                      name="Mmopbals"
                      value={formData.Mmopbals}
                      onChange={handleNumberChange}
                       ref={(el) => (inputRefs.current[3] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 3)} // Handle Enter key
                      maxLength={10}
                      onBlur={() => handleRateBlur("Mmopbals")}
                    />
                  </div>
                  <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
                    <text>Group Name:</text>
                    <input
                      className="GroupNAME"
                      readOnly={!isEditMode || isDisabled}
                      size="small"
                      label="Add2s"
                      name="Add2s"
                      value={formData.Add2s}
                      onChange={handleChange}
                      ref={(el) => (inputRefs.current[4] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 4)} // Handle Enter key
                    />
                  </div>
                  <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
                    <text>PurchaseRate:</text>
                    <input
                      className="PurchaseRATE"
                      readOnly={!isEditMode || isDisabled}
                      size="small"
                      label="Prate"
                      name="Prate"
                      value={formData.Prate}
                      onChange={handleNumberChange}
                      ref={(el) => (inputRefs.current[5] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 5)} // Handle Enter key
                      maxLength={10}
                      onBlur={() => handleRateBlur("Prate")}
                    />
                  </div>
                  <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
          <text>M.R.P:</text>
          <input
            className="MRP"
            size="small"
            label="Mrps"
            name="Mrps"
            value={formData.Mrps}
            onChange={handleNumberChange}
            ref={(el) => (inputRefs.current[6] = el)} // Assign ref
            onKeyDown={(e) => handleKeyDown(e, 6)} // Handle Enter key
            maxLength={10}
            onBlur={() => handleRateBlur("Mrps")}
          />
          <input
            value={a}
            style={{
              width: 75,
              textAlign: "center",
              marginLeft: 2,
              backgroundColor: "skyblue",
              color:"black"
            }}
            disabled
          />
          <input
            className="Cds"
            size="small"
            label="Cds"
            name="Cds"
            value={formData.Cds}
            onChange={handleNumberChange}
            ref={(el) => (inputRefs.current[7] = el)} // Assign ref
            onKeyDown={(e) => handleKeyDown(e, 7)} // Handle Enter key
            maxLength={10}
            onBlur={() => handleRateBlur("Cds")}
          />
        </div>

        <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
          <text>SaleRate:</text>
          <input
            className="SaleRATE"
            size="small"
            fullWidth
            label="Srate"
            name="Srate"
            value={formData.Srate}
            onChange={handleSrateChange} // Allow manual entry in Srate
            ref={(el) => (inputRefs.current[8] = el)} // Assign ref
            onKeyDown={(e) => handleKeyDown(e, 8)} // Handle Enter key
            maxLength={10}
            onBlur={() => handleRateBlur("Srate")}
          />
          <text style={{ marginTop: 5 }}>TotalGST@:</text>
          <input
            className="TotalGST"
            size="small"
            fullWidth
            label="itax_rate"
            name="itax_rate"
            value={formData.itax_rate}
            onChange={handleChangevalues}
            ref={(el) => (inputRefs.current[9] = el)} // Assign ref
            onKeyDown={(e) => handleKeyDown(e, 9)} // Handle Enter key
            maxLength={4}
            onBlur={() => handleRateBlur("itax_rate")}
          />
        </div>
                  <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
                    <text>C.GST@:</text>
                    <input
                      className="ItemCgst"
                      readOnly
                      size="small"
                      label="ctax_rate"
                      name="ctax_rate"
                      value={formData.ctax_rate}
                      disabled
                      ref={(el) => (inputRefs.current[10] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 10)} // Handle Enter key
                      maxLength={10}
                      onBlur={() => handleRateBlur("ctax_rate")}
                    />
                    <input
                      value={"Cess Qty"}
                      style={{
                        width: 65,
                        textAlign: "center",
                        marginLeft: 2,
                        backgroundColor: "skyblue",
                        color:'black'
                      }}
                      disabled
                    />
                    <input
                      className="Drate"
                      readOnly={!isEditMode || isDisabled}
                      size="small"
                      label="Drate"
                      name="Drate"
                      value={formData.Drate}
                      onChange={handleNumberChange}
                      ref={(el) => (inputRefs.current[11] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 11)} // Handle Enter key
                      maxLength={10}
                      onBlur={() => handleRateBlur("Drate")}
                    />
                  </div>
                  <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
                    <text>S.GST@:</text>
                    <input
                      className="ItemSgst"
                      readOnly
                      size="small"
                      label="Stax_rate"
                      name="Stax_rate"
                      value={formData.Stax_rate}
                      disabled
                      ref={(el) => (inputRefs.current[12] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 12)} // Handle Enter key
                      maxLength={10}
                      onBlur={() => handleRateBlur("Stax_rate")}
                    />
                    <input
                      value={"Cess @"}
                      style={{
                        width: 65,
                        textAlign: "center",
                        marginLeft: 2,
                        backgroundColor: "skyblue",
                        color:'black'
                      }}
                      disabled
                    />
                    <input
                      className="Cess_rate"
                      readOnly={!isEditMode || isDisabled}
                      size="small"
                      label="Cess_rate"
                      name="Cess_rate"
                      value={formData.Cess_rate}
                      onChange={handleNumberChange}
                      ref={(el) => (inputRefs.current[13] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 13)} // Handle Enter key
                      maxLength={10}
                      onBlur={() => handleRateBlur("Cess_rate")}
                    />
                  </div>
                  <div>
                    {PurchaseAcc.map((item, index) => (
                      <div key={item.Pcodess}>
                        <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
                          <text>PurchaseA/c:</text>
                          <input
                    className="PurchaseACC"
                    readOnly={!isEditMode || isDisabled}
                    value={item.Pcodess || ''}
                    onChange={(e) => {
                      const newPur = [...PurchaseAcc];
                      newPur[index].Pcodess = e.target.value;
                      setPurchaseAcc(newPur);
                    }}
                    ref={(el) => (inputRefs.current[14] = el)} // Assign ref
                    onKeyDown={(e) => {
                      handleOpenModal(e, index, "Pcodess");
                      handleKeyDown(e, 14)
                      handleOpenModalBack(e, index, "Pcodess");
                    }}
                  />
                          {/* <input
                            className="PurchaseACC"
                            readOnly={!isEditMode || isDisabled}
                            id="Pcodess"
                            value={item.Pcodess}
                            // onClick={() => openModalForItemAcc(index)}
                             ref={(el) => (inputRefs.current[14] = el)} // Assign ref
                            onKeyDown={(e) => {
                              handleOpenModal(e, index, "Pcodess");
                              handleKeyDown(e, 14)
                            }}
                          /> */}
                        </div>
                      </div>
                    ))}
                    {showModalAcc && (
                      <ProductModalAccount
                        allFieldsAcc={allFieldsAcc}
                        productsAcc={productsAcc}
                        onSelectAcc={handleProductSelectAcc}
                        onCloseAcc={() => setShowModalAcc(false)}
                        initialKey={pressedKey} // Pass the pressed key to the modal
                      />
                    )}
                  </div>
                  <div>
                    {SaleAcc.map((item, index) => (
                      <div key={item.Scodess}>
                        <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
                          <text>SaleA/c:</text>
                          <input
                    className="SaleACC"
                    readOnly={!isEditMode || isDisabled}
                    value={item.Scodess || ''}
                    onChange={(e) => {
                      const newSale = [...SaleAcc];
                      newSale[index].Scodess = e.target.value;
                      setSaleAcc(newSale);
                    }}
                    ref={(el) => (inputRefs.current[15] = el)} // Assign ref
                            onKeyDown={(e) => {
                              handleOpenModal(e, index, "Scodess");
                               handleKeyDown(e, 15)
                               handleOpenModalBack(e, index, "Scodess");
                            }}
                  />
                          {/* <input
                            className="SaleACC"
                            readOnly={!isEditMode || isDisabled}
                            id="Scodess"
                            value={item.Scodess}
                            ref={(el) => (inputRefs.current[15] = el)} // Assign ref
                            onKeyDown={(e) => {
                              handleOpenModal(e, index, "Scodess");
                               handleKeyDown(e, 15)
                            }}
                          /> */}
                        </div>
                      </div>
                    ))}
                    {showModalCus && (
                      <ProductModalCustomer
                        allFields={allFieldsCus}
                        products={productsCus}
                        onSelect={handleProductSelectCus}
                        onClose={() => setShowModalCus(false)}
                        initialKey={pressedKey} // Pass the pressed key to the modal
                      />
                    )}
                  </div>
                  <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
                    <text>Size:</text>
                    <input
                      className="SIZE"
                      readOnly={!isEditMode || isDisabled}
                      size="small"
                      label="Pack"
                      name="Pack"
                      value={formData.Pack}
                      onChange={handleChange}
                      ref={(el) => (inputRefs.current[16] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 16)} // Handle Enter key
                      maxLength={12}
                    />
                  </div>
                  <div style={{ display: "flex", flexDirection: "row",marginTop:5}}>
                    <text>HSNCode:</text>
                    <input
                      className="HSNCode"
                      readOnly={!isEditMode || isDisabled}
                      size="small"
                      label="Hsn"
                      id="Hsn"
                      value={formData.Hsn}
                      onChange={handleNumericValue}
                      ref={(el) => (inputRefs.current[17] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 17)} // Handle Enter key
                      maxLength={8}
                    />
                  </div>
                </div>
              </div>
              {/* Second Half Screen */}
              <div className="SecondHalf">   
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "row",
                        marginTop: 1,
                      }}
                    >
                      <text style={{ marginTop: 5 }}>Scheme@:</text>
                      <input
                        className="Scheme"
                        readOnly={!isEditMode || isDisabled}
                        size="small"
                        label="schemes"
                        name="schemes"
                        value={formData.schemes}
                        onChange={handleNumberChange}
                        ref={(el) => (inputRefs.current[18] = el)} // Assign ref
                        onKeyDown={(e) => handleKeyDown(e, 18)} // Handle Enter key
                        maxLength={4}
                        onBlur={() => handleRateBlur("schemes")}
                      />
                      <input
                        value={"ExpireDate"}
                        style={{
                          width: 78,
                          textAlign: "center",
                          marginLeft: 2,
                          backgroundColor: "skyblue",
                          color:"black"
                        }}
                        disabled
                      />
                     <DatePicker
                    id="duedate"
                    value={formData.duedate}
                    className="duedatepicker"
                    selected={expiredDate}
                    onChange={handleDateChange}
                    readOnly={!isEditMode || isDisabled}
                    placeholderText="DueDate"
                    dateFormat="dd/MM/yyyy" 
                  />
                    </div>
                    <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
                      <text>Rate Calculate:</text>
                      <select
                        className="SelectField"
                        readOnly={!isEditMode || isDisabled}
                        name="Rateins"
                        style={{
                          color: "black",
                          width: "70%",
                          marginLeft:13
                        }}
                        value={formData.Rateins}
                        onChange={handleratecal}
                        displayEmpty
                        inputProps={{ "aria-label": "Without label" }}
                        ref={(el) => (inputRefs.current[19] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 19)} // Handle Enter key
                      >
                        <option value=""></option>
                        <option value="Default">Default</option>
                        <option value="Wt/Qty">Wt/Qty</option>
                        <option value="Pc/Pkgs">Pc/Pkgs</option>
                        <option value="Specific">Specific</option>
                      </select>
                    </div>
                    <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
                      <text>Cls Stock in:</text>
                      <select
                        className="SelectField"
                        readOnly={!isEditMode || isDisabled}
                        name="Stockins"
                        style={{
                          width: "70%",
                          color: "black",
                          marginLeft:35
                        }}
                        value={formData.Stockins}
                        onChange={hanldeclsStock}
                        displayEmpty
                        inputProps={{ "aria-label": "Without label" }}
                         ref={(el) => (inputRefs.current[20] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 20)} // Handle Enter key
                      >
                        <option value=""></option>
                        <option value={"Wt/Qty"}>Wt/Qty</option>
                        <option value={"Pieces/Case"}>Pieces/Case</option>
                        <option value={"Default"}>Default</option>
                      </select>
                    </div>
                    <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
                      <text>Qty in Units:</text>
                      <select
                        className="SelectField"
                        readOnly={!isEditMode || isDisabled}
                        name="Units"
                        style={{
                          width: "70%",
                          color: "black",
                          marginLeft:32
                        }}
                        value={formData.Units}
                        onChange={handleqtyunit}
                        displayEmpty
                        inputProps={{ "aria-label": "Without label" }}
                         ref={(el) => (inputRefs.current[21] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 21)} // Handle Enter key
                      >
                        <option value=""></option>
                        <option value="M.Tons">M.Tons</option>
                        <option value="Qtls">Qtls</option>
                        <option value="Kg.">Kg.</option>
                        <option value="Ltrs">Ltrs</option>
                        <option value="Case">Case</option>
                        <option value="Box">Box</option>
                        <option value="Packets">Packets</option>
                        <option value="Pcs">Pcs</option>
                        <option value="Pair">Pair</option>
                        <option value="Dozen">Dozen</option>
                        <option value="Lari">Lari</option>
                      </select>
                    </div>
                    <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
                      <text>Portal UOM:</text>
                      <select
                        className="SelectField"
                        readOnly={!isEditMode || isDisabled}
                        name="TradeName"
                        style={{
                          width: "70%",
                          color: "black",
                          marginLeft:34
                        }}
                        value={formData.TradeName}
                        onChange={handleportal}
                        displayEmpty
                        inputProps={{ "aria-label": "Without label" }}
                         ref={(el) => (inputRefs.current[22] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 22)} // Handle Enter key
                      >
                        <option value=""></option>
                        <option value="TUB-TUBES">TUB-TUBES</option>
                        <option value="UGS-US GALLONS">UGS-US GALLONS</option>
                        <option value="UNT-UNITS">UNT-UNITS</option>
                        <option value="YDS-YARDS">YDS-YARDS</option>
                        <option value="OTH-OTHERS">OTH-OTHERS</option>
                        <option value="LTR-LITRES">LTR-LITRES</option>
                        <option value="TON-TONNES">TON-TONNES</option>
                        <option value="THD-THOUSAND">THD-THOUSAND</option>
                        <option value="TGM-TEN GROSS">TGM-TEN GROSS</option>
                        <option value="TBS-TABLETS">TBS-TABLETS</option>
                        <option value="SQY-SQUARE YARDS">
                          SQY-SQUARE YARDS
                        </option>
                        <option value="SQM-SQUARE METERS">
                          SQM-SQUARE METERS
                        </option>
                        <option value="SQF-SQUARE-FEET">SQF-SQUARE-FEET</option>
                        <option value="SET-SETS">SET-SETS</option>
                        <option value="ROL-ROLLS">ROL-ROLLS</option>
                        <option value="QTL-QUINTAL">QTL-QUINTAL</option>
                        <option value="PRS-PAIRS">PRS-PAIRS</option>
                        <option value="PCS-PIECES">PCS-PIECES</option>
                        <option value="PAC-PACKS">PAC-PACKS</option>
                        <option value="NOS-NUMBERS">NOS-NUMBERS</option>
                        <option value="MTS-METRIC TON">MTS-METRIC TON</option>
                        <option value="MTR-METERS">MTR-METERS</option>
                        <option value="MLT-MILILITRE">MLT-MILILITRE</option>
                        <option value="KME-KILOMETRE">KME-KILOMETRE</option>
                        <option value="KLR-KILOLITRE">KLR-KILOLITRE</option>
                        <option value="KGS-KILOGRAMS">KGS-KILOGRAMS</option>
                        <option value="GYD-GROSS YARDS">GYD-GROSS YARDS</option>
                        <option value="GRS-GROSS">GRS-GROSS</option>
                        <option value="GMS-GRAMMES">GMS-GRAMMES</option>
                        <option value="GGK-GREAT GROSS">GGK-GREAT GROSS</option>
                        <option value="DRM-DRUMS">DRM-DRUMS</option>
                        <option value="DOZ-DOZENS">DOZ-DOZENS</option>
                        <option value="CTN-CARTONS">CTN-CARTONS</option>
                        <option value="CMS-CENTIMETERS">CMS-CENTIMETERS</option>
                        <option value="CCM-CUBIC CENTIMETERS">
                          CCM-CUBIC CENTIMETERS
                        </option>
                        <option value="CBM-CUBIC METERS">
                          CBM-CUBIC METERS
                        </option>
                        <option value="CAN-CANS">CAN-CANS</option>
                        <option value="BUN-BUNCHES">BUN-BUNCHES</option>
                        <option value="BTL-BOTTLES">BTL-BOTTLES</option>
                        <option value="BOX-BOX">BOX-BOX</option>
                        <option value="BAG-BAGS">BAG-BAGS</option>
                        <option value="BAL-BALE">BAL-BALE</option>
                        <option value="BDL-BUNDLES">BDL-BUNDLES</option>
                        <option value="BKL-BUCKLES">BKL-BUCKLES</option>
                        <option value="BOU-BILLION OF UNITS">
                          BOU-BILLION OF UNITS
                        </option>
                      </select>
                    </div>
                    <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
                      <text>Stock Calculate:</text>
                      <select
                        className="SelectField"
                        readOnly={!isEditMode || isDisabled}
                        name="Stkcals"
                        style={{
                          width: "70%",
                          color: "black",
                          marginLeft:9
                        }}
                        value={formData.Stkcals}
                        onChange={handlestockCal}
                        displayEmpty
                        inputProps={{ "aria-label": "Without label" }}
                         ref={(el) => (inputRefs.current[23] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 23)} // Handle Enter key
                      >
                        <option value=""></option>
                        <option value={"Wt/Qty"}>Wt/Qty</option>
                        <option value={"Pc/Packet"}>Pc/Packet</option>
                        <option value={"Default"}>Default</option>
                        <option value={"Wt/Qty Fix"}>Wt/Qty Fix</option>
                        <option value={"Pc/Packet Fix"}>Pc/Packet Fix</option>
                      </select>
                    </div>
                    <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
                      <text>Types of Goods:</text>
                      <select
                        className="SelectField"
                        readOnly={!isEditMode || isDisabled}
                        name="Types"
                        style={{
                          width: "70%",
                          color: "black",
                          marginLeft:8
                        }}
                        value={formData.Types}
                        onChange={handleGoods}
                        displayEmpty
                        inputProps={{ "aria-label": "Without label" }}
                        ref={(el) => (inputRefs.current[24] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 24)} // Handle Enter key
                      >
                        <option value=""></option>
                        <option value={"Raw Material"}>Raw Material</option>
                        <option value={"Finished Product"}>
                          Finished Product
                        </option>
                        <option value={"Semi-Finished Product"}>
                          Semi-Finished Product
                        </option>
                        <option value={"Bye Product"}>Bye Product</option>
                        <option value={"Wastage"}>Wastage</option>
                        <option value={"Consumable"}>Consumable</option>
                        <option value={"Other Goods"}>Other Goods</option>
                      </select>
                    </div>
                    <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
                      <text>Stk Valuation:</text>
                      <select
                        className="SelectField"
                        readOnly={!isEditMode || isDisabled}
                        name="Stkvals"
                        style={{
                          width: "70%",
                          color: "black",
                          marginLeft:24
                        }}
                        value={formData.Stkvals}
                        onChange={handlestkValuation}
                        displayEmpty
                        inputProps={{ "aria-label": "Without label" }}
                         ref={(el) => (inputRefs.current[25] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 25)} // Handle Enter key
                      >
                        <option value=""></option>
                        <option value={"Purchase Rate"}>Purchase Rate</option>
                        <option value={"Sale Rate"}>Sale Rate</option>
                        <option value={"None"}>None</option>
                      </select>
                    </div>
                    <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
                      <text style={{ marginTop: 5 }}>Qty Per Pc/Case:</text>
                      <input
                        className="QtyPerCase"
                        readOnly={!isEditMode || isDisabled}
                        size="small"
                        label="Qpps"
                        name="Qpps"
                        value={formData.Qpps}
                        onChange={handleNumberChange}
                        ref={(el) => (inputRefs.current[26] = el)} // Assign ref
                        onKeyDown={(e) => handleKeyDown(e, 26)} // Handle Enter key
                        maxLength={8}
                        onBlur={() => handleRateBlur("Qpps")}
                      />
                      <input
                        value={"Tariff"}
                        style={{
                          width: 60,
                          textAlign: "center",
                          marginLeft: 2,
                          backgroundColor: "skyblue",
                          color:'black'
                        }}
                        disabled
                      />
                      <input
                        className="tariff"
                        readOnly={!isEditMode || isDisabled}
                        size="small"
                        label="tariff"
                        name="tariff"
                        value={formData.tariff}
                        onChange={handleNumberChange}
                        ref={(el) => (inputRefs.current[27] = el)} // Assign ref
                        onKeyDown={(e) => handleKeyDown(e, 27)} // Handle Enter key
                        maxLength={8}
                        onBlur={() => handleRateBlur("tariff")}
                      />{" "}
                    </div>
                    <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
                      <text>Min.Stock Level:</text>
                      <input
                        className="MinSTK"
                        readOnly={!isEditMode || isDisabled}
                        size="small"
                        label="Inval"
                        name="Inval"
                        value={formData.Inval}
                        onChange={handleNumberChange}
                        ref={(el) => (inputRefs.current[28] = el)} // Assign ref
                        onKeyDown={(e) => handleKeyDown(e, 28)} // Handle Enter key
                        maxLength={8}
                        onBlur={() => handleRateBlur("Inval")}
                      />
                      <input
                        className="Rg23c"
                        readOnly={!isEditMode || isDisabled}
                        size="small"
                        fullWidth
                        label="Rg23c"
                        name="Rg23c"
                        value={formData.Rg23c}
                        onChange={handleNumberChange}
                        ref={(el) => (inputRefs.current[29] = el)} // Assign ref
                        onKeyDown={(e) => handleKeyDown(e, 29)} // Handle Enter key
                        maxLength={8}
                        onBlur={() => handleRateBlur("Rg23c")}
                      />
                    </div>
                    <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
                      <text>206C(1H)/194Q</text>
                      <select
                        className="SelectField"
                        readOnly={!isEditMode || isDisabled}
                        name="Tcs206"
                        style={{
                          width: "70%",
                          color: "black",
                          marginLeft:10
                        }}
                        value={formData.Tcs206}
                        onChange={handleselection}
                        displayEmpty
                        inputProps={{ "aria-label": "Without label" }}
                         ref={(el) => (inputRefs.current[30] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 30)} // Handle Enter key
                      >
                        <option value=""></option>
                        <option value={"Yes"}>Yes</option>
                        <option value={"No"}>NO</option>
                        <option value={"NA"}>NA</option>
                      </select>
                    </div>
                    <div style={{ display: "flex", flexDirection: "row",marginTop:5 }}>
                      <text>GST Type:</text>
                      <select
                        className="SelectField"
                        readOnly={!isEditMode || isDisabled}
                        name="Stype"
                        style={{
                          width: "70%",
                          color: "black",
                          marginLeft:53
                        }}
                        value={formData.Stype}
                        onChange={handlegsttype}
                        displayEmpty
                        inputProps={{ "aria-label": "Without label" }}
                         ref={(el) => (inputRefs.current[31] = el)} // Assign ref
                      onKeyDown={(e) => handleKeyDown(e, 31)} // Handle Enter key
                      >
                        <option value=""></option>
                        <option value={"Taxable"}>Taxable</option>
                        <option value={"Free Tax"}>Free Tax</option>
                        <option value={"Non GST"}>Non GST</option>
                        <option value={"Services"}>Services</option>
                        <option value={"Exempted"}>Exempted</option>
                        <option value={"X-Not Sale"}>X-Not Sale</option>
                      </select>
                    </div>
                {/* Section 3 */}
              </div>
              <div className="ThirdHalf">
                <div style={{display:'flex',flexDirection:'row'}}>
                <input
                disabled={!isEditMode || isDisabled}
                style={{marginLeft:"2x0%"}}
                type="checkbox"
                name="T1"
                checked={formData.T1}
                onChange={handleChangeCheckBox}
                className="custom-checkbox"
                />
                <text style={{marginLeft:"2%"}}>Add to Production Card</text>
                </div>
                {formData.T1 && (
                <>
                <div style={{display:'flex',flexDirection:'row',marginTop:10}}>
                <text>Production Sr.No</text>
                <input
                readOnly={!isEditMode || isDisabled}
                className="Psrno"
                id="Psrno"
                value={formData.Psrno}
                onChange={handleNumericValue}
                />
                </div>
                <div style={{display:'flex',flexDirection:'row',marginTop:5}}>
                <text>Unit.No</text>
                <input
                readOnly={!isEditMode || isDisabled}
                className="PUnitno"
                id="PUnitno"
                value={formData.PUnitno}
                onChange={handleNumericValue}
                />
                </div>
                <div style={{display:'flex',flexDirection:'row',marginTop:5}}>
                <text>Percentage</text>
                <input
                readOnly={!isEditMode || isDisabled}
                className="percentage"
                id="percentage"
                value={formData.percentage}
                onChange={handleNumericValue}
                onBlur={() => handleRateBlur("percentage")}
                />
                </div>
                </>
                )}
              </div>
            </div>
        <div
          className="Buttonsgroupz"
        >
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[0] }}
            onClick={handleAdd}
            disabled={!isAddEnabled}
          >
            Add
          </Button>
          <Button
            disabled={!isAddEnabled}
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[1] }}
            onClick={handleEditClick}
          >
            Edit
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[2] }}
            onClick={handlePrevious}
            disabled={index === 0}
          >
            Previous
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[3] }}
            onClick={handleNext}
            disabled={index === data.length - 1}
          >
            Next
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[4] }}
            onClick={handleFirst}
            disabled={index === 0}
          >
            First
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[5] }}
            onClick={handleLast}
            disabled={index === data.length - 1}
          >
            Last
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[6] }}
            onClick={handleOpen}
          >
            Search
          </Button>
            <Modal open={openSearch} onClose={handleCloseSearch}>
            <Box
              sx={{
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                width: 400,
                bgcolor: "background.paper",
                boxShadow: 24,
                p: 4,
                borderRadius: 2,
              }}
            >
              <Typography variant="h6" mb={2}>
                Select Ledger Account
              </Typography>
              <Autocomplete
                fullWidth
                options={data2}
                getOptionLabel={(option) =>option?.formData?.Aheads || ""} // Display Name
                value={selectedOption}
                onChange={handleSelect} // Handle selection
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    label="Search and Select"
                    inputRef={autoCompleteRef} // Set focus on open
                  />
                )}
              />
            </Box>
           </Modal>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[7] }}
          >
            Print
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[8] }}
            onClick={handleDeleteClick}
          >
            Delete
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[9] }}
            onClick={handleExit}
          >
            Exit
          </Button>
          <div>
            <Button
              ref={(el) => (inputRefs.current[32] = el)} // Assign ref
              onKeyDown={(e) => handleKeyDown(e, 32)} // Handle Enter key
              className="Buttonz"
              onClick={handleSaveClick}
              disabled={!isSubmitEnabled}
              style={{ color: "black", backgroundColor: buttonColors[10] }}
              // onClick={handleSubmit} disabled={!isSubmitEnabled}
            >
              Save
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewStockAcc;


