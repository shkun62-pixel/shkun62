import React, { useRef, useEffect, useState } from 'react';
import { useReactToPrint } from 'react-to-print';
import { Modal, Box, Button } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

const InvoiceJournal = React.forwardRef(({
    formData,
    items,
    isOpen, // Changed from 'open' to 'isOpen'
    handleClose,
    GSTIN,
    PAN,
    shopName,
    description,
    address
  }, ref) => {
    const chunkItems = (items, firstChunkSize, otherChunkSize) => {
      const chunks = [];
      let i = 0;
      // Handle the first chunk with a specific size
      if (items.length > 0) {
        chunks.push(items.slice(i, i + firstChunkSize));
        i += firstChunkSize;
      }
      // Handle all other chunks with a different size
      while (i < items.length) {
        chunks.push(items.slice(i, i + otherChunkSize));
        i += otherChunkSize;
      }
      return chunks;
    };
    // Split items into chunks of 10
    const chunks = chunkItems(items, 10, 20);

    const [totalQuantity, setTotalQuantity] = useState(0);
    // Function to calculate total quantity
    const calculateTotalQuantity = () => {
      const total = items.reduce((accumulator, currentItem) => {
        return accumulator + Number(currentItem.weight);
      }, 0);
      setTotalQuantity(total);
    };
    useEffect(() => {
      calculateTotalQuantity();
    }, [items]);

    const style = {
      bgcolor: "white",
      boxShadow: 24,
      p: 4,
      overflowY: "auto",
    };

    const componentRef = useRef();
    const handlePrint = useReactToPrint({
      content: () => componentRef.current,
    });

    return (
      <Modal
        open={isOpen}
        style={{ overflow: "auto" }}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <button className="close-button" onClick={handleClose}>
            <CloseIcon />
          </button>
          <Button
            className="Button"
            style={{ color: "black", backgroundColor: "lightcoral" }}
            onClick={handlePrint}
          >
            Print
          </Button>
          <text style={{ fontWeight: "bold", fontSize: 30, marginLeft: "32%" }}>
            This Is The Preview of Bill
          </text>
          <div
            ref={componentRef}
            style={{
              width: "290mm",
              minHeight: "390mm",
              margin: "auto",
              padding: "20px",
              // border: "1px solid #000",
              borderRadius: "5px",
              boxSizing: "border-box",
              marginTop: 5,
            }}
          >
            {chunks.map((chunk, pageIndex) => (
              <div
                key={pageIndex}
                style={{
                  minHeight: "257mm",
                  marginBottom: "20px",
                  pageBreakAfter:
                    pageIndex === chunks.length - 1 ? "auto" : "always", // Changed 'avoid' to 'auto'
                }}
              >
                <div style={{display:"flex",flexDirection:"column",textAlign:'center'}}>
                  <text style={{fontSize:40,color:'darkblue'}}>{shopName}</text>
                  <text style={{fontSize:20}}>{address}</text>
                </div>
               <div style={{display:"flex",flexDirection:'row',marginTop:50}}>
                <text style={{fontSize:20}}>DATE:{formData.date}</text>
                <text style={{marginLeft:"67%",fontSize:20}}>JOURNAL VOUCHER</text>
               </div>
                <table
                  style={{
                    width: "100%",
                    borderCollapse: "collapse",
                    borderRight: "1px solid #000",
                    borderLeft: "1px solid #000",
                    borderBottom: "1px solid #000",
                  }}
                >
                  <thead style={{backgroundColor:"lightgrey"}}>
                    <tr style={{fontSize:20}}>
                      <th style={{ border: "1px solid #000", padding: "8px",textAlign:"center" }}>
                        Account Name
                      </th>
                      <th style={{ border: "1px solid #000", padding: "8px",textAlign:"center" }}>
                        Narration
                      </th>
                      <th style={{ border: "1px solid #000", padding: "8px" ,textAlign:"center"}}>
                        Debit
                      </th>
                      <th style={{ border: "1px solid #000", padding: "8px",textAlign:"center" }}>
                        Credit
                      </th>
                    </tr>
                  </thead>
                  <tbody style={{ borderBottom: "1px solid black" }}>
                    {chunk.map((item, index) => (
                      <tr
                        key={index}
                        style={{
                          borderBottom:
                            index === chunk.length - 1
                              ? "1px solid #000"
                              : "none",
                              fontSize:20
                        }}
                      > 
                        <td
                          style={{
                            borderRight: "1px solid black",
                            padding: "8px 0",
                            paddingLeft: 10,
                            display:"flex",
                            flexDirection:"column"
                          }}
                        >
                          {item.accountname}
                        </td>
                        <td
                          style={{
                            borderRight: "1px solid black",
                            padding: "8px 0",
                            paddingLeft: 10,
                          }}
                        >
                          {item.narration}
                        </td>
                        <td
                          style={{
                            borderRight: "1px solid black",
                            padding: "8px 0",
                            paddingRight: 10,
                            textAlign:"right",
                          }}
                        >
                          {item.debit}
                        </td>
                        <td
                          style={{
                            borderRight: "1px solid black",
                            padding: "8px 0",
                            paddingRight: 10,
                            textAlign:"right",
                          }}
                        >
                          {item.credit}
                        </td>
                       
                        {/* <td style={{ borderRight: "1px solid black", padding: "8px 0" }}>{item.Others}</td>
                                        <td style={{ borderRight: "1px solid black", padding: "8px 0" }}>{item.CGST}</td>
                                        <td style={{ borderRight: "1px solid black", padding: "8px 0" }}>{item.total}</td> */}
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr
                      style={{
                        borderBottom: "1px solid #000",
                        borderLeft: "1px solid #000",
                        borderRight: "1px solid #000",
                      }}
                    >
                      <td
                        colSpan="2"
                        style={{ paddingLeft: "39px", border: "none" ,fontSize:20, fontWeight:'bold'}}
                      >
                        TOTAL
                      </td>
                      <td
                        style={{
                          textAlign: "right",
                          paddingRight: "10px",
                          border: "1px solid #000",
                          fontSize:20,
                          fontWeight:'bold'
                        }}
                      >
                        {formData.totaldebit}
                      </td>
                      <td
                        style={{
                          textAlign: "right",
                          paddingRight: "10px",
                          border: "1px solid #000",
                          fontSize:20
                          ,fontWeight:'bold'
                        }}
                      >
                        {formData.totalcredit}
                      </td>
                    </tr>
                  </tfoot>
                </table>
                <div style={{display:"flex",flexDirection:"row",marginTop:60}}>
                    <text style={{fontSize:25,fontFamily:'serif',marginLeft:20}}>Cashier</text>
                    <text style={{fontSize:25,marginLeft:"32%",fontFamily:'serif'}}>Accountant</text>
                    <text style={{fontSize:25,marginLeft:"32%",fontFamily:'serif'}}>Manager</text>
                </div>
                {/* <div style={{ fontSize: "12px" }}>
                  <text>Footer content specific to page {pageIndex + 1}</text>
                </div> */}
              </div>
            ))}
          </div>
        </Box>
      </Modal>
    );
  });
  export default InvoiceJournal;