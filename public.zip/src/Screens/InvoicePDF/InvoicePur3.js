import React, { useRef, useEffect, useState } from 'react';
import { useReactToPrint } from 'react-to-print';
import { Modal, Box, Button } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import logo from './/logo.jpg';
import qrcode from './/qrcode.png'

const InvoicePur3 = React.forwardRef(({
    formData,
    items,
    supplierdetails,
    isOpen, // Changed from 'open' to 'isOpen'
    handleClose,
    GSTIN,
    PAN,
    shopName,
    description,
    address
  }, ref) => {
    const chunkItems = (items, firstChunkSize, otherChunkSize) => {
      const chunks = [];
      let i = 0;
      // Handle the first chunk with a specific size
      if (items.length > 0) {
        chunks.push(items.slice(i, i + firstChunkSize));
        i += firstChunkSize;
      }
      // Handle all other chunks with a different size
      while (i < items.length) {
        chunks.push(items.slice(i, i + otherChunkSize));
        i += otherChunkSize;
      }
      return chunks;
    };
    // Split items into chunks of 10
    const chunks = chunkItems(items, 10, 20);

    const [totalQuantity, setTotalQuantity] = useState(0);
    // Function to calculate total quantity
    const calculateTotalQuantity = () => {
      const total = items.reduce((accumulator, currentItem) => {
        return accumulator + Number(currentItem.weight);
      }, 0);
      setTotalQuantity(total);
    };
    useEffect(() => {
      calculateTotalQuantity();
    }, [items]);

    const style = {
      bgcolor: "white",
      boxShadow: 24,
      p: 4,
      overflowY: "auto",
    };

    const componentRef = useRef();
    const handlePrint = useReactToPrint({
      content: () => componentRef.current,
    });
    function numberToIndianWords(num) {
      const ones = [
          "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
          "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
          "Seventeen", "Eighteen", "Nineteen"
      ];
      const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
      const scales = ["", "Thousand", "Lakh", "Crore"];
  
      if (num === 0) return "Zero Rupees";
  
      function convertHundred(n) {
          let result = "";
          if (n >= 100) {
              result += ones[Math.floor(n / 100)] + " Hundred ";
              n %= 100;
          }
          if (n >= 20) {
              result += tens[Math.floor(n / 10)] + " ";
              n %= 10;
          }
          if (n > 0) {
              result += ones[n] + " ";
          }
          return result.trim();
      }
  
      function convertDecimal(decimalPart) {
          let result = "";
          for (let digit of decimalPart) {
              result += ones[parseInt(digit)] + " ";
          }
          return result.trim();
      }
  
      let [whole, decimal] = num.toString().split(".");
      let word = "";
  
      // Convert the whole number part using Indian numbering system
      let scaleIndex = 0;
      while (whole.length > 0) {
          let part = 0;
          if (scaleIndex === 0) { // Last 3 digits for Thousand
              part = parseInt(whole.slice(-3));
              whole = whole.slice(0, -3);
          } else { // Next 2 digits for Lakh, Crore, etc.
              part = parseInt(whole.slice(-2));
              whole = whole.slice(0, -2);
          }
  
          if (part > 0) {
              word = convertHundred(part) + " " + scales[scaleIndex] + " " + word;
          }
          scaleIndex++;
      }
  
      word = word.trim() + " Rupees";
  
      // Convert the decimal part if present
      if (decimal) {
          word += " and " + convertDecimal(decimal) + " Paise";
      }
  
      return word.trim();
  }
  
  // Example usage with formData.grandtotal
  let totalInWords = numberToIndianWords(formData.grandtotal);

    return (
      <Modal
        open={isOpen}
        style={{ overflow: "auto" }}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <button className="close-button" onClick={handleClose}>
            <CloseIcon />
          </button>
          <Button
            className="Button"
            style={{ color: "black", backgroundColor: "lightcoral" }}
            onClick={handlePrint}
          >
            Print
          </Button>
          {/* <text style={{ fontWeight: "bold", fontSize: 30, marginLeft: "32%" }}>
            This Is The Preview of Bill
          </text> */}
          <div
            ref={componentRef}
            style={{
              width: "290mm",
              minHeight: "390mm",
              margin: "auto",
              padding: "20px",
              // border: "1px solid #000",
              borderRadius: "5px",
              boxSizing: "border-box",
             
            }}
          >
            <text style={{fontSize:30,marginLeft:"42%"}}>TAX-INVOICE</text>
            <a style={{fontSize:20,marginLeft:"28%"}}>OFFICE COPY</a>
            {chunks.map((chunk, pageIndex) => (
              <div
                key={pageIndex}
                style={{
                  minHeight: "257mm",
                  marginBottom: "20px",
                  pageBreakAfter:
                    pageIndex === chunks.length - 1 ? "auto" : "always", // Changed 'avoid' to 'auto'
                }}
              >
                {pageIndex === 0 && (
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        height: 510,
                    //   backgroundColor:'yellow',
                      borderLeft:"1px solid black",
                       borderRight:"1px solid black",
                        borderTop:"1px solid black",
                      }}
                    >

                        <div style={{display:'flex',flexDirection:'row',height:190}}>
                       <div style={{display:'flex'}}>
                       <img src={logo} alt="Logo" style={{ width: '140px', height: '140px',borderRadius:"50%"}} />
                       </div>
                       <div style={{display:'flex',flexDirection:'column',textAlign:'center'}}>
                       <text
                        style={{
                          fontSize: 60,
                          fontWeight: "600",
                          fontFamily: "serif",
                          color:'darkblue',
                          marginLeft:10
                        }}
                      >
                        {shopName}
                      </text>
                      <a style={{fontSize:20,marginTop:-20}}>{description}</a>
                      <a style={{fontSize:20}}>{address}</a>
                      <div style={{display:'flex',flexDirection:'row',marginLeft:"15%"}}>
                      <a style={{fontSize:20}}>GSTIN: {GSTIN}</a>
                      <a style={{fontSize:20,marginLeft:20}}>PAN: {PAN}</a>
                      </div>
                      <div style={{display:'flex',flexDirection:'row',marginLeft:"15.5%"}}>
                      <a style={{fontSize:20}}>Ph No: 659835243</a>
                      <a style={{fontSize:20,marginLeft:20}}>Email: Narayan@gamil.com</a>
                      </div>
                      </div>
                      <img src={qrcode} alt="QR Code" style={{ width: '180px', height: '180px',marginLeft:50,marginTop:5 }} />
                        </div>
                        <div style={{height:380,borderTop:"1px solid black",display:'flex',flexDirection:"row"}}>
                      <div style={{width:"50%",height:"100%",borderRight:"1px solid black",display:'flex',flexDirection:'column'}}>
                        <div style={{borderBottom:"1px solid black",height:"25%"}}>
                            <text style={{fontSize:20,marginLeft:10}}>Original For Recipient</text>
                        </div>
                        <div style={{borderBottom:"1px solid black",height:"25%"}}>
                        <text style={{fontSize:20,marginLeft:10}}>Self Invoice No. {formData.vbillno}</text>
                        </div>
                        <div style={{borderBottom:"1px solid black",height:"25%"}}>
                        <text style={{fontSize:20,marginLeft:10}}>Self Invoice Date. {formData.date}</text>
                        </div>
                        <div style={{height:"25%"}}>
                        <text style={{fontSize:20,marginLeft:10}}>Payment Mode : Credit</text>
                        </div>
                        </div>
                        <div style={{width:"50%",display:'flex',flexDirection:"column"}}>
                            <div style={{display:'flex',flexDirection:'row',color:'red'}}>
                                <a style={{fontSize:20,marginLeft:10}}>EWB NO.</a>
                                <text style={{fontSize:20,marginLeft:10}}>31185669823</text>
                            </div>
                            <div style={{display:'flex',flexDirection:'row',color:'red'}}>
                                <a style={{fontSize:20,marginLeft:10}}>Valid Upto.</a>
                                <text style={{fontSize:20,marginLeft:10}}>25/11/2024</text>
                            </div>
                            <div style={{display:'flex',flexDirection:'row',color:'red'}}>
                                <a style={{fontSize:20,marginLeft:10}}>IRN:</a>
                                <text style={{fontSize:20,marginLeft:10}}>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor</text>
                            </div>
                        </div>
                      </div>
                        <div style={{borderTop:"1px solid black",height:40,color:'red'}}>
                          <text style={{fontSize:20,marginLeft:10}}>Ack No.</text>
                          <text style={{fontSize:20,marginLeft:5}}>88995666226633</text>
                          <text style={{fontSize:20,marginLeft:"20%"}}>Ack Dt.</text>
                          <text style={{fontSize:20,marginLeft:5}}>21/11/2024</text>
                          <text style={{fontSize:20,marginLeft:"20%"}}>Distance Km.</text>
                          <text style={{fontSize:20,marginLeft:5}}>250</text>
                        </div>
                      <div style={{height:160,borderTop:"1px solid black",display:'flex',flexDirection:"row"}}>
                      {/* Billed To */}
                      <div style={{width:"50%",borderRight:"1px solid black"}}>
                      {supplierdetails.map((item) => (
                          <div key={item.vacode}>
                            <text
                              style={{
                                marginBottom: 0,
                                fontWeight: "bold",
                                fontSize: 18,
                                marginLeft: "30%",
                                textDecoration:"underline"
                              }}
                            >
                              Details of Receiver (Billed to)
                            </text>
                            <p
                              style={{
                                marginBottom: 0,
                                fontWeight: "bold",
                                fontSize: 20,
                                marginLeft: 10,
                              }}
                            >
                              Name: {item.vacode}{" "}
                            </p>
                            <p
                              style={{
                                marginBottom: 0,
                                fontWeight: "bold",
                                fontSize: 20,
                                marginLeft: 10,
                              }}
                            >
                              Address: {item.Add1}{" "}
                            </p>
                            <div
                              style={{ display: "flex", flexDirection: "row" }}
                            >
                              <p
                                style={{
                                  marginBottom: 0,
                                  fontWeight: "bold",
                                  fontSize: 20,
                                  marginLeft: 10,
                                }}
                              >
                                City: {item.city}{" ,"}
                              </p>
                              <p
                                style={{
                                  marginBottom: 0,
                                  fontWeight: "bold",
                                  fontSize: 20,
                                  marginLeft: 10,
                                }}
                              >
                                State: {item.state}{" "}
                              </p>
                            </div>
                            <div
                              style={{ display: "flex", flexDirection: "row" }}
                            >
                              <p
                                style={{
                                  marginBottom: 0,
                                  fontWeight: "bold",
                                  fontSize: 20,
                                  marginLeft: 10,
                                }}
                              >
                                GSTIN: {item.gstno}{" "}
                              </p>
                              <p
                                style={{
                                  marginBottom: 0,
                                  fontWeight: "bold",
                                  fontSize: 20,
                                  marginLeft: 10,
                                }}
                              >
                                PAN: {item.pan}{" "}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                      {/* Shipped to */}
                        <div style={{width:"50%"}}>
                        <div style={{borderBottom:"1px solid black",height:"25%"}}>
                            <text style={{fontSize:20,marginLeft:10}}>Doc No. {formData.vbillno}</text>
                        </div>
                        <div style={{borderBottom:"1px solid black",height:"25%"}}>
                            <text style={{fontSize:20,marginLeft:10}}>Doc Date. {formData.date}</text>
                        </div>
                        <div style={{borderBottom:"1px solid black",height:"25%"}}>
                            <text style={{fontSize:20,marginLeft:10}}>Vehicle No. {formData.trpt}</text>
                        </div>
                        <div style={{height:"25%"}}>
                            <text style={{fontSize:20,marginLeft:10}}>Transporter Name. {formData.v_tpt}</text>
                        </div>
                      </div>
                      </div>
                     
                    </div>
                )}
                  <table
                  style={{
                    width: "100%",
                    borderCollapse: "collapse",
                    borderRight: "1px solid #000",
                    borderLeft: "1px solid #000",
                    borderBottom: "1px solid #000",
                  }}
                >
                  <thead style={{backgroundColor:"lightgrey"}}>
                    <tr>
                    <th style={{ border: "1px solid #000", padding: "8px",textAlign:'center',fontSize:20,width:30 }}>
                        Sr.No
                      </th>
                      <th style={{ border: "1px solid #000", padding: "8px",textAlign:'center',fontSize:20,width:400 }}>
                        Description
                      </th>
                    
                      <th style={{ border: "1px solid #000", padding: "8px",textAlign:'center',fontSize:20 }}>
                        HSN
                      </th>
                      <th style={{ border: "1px solid #000", padding: "8px",textAlign:'center',fontSize:20 }}>
                        PCS
                      </th>
                      <th style={{ border: "1px solid #000", padding: "8px",textAlign:'center',fontSize:20 }}>
                        Qty.
                      </th>
                      <th style={{ border: "1px solid #000", padding: "8px",textAlign:'center',fontSize:20 }}>
                        Unit
                      </th>
                      <th style={{ border: "1px solid #000", padding: "8px",textAlign:'center',fontSize:20 }}>
                        Rate
                      </th>
                      <th style={{ border: "1px solid #000", padding: "8px",textAlign:'center',fontSize:20 }}>
                        Amount
                      </th>
                    </tr>
                  </thead>
                  <tbody style={{ borderBottom: "1px solid black" }}>
                    {chunk.map((item, index) => (
                      <tr
                        key={index}
                        style={{
                          borderBottom:
                            index === chunk.length - 1
                              ? "1px solid #000"
                              : "none",
                              fontSize:20,
                              fontWeight:650
                        }}
                      >
                        <td
                          style={{
                            borderRight: "1px solid black",
                            // padding: "8px 0",
                            paddingLeft: 10,
                          }}
                        >
                          {item.id}
                        </td>
                        <td
                          style={{
                            borderRight: "1px solid black",
                            // padding: "8px 0",
                            paddingLeft: 10,
                          }}
                        >
                          {item.sdisc}
                        </td>
                        
                        <td
                          style={{
                            borderRight: "1px solid black",
                            // padding: "8px 0",
                            paddingLeft: 10,
                          }}
                        >
                          {item.tariff}
                        </td>
                        <td
                          style={{
                            borderRight: "1px solid black",
                            // padding: "8px 0",
                            paddingLeft: 10,
                          }}
                        >
                          {item.pkgs}
                        </td>
                        <td
                          style={{
                            borderRight: "1px solid black",
                            // padding: "8px 0",
                            paddingLeft: 10,
                          }}
                        >
                          {item.weight}
                        </td>
                        <td
                          style={{
                            borderRight: "1px solid black",
                            // padding: "8px 0",
                            paddingLeft: 10,
                          }}
                        >
                          {item.Units}
                        </td>
                        <td
                          style={{
                            borderRight: "1px solid black",
                            // padding: "8px 0",
                            paddingLeft: 10,
                          }}
                        >
                          {item.rate}
                        </td>
                        <td
                          style={{
                            borderRight: "1px solid black",
                            // padding: "8px 0",
                           textAlign:"right",
                           paddingRight:10
                          }}
                        >
                          {item.weight * item.rate}
                        </td>
                        {/* <td style={{ borderRight: "1px solid black", padding: "8px 0" }}>{item.Others}</td>
                                        <td style={{ borderRight: "1px solid black", padding: "8px 0" }}>{item.CGST}</td>
                                        <td style={{ borderRight: "1px solid black", padding: "8px 0" }}>{item.total}</td> */}
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr
                      style={{
                        borderBottom: "1px solid #000",
                        borderLeft: "1px solid #000",
                        borderRight: "1px solid #000",
                      }}
                    >
                      <td
                        colSpan="2"
                        style={{ paddingLeft: "39px", border: "none",fontWeight:"bold",fontSize:18 }}
                      >
                        TOTAL
                      </td>
                      {/* <td style={{ textAlign: 'right', padding: '8px' }}>${calculateSubtotal(chunk)}</td> */}
                      <td></td>
                      {/* <td colSpan="2" style={{  paddingLeft: '39px', border: '1px solid #000' }}>Qty. Total</td> */}
                      <td></td>
                      <td
                        style={{
                          textAlign: "left",
                          paddingLeft: "11px",
                          border: "1px solid #000",
                          fontWeight:"bold",
                          fontSize:18
                        }}
                      >
                        {totalQuantity}
                      </td>
                      <td></td>
                      <td
                        style={{
                          textAlign: "left",
                          paddingLeft: "11px",
                          border: "1px solid #000",
                          fontWeight:"bold",
                          fontSize:18,
                          color:'red'
                        }}
                      >
                        Total{" "}
                      </td>

                      <td
                        style={{
                          textAlign: "right",
                          textAlign:"right",
                          paddingRight:10,
                          border: "1px solid #000",
                          fontWeight:"bold",
                          fontSize:18,
                          color:'red'
                        }}
                      >
                        {formData.sub_total}
                      </td>
                    </tr>
                  </tfoot>
                </table>
                <div style={{display:"flex",flexDirection:"column",borderLeft:"1px solid black",borderRight:"1px solid black",borderBottom:"1px solid black",height:245}}>
                  {/* Taxable */}
                 <div style={{width:"100%",display:'flex',flexDirection:'row'}}>
<div  style={{width:"15%",height:90,display:'flex',flexDirection:"column",borderRight:"1px solid black"}}>
  <div style={{borderBottom:"1px solid black",height:30,textAlign:'center'}}>
    <a style={{fontSize:20}}>Taxable</a>
  </div>
  <div style={{borderBottom:"1px solid black",height:30,textAlign:'center'}}>
  <a style={{fontSize:20}}>Amount</a>
  </div>
  <div style={{borderBottom:"1px solid black",height:30,textAlign:'center'}}>
    <text style={{fontSize:20}}>{formData.sub_total}</text>
  </div>
</div>
{/* CGST */}
<div  style={{width:"20%",height:90,display:'flex',flexDirection:"column",borderRight:"1px solid black"}}>
  <div style={{borderBottom:"1px solid black",height:30,textAlign:'center'}}>
    <a style={{fontSize:20}}>CGST</a>
  </div>
  <div style={{borderBottom:"1px solid black",height:30,textAlign:'center',display:'flex',flexDirection:'row'}}>
 <div style={{borderRight:'1px solid black',width:"40%"}}>
  <a style={{fontSize:20}}>Rate</a>
 </div>
 <div style={{width:"70%"}}>
  <a style={{fontSize:20}}>Amount</a>
 </div>
  </div>
  <div style={{borderBottom:"1px solid black",height:30,display:'flex',flexDirection:'row',textAlign:'center'}}>
  <div style={{borderRight:'1px solid black',width:"40%"}}>
  <text style={{fontSize:20}}>9.00%</text>
 </div>
 <div style={{width:"70%"}}>
  <text style={{fontSize:20}}>{formData.cgst}</text>
 </div>
  </div>
</div>
{/* SGST */}
<div  style={{width:"20%",height:90,display:'flex',flexDirection:"column",borderRight:"1px solid black"}}>
  <div style={{borderBottom:"1px solid black",height:30,textAlign:'center'}}>
    <a style={{fontSize:20}}>SGST</a>
  </div>
  <div style={{borderBottom:"1px solid black",height:30,textAlign:'center',display:'flex',flexDirection:'row'}}>
 <div style={{borderRight:'1px solid black',width:"40%"}}>
  <a style={{fontSize:20}}>Rate</a>
 </div>
 <div style={{width:"70%"}}>
  <a style={{fontSize:20}}>Amount</a>
 </div>
  </div>
  <div style={{borderBottom:"1px solid black",height:30,display:'flex',flexDirection:'row',textAlign:'center'}}>
  <div style={{borderRight:'1px solid black',width:"40%"}}>
  <text style={{fontSize:20}}>9.00%</text>
 </div>
 <div style={{width:"70%"}}>
  <text style={{fontSize:20}}>{formData.sgst}</text>
 </div>
  </div>
</div>
{/* IGST */}
<div  style={{width:"20%",height:90,display:'flex',flexDirection:"column",borderRight:"1px solid black"}}>
  <div style={{borderBottom:"1px solid black",height:30,textAlign:'center'}}>
    <a style={{fontSize:20}}>IGST</a>
  </div>
  <div style={{borderBottom:"1px solid black",height:30,textAlign:'center',display:'flex',flexDirection:'row'}}>
 <div style={{borderRight:'1px solid black',width:"40%"}}>
  <a style={{fontSize:20}}>Rate</a>
 </div>
 <div style={{width:"70%"}}>
  <a style={{fontSize:20}}>Amount</a>
 </div>
  </div>
  <div style={{borderBottom:"1px solid black",height:30,display:'flex',flexDirection:'row',textAlign:'center'}}>
  <div style={{borderRight:'1px solid black',width:"40%"}}>
  <text style={{fontSize:20}}>9.00%</text>
 </div>
 <div style={{width:"70%"}}>
  <text style={{fontSize:20}}>{formData.igst}</text>
 </div>
  </div>
</div>
{/* Others */}
<div  style={{width:"15%",height:90,display:'flex',flexDirection:"column",borderRight:"1px solid black"}}>
  <div style={{borderBottom:"1px solid black",height:30,textAlign:'center'}}>
    <a style={{fontSize:20}}>Others</a>
  </div>
  <div style={{borderBottom:"1px solid black",height:30,textAlign:'center'}}>
  <a style={{fontSize:20}}>Amount</a>
  </div>
  <div style={{borderBottom:"1px solid black",height:30,textAlign:'center'}}>
    <text style={{fontSize:20}}>{formData.exp_before}</text>
  </div>
</div>
{/* GrandTotal */}
<div  style={{width:"15%",height:90,display:'flex',flexDirection:"column"}}>
  <div style={{borderBottom:"1px solid black",height:30,textAlign:'center'}}>
    <a style={{fontSize:20}}>Expense</a>
  </div>
  <div style={{borderBottom:"1px solid black",height:30,textAlign:'center'}}>
  <a style={{fontSize:20}}>Amount</a>
  </div>
  <div style={{borderBottom:"1px solid black",height:30,textAlign:'center'}}>
    <text style={{fontSize:20}}>{formData.expafterGST}</text>
  </div>
</div>
</div>
{/* OTHER DETAILS */}
<div style={{display:"flex",flexDirection:'row',height:'100%'}}>
  <div style={{width:"45%",borderRight:"1px solid black",padding:10}}>
    <text style={{fontSize:20}}>Remarks: {formData.rem2}</text>
  </div>
  {/* Labour */}
  <div style={{display:'flex',flexDirection:'column',width:"30%",height:"100%",marginLeft:10,borderRight:"1px solid"}}>
<a style={{fontSize:20}}>Labour:</a>
<a style={{fontSize:20}}>Postage:</a>
<a style={{fontSize:20}}>Discount:</a>
<a style={{fontSize:20}}>Freight:</a>
<a style={{fontSize:20}}>Expense5:</a>
</div>
{/* sd */}
<div style={{display:'flex',flexDirection:'column',width:"20%",height:"100%",textAlign:'right',marginRight:20}}>
<text style={{fontSize:20,color:'red'}}>Total Tax: {formData.tax}</text>
<text style={{fontSize:20,color:'red'}}>Grand Total: {formData.grandtotal}</text>
</div>
</div>
                  {/* EXPENSE */}
                  
                 
                </div>
                <div style={{height:30,borderRight:"1px solid black",borderLeft:"1px solid black",borderBottom:"1px solid black"}}>
                  <text style={{fontSize:20,color:'red'}}>Rs.(InWords):{totalInWords}</text>
                </div>
                <div style={{display:"flex",flexDirection:"row",borderLeft:"1px solid black",borderRight:"1px solid black",borderBottom:"1px solid black",height:120}}>
               <div style={{width:"50%",borderRight:"1px solid black"}}>
                <text style={{marginLeft:10,fontSize:17,textDecoration:"underline"}}>Our Bank:</text>
                <text style={{fontSize:16,marginLeft:20}}>{shopName}</text>
                <div style={{display:'flex',flexDirection:'column'}}>
                <text style={{fontSize:16,marginLeft:"24%"}}>A/C No.5022334421341</text>
                <text style={{fontSize:16,marginLeft:"24%"}}>IFSC.HDFC0002763</text>
                <text style={{fontSize:16,marginLeft:"24%"}}>BANK-HDFC BANK LTD</text>
                <text style={{fontSize:16,marginLeft:"24%"}}>MANDI GOBINDGARH</text>
                </div>
               </div>
               <div style={{display:'flex',flexDirection:"column",marginTop:20,textAlign:'center',marginLeft:40}}>
                <text style={{fontSize:20}}>Received the above goods in good conditions,</text>
                <text  style={{fontSize:20}}>Rate & Weight of this bill found correct</text>
               </div>
                </div>
                {/*  */}
                <div style={{display:"flex",flexDirection:"row",borderLeft:"1px solid black",borderRight:"1px solid black",borderBottom:"1px solid black",height:180}}>
               <div style={{width:"72%",display:'flex',flexDirection:'column'}}>
                <text style={{fontSize:20,textDecoration:'underline',marginLeft:10}}>Terms & Conditions:</text>
                <a style={{marginLeft:10,fontSize:18}}>1.Our responsibility ceases after the goods are removed from our premises.</a>
                <a style={{marginLeft:10,fontSize:18}}>2.Goods once sold are not returnable or exchangeable.</a>
                <a style={{marginLeft:10,fontSize:18}}>3.If the bill is not paid within a week intrest@25% will be charged from the date of bill.</a>
                <a style={{marginLeft:10,fontSize:18}}>Subjected to FATEHGARH SAHIB Jurisdiction Only.</a>
                <div style={{display:'flex',flexDirection:'row',marginTop:5}}>
                  <text style={{fontSize:22,marginLeft:15}}>E.& O.E</text>
                  <text style={{fontSize:22,marginLeft:"42%"}}>Checked/Prepared by</text>
                </div>
               </div>
               <div style={{display:'flex',flexDirection:"column",marginTop:30,marginLeft:40}}>
              <text style={{fontSize:20}}>FOR {shopName}</text>
              <text style={{fontSize:22,marginTop:"33%",marginLeft:20}}>Authorised Signature</text>
               </div>
                </div>
                <div style={{ fontSize: "12px" }}>
                  <text>Footer content specific to page {pageIndex + 1}</text>
                </div>
              </div>
            ))}
          </div>
        </Box>
      </Modal>
    );
  });
  export default InvoicePur3;