import React, { useRef, useEffect, useState } from 'react';
import { useReactToPrint } from 'react-to-print';
import { Modal, Box, Button } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import Logo from './printerpic.png'
const PrintBazar = React.forwardRef(({
    formData,
    items,
    supplierdetails,
    isOpen, // Changed from 'open' to 'isOpen'
    handleClose,
    GSTIN,
    PAN,
    shopName,
    description,
    address
  }, ref) => {
    const chunkItems = (items, firstChunkSize, otherChunkSize) => {
      const chunks = [];
      let i = 0;
      // Handle the first chunk with a specific size
      if (items.length > 0) {
        chunks.push(items.slice(i, i + firstChunkSize));
        i += firstChunkSize;
      }
      // Handle all other chunks with a different size
      while (i < items.length) {
        chunks.push(items.slice(i, i + otherChunkSize));
        i += otherChunkSize;
      }
      return chunks;
    };
    // Split items into chunks of 10
    const chunks = chunkItems(items, 10, 20);

    const [totalQuantity, setTotalQuantity] = useState(0);
    // Function to calculate total quantity
    const calculateTotalQuantity = () => {
      const total = items.reduce((accumulator, currentItem) => {
        return accumulator + Number(currentItem.weight);
      }, 0);
      setTotalQuantity(total);
    };
    useEffect(() => {
      calculateTotalQuantity();
    }, [items]);

    const style = {
      bgcolor: "white",
      boxShadow: 24,
      p: 4,
      overflowY: "auto",
    };

    const componentRef = useRef();
    const handlePrint = useReactToPrint({
      content: () => componentRef.current,
    });
    function numberToIndianWords(num) {
      const ones = [
          "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
          "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
          "Seventeen", "Eighteen", "Nineteen"
      ];
      const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
      const scales = ["", "Thousand", "Lakh", "Crore"];
  
      if (num === 0) return "Zero Rupees";
  
      function convertHundred(n) {
          let result = "";
          if (n >= 100) {
              result += ones[Math.floor(n / 100)] + " Hundred ";
              n %= 100;
          }
          if (n >= 20) {
              result += tens[Math.floor(n / 10)] + " ";
              n %= 10;
          }
          if (n > 0) {
              result += ones[n] + " ";
          }
          return result.trim();
      }
  
      function convertDecimal(decimalPart) {
          let result = "";
          for (let digit of decimalPart) {
              result += ones[parseInt(digit)] + " ";
          }
          return result.trim();
      }
  
      let [whole, decimal] = num.toString().split(".");
      let word = "";
  
      // Convert the whole number part using Indian numbering system
      let scaleIndex = 0;
      while (whole.length > 0) {
          let part = 0;
          if (scaleIndex === 0) { // Last 3 digits for Thousand
              part = parseInt(whole.slice(-3));
              whole = whole.slice(0, -3);
          } else { // Next 2 digits for Lakh, Crore, etc.
              part = parseInt(whole.slice(-2));
              whole = whole.slice(0, -2);
          }
  
          if (part > 0) {
              word = convertHundred(part) + " " + scales[scaleIndex] + " " + word;
          }
          scaleIndex++;
      }
  
      word = word.trim() + " Rupees";
  
      // Convert the decimal part if present
      if (decimal) {
          word += " and " + convertDecimal(decimal) + " Paise";
      }
  
      return word.trim();
  }
  
  // Example usage with formData.grandtotal
  let totalInWords = numberToIndianWords(formData.grandtotal);

    return (
      <Modal
        open={isOpen}
        style={{ overflow: "auto" }}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <button className="close-button" onClick={handleClose}>
            <CloseIcon />
          </button>
          <Button
            className="Button"
            style={{ color: "black", backgroundColor: "lightcoral" }}
            onClick={handlePrint}
          >
            Print
          </Button>
          <text style={{ fontWeight: "bold", fontSize: 30, marginLeft: "32%" }}>
            This Is The Preview of Bill
          </text>
          <div
            ref={componentRef}
            style={{
              width: "210mm",
              minHeight: "148mm",
              margin: "auto",
              padding: "20px",
              border: "1px solid #000",
              borderRadius: "5px",
              boxSizing: "border-box",
              marginTop: 5,
            }}
          >
            {chunks.map((chunk, pageIndex) => (
              <div
                key={pageIndex}
                style={{
                  minHeight: "257mm",
                  marginBottom: "20px",
                  pageBreakAfter:
                    pageIndex === chunks.length - 1 ? "auto" : "always", // Changed 'avoid' to 'auto'
                }}
              >
                {pageIndex === 0 && (
                  <div>
                    <div style={{marginLeft:"40%"}}> <text   style={{marginBottom: 0,fontWeight: "bold",fontSize: 20,}}>BILL/CASH</text></div>
                     <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          marginLeft: "80%",
                          marginTop:-40
                        }}
                      >
                        <p
                          style={{
                            marginBottom: 0,
                            fontWeight: "bold",
                            fontSize: 20,
                          }}
                        >
                          Ph:9988322376
                        </p>
                        <p
                          style={{
                            marginBottom: 0,
                            fontWeight: "bold",
                            fontSize: 20,
                          }}
                        >
                          Cell:
                        </p>
                      </div>
                    <div style={{ textAlign: "center", height: 120,marginTop:-20}}>
                      <text
                        style={{
                          fontSize: 60,
                          fontWeight: "600",
                          fontFamily: "serif",
                          color:'darkblue'
                        }}
                      >
                        {"DEEPAK PRINT BAZAR"}
                      </text>
                    </div>
                  <div style={{width: "105%",height:50,backgroundColor:"yellow",display:'flex',flexDirection:'column',marginLeft:-19,marginTop:-45}}>
                    <text style={{fontSize:17,marginLeft:"20%",letterSpacing:2}}>Computer Accessories,Typing Scanning,Lamination,</text>
                    <text style={{fontSize:17,marginLeft:"20%",letterSpacing:2}}>Spiral Binding,Photostate,Stationary & Internet etc.</text>
                  </div>
                  <text style={{fontSize:20,marginLeft:"30%"}}>Shop No.324,Professor Colony</text>
                  <div style={{display:'flex',flexDirection:'row'}}>
                    <text style={{fontSize:20}}>Bill No.</text>
                    <text style={{fontSize:20,marginLeft:'60%'}}>Dated................................</text>
                  </div>
                  <div style={{display:'flex',flexDirection:'column'}}>
                    <text style={{fontSize:20}}>To......................................................................................................................................</text>
                    <text style={{fontSize:20}}>...........................................................................................................................................</text>
                  </div>
                  </div>
                )}
                  <table
                  style={{
                    width: "100%",
                    borderCollapse: "collapse",
                    borderRight: "1px solid #000",
                    borderLeft: "1px solid #000",
                    borderBottom: "1px solid #000",
                  }}
                >
                  <thead style={{backgroundColor:"lightgrey"}}>
                    <tr>
                    <th style={{ border: "1px solid #000", padding: "8px",textAlign:'center',fontSize:20,width:30 }}>
                        QTY
                      </th>
                      <th style={{ border: "1px solid #000", padding: "8px",textAlign:'center',fontSize:20,width:400 }}>
                        PARTICULARS
                      </th>
                    
                      <th style={{ border: "1px solid #000", padding: "8px",textAlign:'center',fontSize:20 }}>
                        RATE
                      </th>
                      <th style={{ border: "1px solid #000", padding: "8px",textAlign:'center',fontSize:20 }}>
                        AMOUNT
                      </th>
                    </tr>
                  </thead>
                  <tbody style={{ borderBottom: "1px solid black",height:520}}>
                   <tr>
                   <td
                          style={{
                            borderRight: "1px solid black",
                            paddingLeft: 10,
                          }}
                        >

                    </td>
                    <td
                          style={{
                            borderRight: "1px solid black",
                            paddingLeft: 10,
                          }}
                        >
  <img style={{height:120,width:140,marginTop:350}} src={Logo}></img>
                    </td>
                    <td
                          style={{
                            borderRight: "1px solid black",
                            paddingLeft: 10,
                          }}
                        >

                    </td>
                    <td
                          style={{
                            borderRight: "1px solid black",
                            paddingLeft: 10,
                          }}
                        >

                    </td>
                   </tr>
                  </tbody>
                  <tfoot>
                    <tr
                      style={{
                        borderBottom: "1px solid #000",
                        borderLeft: "1px solid #000",
                        borderRight: "1px solid #000",
                      }}
                    >
                      <td
                        colSpan="2"
                        style={{ paddingLeft: "39px", border: "none",fontWeight:"bold",fontSize:18 }}
                      >
                        TOTAL
                      </td>
                      <td
                        style={{
                          textAlign: "left",
                          paddingLeft: "11px",
                          border: "1px solid #000",
                          fontWeight:"bold",
                          fontSize:18
                        }}
                      >
                        {"Amount"}
                      </td>
                    
                      <td
                        style={{
                          textAlign: "left",
                          paddingLeft: "11px",
                          border: "1px solid #000",
                          fontWeight:"bold",
                          fontSize:18,
                          color:'red'
                        }}
                      >
                       
                      </td>
                    </tr>
                  </tfoot>
                </table>
                <div style={{display:"flex",flexDirection:"row",borderLeft:"1px solid black",borderRight:"1px solid black",borderBottom:"1px solid black",height:90}}>  
                  <a style={{fontSize:20,marginTop:60,marginLeft:10}}>E.O.E</a>
                  <a style={{fontSize:20,marginTop:60,marginLeft:"72%"}}>Auth.Signature</a>
                </div>
              </div>
            ))}
          </div>
        </Box>
      </Modal>
    );
  });
  export default PrintBazar;