import React, { useState, useEffect } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import ProductModalCustomer from "../Modals/ProductModalCustomer";
import { ToastContainer, toast } from "react-toastify";
import "react-datepicker/dist/react-datepicker.css";
import axios from "axios";
import "./TdsVoucher.css";
import { Select, MenuItem, FormControl, ButtonGroup } from "@mui/material";
import { Button } from "react-bootstrap";
import TdsSetup from "./TdsSetup";
import { CompanyContext } from '../Context/CompanyContext';
import { useContext } from "react";

const TdsVoucher = () => {

const { company } = useContext(CompanyContext);
  const tenant = company?.databaseName;

  if (!tenant) {
    // you may want to guard here or show an error state,
    // since without a tenant you can’t hit the right API
    console.error("No tenant selected!");
  }

  const [title, setTitle] = useState("(View)");
  const [pressedKey, setPressedKey] = useState(""); // State to hold the pressed key
  const initialColors = [
    "#E9967A",
    "#F0E68C",
    "#FFDEAD",
    "#ADD8E6",
    "#87CEFA",
    "#FFF0F5",
    "#FFC0CB",
    "#D8BFD8",
    "#DC143C",
    "#DCDCDC",
    "#8FBC8F",
  ];
  const [buttonColors, setButtonColors] = useState(initialColors); // Initial colors
  const [formData, setFormData] = useState({
    date: "",
    vno: 0,
    vtype: "T",
    tdson: "",
    amount: 0,
    others: 0,
    vehicle: "",
    gr: "",
    grdate: "",
    invoiceno: 0,
    invoicedate: "",
    weight: 0,
    tdscode: "",
    rem1: "",
    tds_rate: 0,
    tds_amt: 0,
    tds_srate: 0,
    sur: 0,
    tds_crate: 0,
    cess: 0,
    tds_hrate: 0,
    Hcess: 0,
    tds_tot: 0,
    tds_dep: "",
    tds_ch: 0,
    tds_chq: 0,
    Bank: "",
    post: "",
  });
  const [debitAcc, setdebitAcc] = useState([
    {
      Drcode: "",
      City: "",
    },
  ]);
  const [creditAcc, setcreditAcc] = useState([
    {
      Crcode1: 0,
      Crcode: "",
      city: "",
    },
  ]);
  const [tdsRetAcc, settdsRetAcc] = useState([
    {
      Cacode: "",
      Pan: "",
    },
  ]);
  const [TdsAcc, setTdsAcc] = useState([
    {
      tdscode: "",
    },
  ]);

  const [selectedDate, setSelectedDate] = useState(new Date());
  const [dayName, setDayName] = useState("");
  const getDayName = (date) => {
    const daysOfWeek = [
      "Sunday",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
    ];
    return daysOfWeek[date.getDay()];
  };
  // Search functions
  useEffect(() => {
    if (formData.date) {
      try {
        const date = new Date(formData.date);
        if (!isNaN(date.getTime())) {
          // Ensure the date is valid
          setSelectedDate(date);
          setDayName(getDayName(date));
        } else {
          console.error("Invalid date value in formData.date:", formData.date);
        }
      } catch (error) {
        console.error("Error parsing date:", error);
      }
    } else {
      // If no date exists in formData, handle the "else" part
      const today = new Date();
      const formattedDate = today.toISOString().split("T")[0];
      setSelectedDate(today);
      setDayName(getDayName(today));
      setFormData({ ...formData, date: formattedDate });
    }
  }, [formData.date, setFormData]);

  const [grdate, setgrdate] = useState(null);
  useEffect(() => {
    if (formData.grdate) {
      setgrdate(new Date(formData.grdate));
    } else {
      const today = new Date();
      setgrdate(today);
      setFormData({ ...formData, grdate: today });
    }
  }, [formData.grdate, setFormData]);

  // INVOICE DATE
  const [invoiceDate, setinvoiceDate] = useState(null);
  useEffect(() => {
    if (formData.invoicedate) {
      setinvoiceDate(new Date(formData.invoicedate));
    } else {
      const today = new Date();
      setinvoiceDate(today);
      setFormData({ ...formData, invoicedate: today });
    }
  }, [formData.invoicedate, setFormData]);

  // DEPOSIT DATE
  const [depDate, setdepDate] = useState(null);
  useEffect(() => {
    if (formData.tds_dep) {
      setdepDate(new Date(formData.tds_dep));
    } else {
      const today = new Date();
      setdepDate(today);
      setFormData({ ...formData, tds_dep: today });
    }
  }, [formData.tds_dep, setFormData]);

  const handleDateChange = (date) => {
    setgrdate(date);
    setFormData({ ...formData, grdate: date });
  };
  const handleDateChange2 = (date) => {
    setinvoiceDate(date);
    setFormData({ ...formData, invoicedate: date });
  };
  const handleDateChange3 = (date) => {
    setinvoiceDate(date);
    setFormData({ ...formData, tds_dep: date });
  };
  // FETCH DATA
  const [data, setData] = useState([]);
  const [data1, setData1] = useState([]);
  const [index, setIndex] = useState(0);
  const [isAddEnabled, setIsAddEnabled] = useState(true);
  const [isSubmitEnabled, setIsSubmitEnabled] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false); // State to track edit mode
  const [isAbcmode, setIsAbcmode] = useState(false);
  const [isDisabled, setIsDisabled] = useState(false); // State to track field disablement
  const [firstTimeCheckData, setFirstTimeCheckData] = useState("");
  const fetchData = async () => {
    try {
      const response = await axios.get(
        `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/tdsvoucher/last`
      );
      console.log("Response: ", response.data.data);
      if (response.status === 200 && response.data && response.data.data) {
        const lastEntry = response.data.data;
        setFirstTimeCheckData("DataAvailable");
        setFormData(lastEntry.formData);
        // Update items and supplier details
        const updatedItems = lastEntry.debitAcc.map((item) => ({
          ...item,
        }));
        const updatedCustomer = lastEntry.creditAcc.map((item) => ({
          ...item,
        }));
        const updatedshipped = lastEntry.tdsRetAcc.map((item) => ({
          ...item,
        }));
        const updatedTdsAcc = lastEntry.TdsAcc.map((item) => ({
          ...item,
        }));
        setdebitAcc(updatedItems);
        setcreditAcc(updatedCustomer);
        settdsRetAcc(updatedshipped);
        setTdsAcc(updatedTdsAcc);
        // Set data and index
        setData1(lastEntry);
        setIndex(lastEntry.vno);
      } else {
        setFirstTimeCheckData("DataNotAvailable");
        console.log("No data available");
        initializeEmptyData();
      }
    } catch (error) {
      console.error("Error fetching data", error);
      initializeEmptyData();
    }
  };
  // Function to initialize empty data
  const initializeEmptyData = () => {
    // Default date as current date
    const emptyFormData = {
      date: new Date().toLocaleDateString(), // Use today's date
      date: "",
      vno: 0,
      vtype: "T",
      tdson: "",
      amount: 0,
      others: 0,
      vehicle: "",
      gr: "",
      grdate: "",
      invoiceno: 0,
      invoicedate: "",
      weight: 0,
      tdscode: "",
      rem1: "",
      tds_rate: 0,
      tds_amt: 0,
      tds_srate: 0,
      sur: 0,
      tds_crate: 0,
      cess: 0,
      tds_hrate: 0,
      Hcess: 0,
      tds_tot: 0,
      tds_dep: "",
      tds_ch: 0,
      tds_chq: 0,
      Bank: "",
      post: "",
    };
    const emptyItems = [
      {
        Drcode: "",
        City: "",
      },
    ];
    const emptyshipped = [
      {
        Crcode1: 0,
        Crcode: "",
        city: "",
      },
    ];
    const emptycustomer = [
      {
        Cacode: "",
        Pan: "",
      },
    ];
    // Set the empty data
    setFormData(emptyFormData);
    setdebitAcc(emptyItems);
    setcreditAcc(emptycustomer);
    settdsRetAcc(emptyshipped);
    setData1({
      formData: emptyFormData,
      debitAcc: emptyItems,
      creditAcc: emptyshipped,
      tdsRetAcc: emptycustomer,
    }); // Store empty data
    setIndex(0);
  };
  useEffect(() => {
    fetchData(); // Fetch data when component mounts
  }, []);
  const handleInputChange = (event) => {
    const { id, value } = event.target;
    setFormData((prevData) => ({
      ...prevData,
      [id]: value,
    }));
  };
  const handleNumberChange = (event) => {
    const { id, value } = event.target;
    const newValue = parseFloat(value) || 0;
    const updatedFormData = {
      ...formData,
      [id]: newValue,
    };

    if (
      id === "tds_rate" ||
      id === "tds_srate" ||
      id === "tds_crate" ||
      id === "tds_hrate" ||
      id === "amount"
    ) {
      const amount = parseFloat(updatedFormData.amount) || 0;
      const tds_rate = parseFloat(updatedFormData.tds_rate) || 0;
      const tds_srate = parseFloat(updatedFormData.tds_srate) || 0;
      const tds_crate = parseFloat(updatedFormData.tds_crate) || 0;
      const tds_hrate = parseFloat(updatedFormData.tds_hrate) || 0;

      updatedFormData.tds_amt = (tds_rate / 100) * amount;
      updatedFormData.sur = (tds_srate / 100) * amount;
      updatedFormData.cess = (tds_crate / 100) * amount;
      updatedFormData.Hcess = (tds_hrate / 100) * amount;
      updatedFormData.tds_tot =
        updatedFormData.tds_amt +
        updatedFormData.sur +
        updatedFormData.cess +
        updatedFormData.Hcess;
    }

    setFormData(updatedFormData);
  };

  // Modal For Customer
  React.useEffect(() => {
    // Fetch products from the API when the component mounts
    fetchCustomers();
  }, []);

  const fetchCustomers = async () => {
    try {
      const response = await fetch(
        `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/ledgerAccount`
      );
      if (!response.ok) {
        throw new Error("Failed to fetch products");
      }
      const data = await response.json();
      //   console.log(data);
      // Ensure to extract the formData for easier access in the rest of your app
      const formattedData = data.map((item) => ({
        ...item.formData,
        _id: item._id,
      }));
      setProductsCus(formattedData);
      setLoadingCus(false);
      setProductsDebit(formattedData);
      setLoadingDebit(false);
      setProductsAcc(formattedData);
      setLoadingAcc(false);
      setProductsTdsAcc(formattedData);
      setLoadingTdsAcc(false);
    } catch (error) {
      setErrorCus(error.message);
      setLoadingCus(false);
      setErrorDebit(error.message);
      setLoadingDebit(false);
      setErrorAcc(error.message);
      setLoadingAcc(false);
      setErrorTdsAcc(error.message);
      setLoadingTdsAcc(false);
    }
  };
  const [productsCus, setProductsCus] = useState([]);
  const [showModalCus, setShowModalCus] = useState(false);
  const [selectedItemIndexCus, setSelectedItemIndexCus] = useState(null);
  const [loadingCus, setLoadingCus] = useState(true);
  const [errorCus, setErrorCus] = useState(null);
  const handleItemChangeCus = (index, key, value) => {
    const updatedItems = [...creditAcc];
    updatedItems[index][key] = value;
    // If the key is 'name', find the corresponding product and set the price
    if (key === "name") {
      const selectedProduct = productsCus.find(
        (product) => product.ahead === value
      );
      if (selectedProduct) {
        updatedItems[index]["Crcode1"] = selectedProduct.acode;
        updatedItems[index]["Crcode"] = selectedProduct.ahead;
        updatedItems[index]["city"] = selectedProduct.city;
      }
    }
    setcreditAcc(updatedItems);
  };

  const handleProductSelectCus = (product) => {
    if (selectedItemIndexCus !== null) {
      handleItemChangeCus(selectedItemIndexCus, "name", product.ahead);
      setShowModalCus(false);
    }
  };
  const openModalForItemCus = (index) => {
    if (isEditMode) {
      setSelectedItemIndexCus(index);
      setShowModalCus(true);
    }
  };
  const allFieldsCus = productsCus.reduce((fields, product) => {
    Object.keys(product).forEach((key) => {
      if (!fields.includes(key)) {
        fields.push(key);
      }
    });

    return fields;
  }, []);

  const handleTdsOn = (event) => {
    const { value } = event.target; // Get the selected value from the event
    setFormData((prevState) => ({
      ...prevState,
      tdson: value, // Update the ratecalculate field in FormData
    }));
  };

  // Modal For Credit
  const [productsAcc, setProductsAcc] = useState([]);
  const [showModalAcc, setShowModalAcc] = useState(false);
  const [selectedItemIndexAcc, setSelectedItemIndexAcc] = useState(null);
  const [loadingAcc, setLoadingAcc] = useState(true);
  const [errorAcc, setErrorAcc] = useState(null);

  const handleItemChangeAcc = (index, key, value) => {
    const updatedItems = [...tdsRetAcc];
    updatedItems[index][key] = value;
    // If the key is 'name', find the corresponding product and set the price
    if (key === "acName") {
      const selectedProduct = productsCus.find(
        (product) => product.ahead === value
      );
      if (selectedProduct) {
        updatedItems[index]["Cacode"] = selectedProduct.ahead;
        updatedItems[index]["Pan"] = selectedProduct.pan;
      }
    }
    settdsRetAcc(updatedItems);
  };
  const handleProductSelectAcc = (product) => {
    if (selectedItemIndexAcc !== null) {
      handleItemChangeAcc(selectedItemIndexAcc, "acName", product.ahead);
      setShowModalAcc(false);
    }
  };

  const openModalForItemAcc = (index) => {
    if (isEditMode) {
      setSelectedItemIndexAcc(index);
      setShowModalAcc(true);
    }
  };
  const allFieldsAcc = productsAcc.reduce((fields, product) => {
    Object.keys(product).forEach((key) => {
      if (!fields.includes(key)) {
        fields.push(key);
      }
    });

    return fields;
  }, []);

  // Modal For Debit
  const [productsDebit, setProductsDebit] = useState([]);
  const [showModalDebit, setShowModalDebit] = useState(false);
  const [selectedItemIndexDebit, setSelectedItemIndexDebit] = useState(null);
  const [loadingDebit, setLoadingDebit] = useState(true);
  const [errorDebit, setErrorDebit] = useState(null);

  const handleItemChangeDebit = (index, key, value) => {
    const updatedItems = [...debitAcc];
    updatedItems[index][key] = value;
    // If the key is 'name', find the corresponding product and set the price
    if (key === "ahead") {
      const selectedProduct = productsCus.find(
        (product) => product.ahead === value
      );
      if (selectedProduct) {
        updatedItems[index]["Drcode"] = selectedProduct.ahead;
        updatedItems[index]["City"] = selectedProduct.city;
      }
    }
    setdebitAcc(updatedItems);
  };
  const handleProductSelectDebit = (product) => {
    if (selectedItemIndexDebit !== null) {
      handleItemChangeDebit(selectedItemIndexDebit, "ahead", product.ahead);
      setShowModalDebit(false);
    }
  };

  const openModalForItemDebit = (index) => {
    if (isEditMode) {
      setSelectedItemIndexDebit(index);
      setShowModalDebit(true);
    }
  };
  const allFieldsDebit = productsDebit.reduce((fields, product) => {
    Object.keys(product).forEach((key) => {
      if (!fields.includes(key)) {
        fields.push(key);
      }
    });

    return fields;
  }, []);

  // Modal For TdsAcc
  const [productsTdsAcc, setProductsTdsAcc] = useState([]);
  const [showModalTdsAcc, setShowModalTdsAcc] = useState(false);
  const [selectedItemIndexTdsAcc, setSelectedItemIndexTdsAcc] = useState(null);
  const [loadingTdsAcc, setLoadingTdsAcc] = useState(true);
  const [errorTdsAcc, setErrorTdsAcc] = useState(null);

  const handleItemChangeTdsAcc = (index, key, value) => {
    const updatedItems = [...TdsAcc];
    updatedItems[index][key] = value;
    // If the key is 'ahead', find the corresponding product and set the code
    if (key === "ahead") {
      const selectedProduct = productsTdsAcc.find(
        (product) => product.ahead === value
      );
      if (selectedProduct) {
        updatedItems[index]["tdscode"] = selectedProduct.ahead;
      }
    }
    setTdsAcc(updatedItems);
  };

  const handleProductSelectTdsAcc = (product) => {
    if (selectedItemIndexTdsAcc !== null) {
      handleItemChangeTdsAcc(selectedItemIndexTdsAcc, "ahead", product.ahead);
      setShowModalTdsAcc(false);
    }
  };

  const openModalForItemTdsAcc = (index) => {
    if (isEditMode) {
      setSelectedItemIndexTdsAcc(index);
      setShowModalTdsAcc(true);
    }
  };

  const allFieldsTdsAcc = productsTdsAcc.reduce((fields, product) => {
    Object.keys(product).forEach((key) => {
      if (!fields.includes(key)) {
        fields.push(key);
      }
    });
    return fields;
  }, []);

  const handleOpenModal = (event, index, field) => {
    if (/^[a-zA-Z]$/.test(event.key) && field === "Crcode") {
      setPressedKey(event.key); // Set the pressed key
      openModalForItemCus(index);
      event.preventDefault(); // Prevent any default action
    }
    if (/^[a-zA-Z]$/.test(event.key) && field === "Cacode") {
      setPressedKey(event.key); // Set the pressed key
      openModalForItemAcc(index);
      event.preventDefault(); // Prevent any default action
    }
    if (/^[a-zA-Z]$/.test(event.key) && field === "Drcode") {
      setPressedKey(event.key); // Set the pressed key
      openModalForItemDebit(index);
      event.preventDefault(); // Prevent any default action
    }
    if (/^[a-zA-Z]$/.test(event.key) && field === "tdscode") {
      setPressedKey(event.key); // Set the pressed key
      openModalForItemTdsAcc(index);
      event.preventDefault(); // Prevent any default action
    }
  };
  const handleNext = async () => {
    document.body.style.backgroundColor = "white";
    setTitle("(View)");

    try {
      if (data1) {
        const response = await axios.get(
          `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/tdsvoucher/next/${data1._id}`
        );
        if (response.status === 200 && response.data) {
          const nextData = response.data.data;
          setData1(nextData);
          setIndex(index + 1);
          setFormData(nextData.formData);

          // Update items and supplier details
          const updatedDebit = nextData.debitAcc.map((item) => ({
            ...item,
          }));
          const updatedCredit = nextData.creditAcc.map((item) => ({
            ...item,
          }));
          const updatedTdsAcc = nextData.tdsRetAcc.map((item) => ({
            ...item,
          }));
          const updatedTdsAcc2 = nextData.TdsAcc.map((item) => ({
            ...item,
          }));
          setTdsAcc(updatedTdsAcc2);
          setdebitAcc(updatedDebit);
          setcreditAcc(updatedCredit);
          settdsRetAcc(updatedTdsAcc);
          setIsDisabled(true);
        }
      }
    } catch (error) {
      console.error("Error fetching next record:", error);
    }
  };

  const handlePrevious = async () => {
    document.body.style.backgroundColor = "white";
    setTitle("(View)");

    try {
      if (data1) {
        const response = await axios.get(
          `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/tdsvoucher/previous/${data1._id}`
        );
        if (response.status === 200 && response.data) {
          const prevData = response.data.data;
          setData1(prevData);
          setIndex(index - 1);
          setFormData(prevData.formData);
          // Update items and supplier details
          const updatedDebit = prevData.debitAcc.map((item) => ({
            ...item,
          }));
          const updatedCredit = prevData.creditAcc.map((item) => ({
            ...item,
          }));
          const updatedTdsAcc = prevData.tdsRetAcc.map((item) => ({
            ...item,
          }));
          const updatedTdsAcc2 = prevData.TdsAcc.map((item) => ({
            ...item,
          }));
          setTdsAcc(updatedTdsAcc2);
          setdebitAcc(updatedDebit);
          setcreditAcc(updatedCredit);
          settdsRetAcc(updatedTdsAcc);
          setIsDisabled(true);
        }
      }
    } catch (error) {
      console.error("Error fetching previous record:", error);
    }
  };

  const handleFirst = async () => {
    document.body.style.backgroundColor = "white";
    setTitle("(View)");

    try {
      const response = await axios.get(
        `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/tdsvoucher/first`
      );
      if (response.status === 200 && response.data) {
        const firstData = response.data.data;
        setData1(firstData);
        setIndex(0);
        setFormData(firstData.formData);
        // Update items and supplier details
        const updatedDebit = firstData.debitAcc.map((item) => ({
          ...item,
        }));
        const updatedCredit = firstData.creditAcc.map((item) => ({
          ...item,
        }));
        const updatedTdsAcc = firstData.tdsRetAcc.map((item) => ({
          ...item,
        }));
        const updatedTdsAcc2 = firstData.TdsAcc.map((item) => ({
          ...item,
        }));
        setTdsAcc(updatedTdsAcc2);
        setdebitAcc(updatedDebit);
        setcreditAcc(updatedCredit);
        settdsRetAcc(updatedTdsAcc);
        setIsDisabled(true);
      }
    } catch (error) {
      console.error("Error fetching first record:", error);
    }
  };

  const handleLast = async () => {
    document.body.style.backgroundColor = "white";
    setTitle("(View)");

    try {
      const response = await axios.get(
        `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/tdsvoucher/last`
      );
      if (response.status === 200 && response.data) {
        const lastData = response.data.data;
        setData1(lastData);
        const lastIndex = response.data.length - 1;
        setIndex(lastIndex);
        setFormData(lastData.formData);
        // Update items and supplier details
        const updatedDebit = lastData.debitAcc.map((item) => ({
          ...item,
        }));
        const updatedCredit = lastData.creditAcc.map((item) => ({
          ...item,
        }));
        const updatedTdsAcc = lastData.tdsRetAcc.map((item) => ({
          ...item,
        }));
        const updatedTdsAcc2 = lastData.TdsAcc.map((item) => ({
          ...item,
        }));
        setTdsAcc(updatedTdsAcc2);
        setdebitAcc(updatedDebit);
        setcreditAcc(updatedCredit);
        settdsRetAcc(updatedTdsAcc);
        setIsDisabled(true);
      }
    } catch (error) {
      console.error("Error fetching last record:", error);
    }
  };
  const handleAdd = async () => {
    try {
      let lastvoucherno = formData.vno ? parseInt(formData.vno) + 1 : 1;
      const newData = {
        date: "",
        vno: lastvoucherno,
        vtype: "T",
        tdson: "",
        amount: 0,
        others: 0,
        vehicle: "",
        gr: "",
        grdate: "",
        invoiceno: 0,
        invoicedate: "",
        weight: 0,
        tdscode: "",
        rem1: "",
        tds_rate: 0,
        tds_amt: 0,
        tds_srate: 0,
        sur: 0,
        tds_crate: 0,
        cess: 0,
        tds_hrate: 0,
        Hcess: 0,
        tds_tot: 0,
        tds_dep: "",
        tds_ch: 0,
        tds_chq: 0,
        Bank: "",
        post: "",
      };
      setData([...data, newData]);
      setFormData(newData);
      setcreditAcc([
        {
          Crcode1: "",
          Crcode: "",
          city: "",
        },
      ]);
      settdsRetAcc([
        {
          Cacode: "",
          Pan: "",
        },
      ]);
      setdebitAcc([
        {
          Drcode: "",
          City: "",
        },
      ]);
      setTdsAcc([
        {
          tdscode: "",
        },
      ]);
      setTitle("(New)");
      setIndex(data.length);
      setIsAddEnabled(false);
      setIsSubmitEnabled(true);
      setIsDisabled(false);
      setIsEditMode(true);
    } catch (error) {
      console.error("Error adding new entry:", error);
    }
  };
  const handleExitClick = async () => {
    document.body.style.backgroundColor = "white"; // Reset background color
    setIsAddEnabled(true); // Enable "Add" button
    try {
      const response = await axios.get(
        `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/tdsvoucher/last`
      ); // Fetch the latest data
      if (response.status === 200 && response.data.data) {
        // If data is available
        const lastEntry = response.data.data;
        setFormData(lastEntry.formData); // Set form data
        setData1(response.data.data);
        // Update items and supplier details
        const updatedDebit = lastEntry.debitAcc.map((item) => ({
          ...item,
        }));
        const updatedCredit = lastEntry.creditAcc.map((item) => ({
          ...item,
        }));
        const updatedTdsAcc = lastEntry.tdsRetAcc.map((item) => ({
          ...item,
        }));
        const updatedTdsAcc2 = lastEntry.TdsAcc.map((item) => ({
          ...item,
        }));
        setTdsAcc(updatedTdsAcc2);
        setdebitAcc(updatedDebit);
        setcreditAcc(updatedCredit);
        settdsRetAcc(updatedTdsAcc);
        setIsDisabled(true);
      } else {
        // If no data is available, initialize with default values
        console.log("No data available");
        const newData = {
          date: "",
          vno: 0,
          vtype: "T",
          tdson: "",
          amount: 0,
          others: 0,
          vehicle: "",
          gr: "",
          grdate: "",
          invoiceno: 0,
          invoicedate: "",
          weight: 0,
          tdscode: "",
          rem1: "",
          tds_rate: 0,
          tds_amt: 0,
          tds_srate: 0,
          sur: 0,
          tds_crate: 0,
          cess: 0,
          tds_hrate: 0,
          Hcess: 0,
          tds_tot: 0,
          tds_dep: "",
          tds_ch: 0,
          tds_chq: 0,
          Bank: "",
          post: "",
        };
        setFormData(newData); // Set default form data
        setdebitAcc([
          {
            Drcode: "",
            City: "",
          },
        ]);
        setcreditAcc([
          {
            Crcode1: "",
            Crcode: "",
            city: "",
          },
        ]);
        settdsRetAcc([
          {
            Cacode: "",
            Pan: "",
          },
        ]);
        setTdsAcc([
          {
            tdscode: "",
          },
        ]);
        setIsDisabled(true); // Disable fields after loading the default data
      }
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  const handleEditClick = () => {
    setTitle("(EDIT)");
    setIsDisabled(false);
    setIsEditMode(true);
    setIsSubmitEnabled(true);
    setIsAbcmode(true);
  };
  const handleSaveClick = async () => {
    document.body.style.backgroundColor = "white";
    let isDataSaved = false;
    try {
      const userConfirmed = window.confirm(
        "Are you sure you want to save the data?"
      );
      if (!userConfirmed) {
        return;
      }
      let combinedData;
      if (isAbcmode) {
        combinedData = {
          _id: formData._id,
          formData: {
            date: selectedDate.toLocaleDateString("en-IN"),
            vno: formData.vno,
            vtype: formData.vtype,
            tdson: formData.tdson,
            amount: formData.amount,
            others: formData.others,
            vehicle: formData.vehicle,
            gr: formData.gr,
            grdate: grdate.toLocaleDateString("en-IN"),
            invoiceno: formData.invoiceno,
            invoicedate: invoiceDate.toLocaleDateString("en-IN"),
            weight: formData.weight,
            tdscode: formData.tdscode,
            rem1: formData.rem1,
            tds_rate: formData.tds_rate,
            tds_amt: formData.tds_amt,
            tds_srate: formData.tds_srate,
            sur: formData.sur,
            tds_crate: formData.tds_crate,
            cess: formData.cess,
            tds_hrate: formData.tds_hrate,
            Hcess: formData.Hcess,
            tds_tot: formData.tds_tot,
            tds_dep: depDate.toLocaleDateString("en-IN"),
            tds_ch: formData.tds_ch,
            tds_chq: formData.tds_chq,
            Bank: formData.Bank,
            post: formData.post,
          },
          debitAcc: debitAcc.map((item) => ({
            Drcode: item.Drcode,
            City: item.City,
          })),
          creditAcc: creditAcc.map((item) => ({
            Crcode1: item.Crcode1,
            Crcode: item.Crcode,
            city: item.city,
          })),
          tdsRetAcc: tdsRetAcc.map((item) => ({
            Cacode: item.Cacode,
            Pan: item.Pan,
          })),
          TdsAcc: TdsAcc.map((item) => ({
            tdscode: item.tdscode,
          })),
        };
      } else {
        combinedData = {
          _id: formData._id,
          formData: {
            date: selectedDate.toLocaleDateString("en-IN"),
            vno: formData.vno,
            vtype: formData.vtype,
            tdson: formData.tdson,
            amount: formData.amount,
            others: formData.others,
            vehicle: formData.vehicle,
            gr: formData.gr,
            grdate: grdate.toLocaleDateString("en-IN"),
            invoiceno: formData.invoiceno,
            invoicedate: invoiceDate.toLocaleDateString("en-IN"),
            weight: formData.weight,
            tdscode: formData.tdscode,
            rem1: formData.rem1,
            tds_rate: formData.tds_rate,
            tds_amt: formData.tds_amt,
            tds_srate: formData.tds_srate,
            sur: formData.sur,
            tds_crate: formData.tds_crate,
            cess: formData.cess,
            tds_hrate: formData.tds_hrate,
            Hcess: formData.Hcess,
            tds_tot: formData.tds_tot,
            tds_dep: depDate.toLocaleDateString("en-IN"),
            tds_ch: formData.tds_ch,
            tds_chq: formData.tds_chq,
            Bank: formData.Bank,
            post: formData.post,
          },
          debitAcc: debitAcc.map((item) => ({
            Drcode: item.Drcode,
            City: item.City,
          })),
          creditAcc: creditAcc.map((item) => ({
            Crcode1: item.Crcode1,
            Crcode: item.Crcode,
            city: item.city,
          })),
          tdsRetAcc: tdsRetAcc.map((item) => ({
            Cacode: item.Cacode,
            Pan: item.Pan,
          })),
          TdsAcc: TdsAcc.map((item) => ({
            tdscode: item.tdscode,
          })),
        };
      }
      // Debugging
      console.log("Combined Data:", combinedData);

      const apiEndpoint = `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/tdsvoucher${
        isAbcmode ? `/${data1._id}` : ""
      }`;
      const method = isAbcmode ? "put" : "post";
      const response = await axios({
        method,
        url: apiEndpoint,
        data: combinedData,
      });

      if (response.status === 200 || response.status === 201) {
        fetchData();
        isDataSaved = true;
      }
    } catch (error) {
      console.error("Error saving data:", error);
      toast.error("Failed to save data. Please try again.", {
        position: "top-center",
      });
    } finally {
      setIsSubmitEnabled(true);
      if (isDataSaved) {
        setTitle("(View)");
        setIsAddEnabled(true);
        setIsDisabled(true);
        setIsEditMode(false);
        toast.success("Data Saved Successfully!", { position: "top-center" });
      } else {
        setIsAddEnabled(false);
        setIsDisabled(false);
      }
    }
  };
  const handleDeleteClick = async (id) => {
    if (!id) {
      toast.error("Invalid ID. Please select an item to delete.", {
        position: "top-center",
      });
      return;
    }
    const userConfirmed = window.confirm(
      "Are you sure you want to delete this item?"
    );
    if (!userConfirmed) return;
    try {
      const apiEndpoint = `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/tdsvoucher/${data1._id}`;
      const response = await axios.delete(apiEndpoint);

      if (response.status === 200) {
        toast.success("Data deleted successfully!", { position: "top-center" });
        fetchData(); // Refresh the data after successful deletion
      } else {
        throw new Error(`Failed to delete data: ${response.statusText}`);
      }
    } catch (error) {
      console.error("Error deleting data:", error);
      toast.error(`Failed to delete data. Error: ${error.message}`, {
        position: "top-center",
      });
    } finally {
    }
  };
  const [isModalOpen, setIsModalOpen] = useState(false);
  const openModal = () => {
    console.log("Modal opened");
    setIsModalOpen(true);
  };
  const closeModal = () => {
    setIsModalOpen(false);
  };
  return (
    <div>
      <ToastContainer/>
      <Button onClick={openModal} style={{ marginLeft: "70%", marginTop: -40 }}>
        SETUP
      </Button>
      {isModalOpen && <TdsSetup onClose={closeModal} />}
      <h1 className="header" style={{ marginTop: -50, fontSize: 35 }}>
        TDS VOUCHER
      </h1>
      <div className="containerTDSvoucher">
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ display: "flex", flexDirection: "row" }}>
            <text>Vch.Date:</text>
            <div style={{ height: 10 }}>
              <DatePicker
                readOnly={!isEditMode || isDisabled}
                className="datepickerVoucher"
                id="date"
                selected={selectedDate}
                onChange={(date) => setSelectedDate(date)}
                dateFormat="dd-MM-yyyy"
              />
            </div>
          </div>
          <div style={{ display: "flex", flexDirection: "row", marginTop: 10 }}>
            <text>Vch.No:</text>
            <input
              readOnly={!isEditMode || isDisabled}
              className="Fields"
              style={{
                height: "30px",
                marginLeft: 12,
                fontWeight: "bold",
                width: 200,
              }}
              id="vno"
              value={formData.vno}
              onChange={handleNumberChange}
            />
            <text style={{ marginLeft: "90%", fontSize: 25, marginTop: -30 }}>
              {title}
            </text>
          </div>
          <div>
            {creditAcc.map((item, index) => (
              <div key={item.Crcode}>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "row",
                    marginTop: 10,
                    marginLeft: "55.8%",
                  }}
                >
                  <input
                    className="Fields"
                    style={{ height: "35px", fontWeight: "bold" }}
                    id="Crcode1"
                    value={item.Crcode1}
                    onChange={handleNumberChange}
                  />
                </div>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    marginTop: 2,
                  }}
                >
                  <text>Credit A/C:</text>
                  <input
                    id="Crcode"
                    type="text"
                    className="Fields"
                    style={{
                      height: "35px",
                      width: 400,
                      marginLeft: 18,
                      fontWeight: "bold",
                    }}
                    value={item.Crcode}
                    onKeyDown={(e) => {
                      handleOpenModal(e, index, "Crcode");
                    }}

                    // onClick={() => openModalForItemCus(index)}
                  />
                </div>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    marginTop: 2,
                  }}
                >
                  <text>City:</text>
                  <input
                    type="text"
                    className="Fields"
                    style={{
                      height: "35px",
                      width: 400,
                      marginLeft: 67,
                      fontWeight: "bold",
                    }}
                    value={item.city}
                    readOnly
                  />
                </div>
              </div>
            ))}
            {showModalCus && (
              <ProductModalCustomer
                allFields={allFieldsCus}
                products={productsCus}
                onSelect={handleProductSelectCus}
                onClose={() => setShowModalCus(false)}
                initialKey={pressedKey} // Pass the pressed key to the modal
              />
            )}
          </div>
          <div style={{ display: "flex", flexDirection: "row", marginTop: 2 }}>
            <text>TdsOn:</text>

            <select
              disabled={!isEditMode || isDisabled}
              className="Fields"
              id="tdson"
              style={{
                height: 35,
                backgroundColor: "white",
                borderColor: "black",
                marginLeft: 50,
                width: 400,
                fontWeight: "bold",
                color: "black",
              }}
              value={formData.tdson}
              onChange={handleTdsOn}
              displayEmpty
              // inputProps={{ "aria-label": "Without label" }}
            >
              <option value={"Interest"}>Interest</option>
              <option value={"Freight"}>Freight</option>
              <option value={"Brokerage"}>Brokerage</option>
              <option value={"Commission"}>Commission</option>
              <option value={"Advertisement"}>Advertisement</option>
              <option value={"Labour"}>Labour</option>
              <option value={"Contract"}>Contract</option>
              <option value={"Job Work"}>Job Work</option>
              <option value={"Salary"}>Salary</option>
              <option value={"Rent"}>Rent</option>
              <option value={"Professional"}>Professional</option>
              <option value={"Purchase"}>Purchase</option>
            </select>
          </div>
          <div>
            {tdsRetAcc.map((item, index) => (
              <div key={item.Cacode}>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    marginTop: 2,
                  }}
                >
                  <text>Tds Ret A/C:</text>
                  <input
                    type="text"
                    className="Fields"
                    style={{
                      height: "35px",
                      width: 400,
                      marginLeft: 10,
                      fontWeight: "bold",
                    }}
                    value={item.Cacode}
                    onKeyDown={(e) => {
                      handleOpenModal(e, index, "Cacode");
                    }}
                    // onClick={() => openModalForItemAcc(index)}
                  />
                </div>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    marginTop: 2,
                  }}
                >
                  <text>Pan:</text>
                  <input
                    type="text"
                    className="Fields"
                    style={{
                      height: "35px",
                      width: 400,
                      marginLeft: 69,
                      fontWeight: "bold",
                    }}
                    value={item.Pan}
                    readOnly
                  />
                </div>
              </div>
            ))}
            {showModalAcc && (
              <ProductModalCustomer
                allFields={allFieldsAcc}
                products={productsAcc}
                onSelect={handleProductSelectAcc}
                onClose={() => setShowModalAcc(false)}
                initialKey={pressedKey} // Pass the pressed key to the modal
              />
            )}
          </div>
          <div style={{ display: "flex", flexDirection: "row", marginTop: 2 }}>
            <text>Amount:</text>
            <input
              readOnly={!isEditMode || isDisabled}
              className="Fields"
              style={{
                height: "35px",
                width: 300,
                marginLeft: 35,
                fontWeight: "bold",
              }}
              id="amount"
              value={formData.amount}
              onChange={handleNumberChange}
            />
          </div>
          <div style={{ display: "flex", flexDirection: "row", marginTop: 2 }}>
            <text>Other Exp:</text>
            <input
              readOnly={!isEditMode || isDisabled}
              className="Fields"
              style={{
                height: "35px",
                width: 300,
                marginLeft: 21,
                fontWeight: "bold",
              }}
              id="others"
              value={formData.others}
              onChange={handleNumberChange}
            />
          </div>
          <div style={{ display: "flex", flexDirection: "row", marginTop: 2 }}>
            <text>Vehicle No:</text>
            <input
              readOnly={!isEditMode || isDisabled}
              className="Fields"
              style={{
                height: "35px",
                width: 300,
                marginLeft: 15,
                fontWeight: "bold",
              }}
              id="vehicle"
              value={formData.vehicle}
              onChange={handleInputChange}
            />
          </div>
          <div style={{ display: "flex", flexDirection: "row", marginTop: 2 }}>
            <text>Gr No:</text>
            <input
              readOnly={!isEditMode || isDisabled}
              className="Fields"
              style={{
                height: "35px",
                width: 300,
                marginLeft: 50,
                fontWeight: "bold",
              }}
              id="gr"
              value={formData.gr}
              onChange={handleNumberChange}
            />
          </div>
          <div style={{ display: "flex", flexDirection: "row", marginTop: 2 }}>
            <text>Grdate:</text>
            <DatePicker
              readOnly={!isEditMode || isDisabled}
              id="duedate"
              value={formData.grdate}
              className="custom-datepickerTDS"
              selected={grdate}
              onChange={handleDateChange}
              dateFormat="dd/MM/yyyy"
            />
          </div>
          <div style={{ display: "flex", flexDirection: "row", marginTop: 2 }}>
            <text>Invoice No:</text>
            <input
              readOnly={!isEditMode || isDisabled}
              className="Fields"
              style={{
                height: "35px",
                width: 300,
                marginLeft: 12,
                fontWeight: "bold",
              }}
              id="invoiceno"
              value={formData.invoiceno}
              onChange={handleNumberChange}
            />
          </div>
          <div style={{ display: "flex", flexDirection: "row", marginTop: 2 }}>
            <text>InvoiceDate:</text>
            <DatePicker
              readOnly={!isEditMode || isDisabled}
              id="duedate"
              value={formData.invoicedate}
              className="custom-datepickerInvo"
              selected={invoiceDate}
              onChange={handleDateChange2}
              placeholderText="InvoiceDate"
              dateFormat="dd/MM/yyyy"
            />
          </div>
          <div style={{ display: "flex", flexDirection: "row", marginTop: 2 }}>
            <text>Weight:</text>
            <input
              readOnly={!isEditMode || isDisabled}
              className="Fields"
              style={{
                height: "35px",
                width: 300,
                marginLeft: 37,
                fontWeight: "bold",
              }}
              id="weight"
              value={formData.weight}
              onChange={handleNumberChange}
            />
          </div>
        </div>
        {/* Right Section */}
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            marginTop: 70,
            marginLeft: 25,
          }}
        >
          <div>
            {debitAcc.map((item, index) => (
              <div key={item.Drcode}>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "row",
                    marginTop: 2,
                  }}
                >
                  <text>DebitA/c:</text>
                  <input
                    type="text"
                    className="Fields"
                    style={{
                      height: "35px",
                      width: 400,
                      marginLeft: 10,
                      fontWeight: "bold",
                    }}
                    value={item.Drcode}
                    onKeyDown={(e) => {
                      handleOpenModal(e, index, "Drcode");
                    }}
                    // onClick={() => openModalForItemDebit(index)}
                  />
                </div>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    marginTop: 2,
                  }}
                >
                  <text>City:</text>
                  <input
                    type="text"
                    className="Fields"
                    style={{
                      height: "35px",
                      width: 400,
                      marginLeft: 48,
                      fontWeight: "bold",
                    }}
                    value={item.City}
                    readOnly
                  />
                </div>
              </div>
            ))}
            {showModalDebit && (
              <ProductModalCustomer
                allFields={allFieldsDebit}
                products={productsDebit}
                onSelect={handleProductSelectDebit}
                onClose={() => setShowModalDebit(false)}
                initialKey={pressedKey} // Pass the pressed key to the modal
              />
            )}
            <div>
              {TdsAcc.map((item, index) => (
                <div key={item.Cacode}>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      marginTop: 2,
                    }}
                  >
                    <text>Tds A/C:</text>
                    <input
                      id="tdscode"
                      type="text"
                      className="Fields"
                      style={{
                        height: "35px",
                        width: 400,
                        marginLeft: 20,
                        fontWeight: "bold",
                      }}
                      value={item.tdscode}
                      onKeyDown={(e) => {
                        handleOpenModal(e, index, "tdscode");
                      }}
                      // onClick={() => openModalForItemAcc(index)}
                    />
                  </div>
                </div>
              ))}
              {showModalTdsAcc && (
                <ProductModalCustomer
                  allFields={allFieldsTdsAcc}
                  products={productsTdsAcc}
                  onSelect={handleProductSelectTdsAcc}
                  onClose={() => setShowModalTdsAcc(false)}
                  initialKey={pressedKey} // Pass the pressed key to the modal
                />
              )}
            </div>
            <div
              style={{ display: "flex", alignItems: "center", marginTop: 2 }}
            >
              <text>Remarks:</text>
              <input
                readOnly={!isEditMode || isDisabled}
                id="rem1"
                type="text"
                className="Fields"
                style={{
                  height: "35px",
                  width: 400,
                  marginLeft: 14,
                  fontWeight: "bold",
                }}
                value={formData.rem1}
                onChange={handleInputChange}
              />
            </div>
          </div>
          {/* TDS BLOCK */}
          <div className="TdsBlock">
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                marginTop: 10,
                marginLeft: 10,
              }}
            >
              <div style={{ display: "flex", flexDirection: "column" }}>
                <div
                  style={{ display: "flex", flexDirection: "row", padding: 5 }}
                >
                  <div style={{ display: "flex", flexDirection: "column" }}>
                    <div style={{ display: "flex", flexDirection: "row" }}>
                      <text>T.D.S:</text>
                      <input
                        readOnly={!isEditMode || isDisabled}
                        id="tds_rate"
                        type="text"
                        className="Fields"
                        style={{
                          height: "30px",
                          width: 120,
                          marginLeft: 27,
                          fontWeight: "bold",
                        }}
                        value={formData.tds_rate}
                        onChange={handleNumberChange}
                      />
                      <input
                        readOnly
                        id="tds_amt"
                        type="text"
                        className="Fields"
                        style={{
                          height: "30px",
                          width: 120,
                          marginLeft: 5,
                          fontWeight: "bold",
                        }}
                        value={formData.tds_amt}
                        onChange={handleNumberChange}
                      />
                    </div>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "row",
                        marginTop: 5,
                      }}
                    >
                      <text>Sur.@:</text>
                      <input
                        readOnly={!isEditMode || isDisabled}
                        id="tds_srate"
                        type="text"
                        className="Fields"
                        style={{
                          height: "30px",
                          width: 120,
                          marginLeft: 20,
                          fontWeight: "bold",
                        }}
                        value={formData.tds_srate}
                        onChange={handleNumberChange}
                      />
                      <input
                        readOnly
                        id="sur"
                        type="text"
                        className="Fields"
                        style={{
                          height: "30px",
                          width: 120,
                          marginLeft: 5,
                          fontWeight: "bold",
                        }}
                        value={formData.sur}
                        onChange={handleNumberChange}
                      />
                    </div>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "row",
                        marginTop: 5,
                      }}
                    >
                      <text>Cess:</text>
                      <input
                        readOnly={!isEditMode || isDisabled}
                        id="tds_crate"
                        type="text"
                        className="Fields"
                        style={{
                          height: "30px",
                          width: 120,
                          marginLeft: 30,
                          fontWeight: "bold",
                        }}
                        value={formData.tds_crate}
                        onChange={handleNumberChange}
                      />
                      <input
                        readOnly
                        id="cess"
                        type="text"
                        className="Fields"
                        style={{
                          height: "30px",
                          width: 120,
                          marginLeft: 5,
                          fontWeight: "bold",
                        }}
                        value={formData.cess}
                        onChange={handleNumberChange}
                      />
                    </div>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "row",
                        marginTop: 5,
                      }}
                    >
                      <text>HE.Cess:</text>
                      <input
                        readOnly={!isEditMode || isDisabled}
                        id="tds_hrate"
                        type="text"
                        className="Fields"
                        style={{
                          height: "30px",
                          width: 120,
                          marginLeft: 5,
                          fontWeight: "bold",
                        }}
                        value={formData.tds_hrate}
                        onChange={handleNumberChange}
                      />
                      <input
                        readOnly
                        id="Hcess"
                        type="text"
                        className="Fields"
                        style={{
                          height: "30px",
                          width: 120,
                          marginLeft: 5,
                          fontWeight: "bold",
                        }}
                        value={formData.Hcess}
                        onChange={handleNumberChange}
                      />
                    </div>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "row",
                        marginTop: 5,
                        marginLeft: 145,
                      }}
                    >
                      <text>Total:</text>
                      <input
                        readOnly
                        id="tds_rate"
                        type="text"
                        className="Fields"
                        style={{
                          height: "30px",
                          width: 120,
                          marginLeft: 5,
                          fontWeight: "bold",
                        }}
                        value={formData.tds_tot}
                        onChange={handleNumberChange}
                      />
                    </div>
                  </div>
                </div>
                {/* deposit left */}
                <div style={{ display: "flex", flexDirection: "row" }}>
                  <div style={{ display: "flex", flexDirection: "column" }}>
                    <text>Deposit Dt</text>
                    <DatePicker
                      readOnly={!isEditMode || isDisabled}
                      id="tds_dep"
                      value={formData.tds_dep}
                      className="custom-datepickerDepo"
                      selected={depDate}
                      onChange={handleDateChange3}
                      placeholderText=""
                      dateFormat="dd/MM/yyyy"
                    />
                  </div>
                  <div style={{ display: "flex", flexDirection: "column" }}>
                    <text>Challan No</text>
                    <input
                      readOnly={!isEditMode || isDisabled}
                      id="tds_ch"
                      type="text"
                      className="Fields"
                      style={{
                        height: "30px",
                        width: 140,
                        marginLeft: 5,
                        fontWeight: "bold",
                      }}
                      value={formData.tds_ch}
                      onChange={handleNumberChange}
                    />
                  </div>
                  <div style={{ display: "flex", flexDirection: "column" }}>
                    <text>Cheque No</text>
                    <input
                      readOnly={!isEditMode || isDisabled}
                      id="tds_chq"
                      type="text"
                      className="Fields"
                      style={{
                        height: "30px",
                        width: 140,
                        marginLeft: 5,
                        fontWeight: "bold",
                      }}
                      value={formData.tds_chq}
                      onChange={handleNumberChange}
                    />
                  </div>
                </div>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "row",
                    marginTop: 10,
                    padding: 5,
                  }}
                >
                  <text>BANK:</text>
                  <input
                    readOnly={!isEditMode || isDisabled}
                    id="Bank"
                    type="text"
                    className="Fields"
                    style={{
                      height: "30px",
                      width: 300,
                      marginLeft: 5,
                      marginBottom: 10,
                      fontWeight: "bold",
                    }}
                    value={formData.Bank}
                    onChange={handleInputChange}
                  />
                </div>
                {/* fit here */}
              </div>

              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  backgroundColor: "black",
                  width: 2,
                  marginLeft: 10,
                  marginBottom: 10,
                }}
              ></div>
              {/* tds right */}
              <div style={{ display: "flex", flexDirection: "column" }}>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "row",
                    marginLeft: 70,
                    padding: 5,
                  }}
                >
                  <div style={{ display: "flex", flexDirection: "column" }}>
                    <div style={{ display: "flex", flexDirection: "row" }}>
                      <text>C.Tax:</text>
                      <input
                        readOnly={!isEditMode || isDisabled}
                        type="text"
                        className="Fields"
                        style={{
                          height: "30px",
                          width: 120,
                          fontWeight: "bold",
                        }}
                      />
                      <input
                        readOnly={!isEditMode || isDisabled}
                        type="text"
                        className="Fields"
                        style={{
                          height: "30px",
                          width: 120,
                          marginLeft: 5,
                          fontWeight: "bold",
                        }}
                      />
                    </div>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "row",
                        marginTop: 5,
                      }}
                    >
                      <text>S.Tax:</text>
                      <input
                        readOnly={!isEditMode || isDisabled}
                        type="text"
                        className="Fields"
                        style={{
                          height: "30px",
                          width: 120,
                          marginLeft: 1,
                          fontWeight: "bold",
                        }}
                      />
                      <input
                        readOnly={!isEditMode || isDisabled}
                        type="text"
                        className="Fields"
                        style={{
                          height: "30px",
                          width: 120,
                          marginLeft: 5,
                          fontWeight: "bold",
                        }}
                      />
                    </div>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "row",
                        marginTop: 5,
                      }}
                    >
                      <text>I.Tax:</text>
                      <input
                        readOnly={!isEditMode || isDisabled}
                        type="text"
                        className="Fields"
                        style={{
                          height: "30px",
                          width: 120,
                          marginLeft: 5,
                          fontWeight: "bold",
                        }}
                      />
                      <input
                        readOnly={!isEditMode || isDisabled}
                        type="text"
                        className="Fields"
                        style={{
                          height: "30px",
                          width: 120,
                          marginLeft: 5,
                          fontWeight: "bold",
                        }}
                      />
                    </div>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "row",
                        marginTop: 5,
                      }}
                    >
                      <text>Cess:</text>
                      <input
                        readOnly={!isEditMode || isDisabled}
                        type="text"
                        className="Fields"
                        style={{
                          height: "30px",
                          width: 120,
                          marginLeft: 7,
                          fontWeight: "bold",
                        }}
                      />
                      <input
                        readOnly={!isEditMode || isDisabled}
                        type="text"
                        className="Fields"
                        style={{
                          height: "30px",
                          width: 120,
                          marginLeft: 5,
                          fontWeight: "bold",
                        }}
                      />
                    </div>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "row",
                        marginLeft: 122,
                        marginTop: 5,
                      }}
                    >
                      <text>Total:</text>
                      <input
                        readOnly={!isEditMode || isDisabled}
                        type="text"
                        className="Fields"
                        style={{
                          height: "30px",
                          width: 120,
                          marginLeft: 5,
                          fontWeight: "bold",
                        }}
                      />
                    </div>
                  </div>
                </div>
                <div
                  style={{ display: "flex", flexDirection: "row", padding: 5 }}
                >
                  <div style={{ display: "flex", flexDirection: "column" }}>
                    <text>Deposit Dt</text>
                    <input
                      readOnly={!isEditMode || isDisabled}
                      type="text"
                      className="Fields"
                      style={{
                        height: "30px",
                        width: 140,
                        marginLeft: 5,
                        fontWeight: "bold",
                      }}
                    />
                  </div>
                  <div style={{ display: "flex", flexDirection: "column" }}>
                    <text>Challan No</text>
                    <input
                      readOnly={!isEditMode || isDisabled}
                      type="text"
                      className="Fields"
                      style={{
                        height: "30px",
                        width: 140,
                        marginLeft: 5,
                        fontWeight: "bold",
                      }}
                    />
                  </div>
                  <div style={{ display: "flex", flexDirection: "column" }}>
                    <text>Cheque No</text>
                    <input
                      readOnly={!isEditMode || isDisabled}
                      type="text"
                      className="Fields"
                      style={{
                        height: "30px",
                        width: 140,
                        marginLeft: 5,
                        fontWeight: "bold",
                      }}
                    />
                  </div>
                </div>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "row",
                    marginLeft: 10,
                    marginBottom: 10,
                  }}
                >
                  <text>BANK:</text>
                  <input
                    readOnly={!isEditMode || isDisabled}
                    className="Fields"
                    style={{ marginLeft: 5, fontWeight: "bold" }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <ButtonGroup
        className="button-group"
        style={{
          marginTop: 10,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          boxShadow: "0px 8px 16px rgba(0, 0, 0, 0.2)",
        }}
        variant="contained"
        aria-label="Basic button group"
      >
        <Button
          className="Buttonz"
          style={{ color: "black", backgroundColor: buttonColors[0] }}
          onClick={handleAdd}
          disabled={!isAddEnabled}
        >
          Add
        </Button>
        <Button
          className="Buttonz"
          style={{ color: "black", backgroundColor: buttonColors[1] }}
          onClick={handleEditClick} // Add this onClick event handler
          disabled={!isAddEnabled} // Disable edit button when not in add mode
        >
          Edit
        </Button>
        <Button
          className="Buttonz"
          style={{ color: "black", backgroundColor: buttonColors[2] }}
          onClick={handlePrevious}
          disabled={index === 0}
        >
          Previous
        </Button>
        <Button
          className="Buttonz"
          style={{ color: "black", backgroundColor: buttonColors[3] }}
          onClick={handleNext}
          disabled={index === data.length - 1}
        >
          Next
        </Button>
        <Button
          className="Buttonz"
          style={{ color: "black", backgroundColor: buttonColors[4] }}
          onClick={handleFirst}
          disabled={index === 0}
        >
          First
        </Button>
        <Button
          className="Buttonz"
          style={{ color: "black", backgroundColor: buttonColors[5] }}
          onClick={handleLast}
          disabled={index === data.length - 1}
        >
          Last
        </Button>
        <Button
          className="Buttonz"
          style={{ color: "black", backgroundColor: buttonColors[6] }}
        >
          Search
        </Button>
        <Button
          className="Buttonz"
          // onClick={handleOpen}
          style={{ color: "black", backgroundColor: buttonColors[7] }}
        >
          Print
        </Button>
        {/* <PrintButton contentRef={componentRef} /> */}
        <Button
          className="Buttonz"
          style={{ color: "black", backgroundColor: buttonColors[8] }}
          onClick={handleDeleteClick}
        >
          Delete
        </Button>
        <Button
          onClick={handleExitClick}
          className="Buttonz"
          style={{ color: "black", backgroundColor: buttonColors[9] }}
        >
          Exit
        </Button>
        <div>
          <Button
            disabled={!isSubmitEnabled}
            className="Buttonz"
            onClick={handleSaveClick}
            style={{ color: "black", backgroundColor: buttonColors[10] }}
          >
            Save
          </Button>
        </div>
      </ButtonGroup>
    </div>
  );
};

export default TdsVoucher;
