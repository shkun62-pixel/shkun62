import React, { useEffect } from 'react';
import Modal from '@mui/material/Modal';
import { Button } from 'react-bootstrap';
import { Box } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
    borderRadius: 5
};
const closeButtonStyle = {
    position: 'absolute',
    top: 10,
    right: 10,
    cursor: 'pointer',
};

const ModalVehicle = ({
    open2, handleClose2, users2, filteredUsers, highlightedIndex, setHighlightedIndex,
    handleRowClick, handleUserClick, handleSaveClick2, handleAddClick, editedUser2,
    setEditedUser2, isAddingNewUser2, searchQuery, handleSearchChange, inputRef, tableBodyRef
}) => {
    useEffect(() => {
        const handleKeyDown = (event) => {
            if (event.key === 'ArrowDown') {
                setHighlightedIndex((prevIndex) => {
                    const newIndex = (prevIndex + 1) % filteredUsers.length;
                    scrollToIndex(newIndex);
                    return newIndex;
                });
            } else if (event.key === 'ArrowUp') {
                setHighlightedIndex((prevIndex) => {
                    const newIndex = (prevIndex - 1 + filteredUsers.length) % filteredUsers.length;
                    scrollToIndex(newIndex);
                    return newIndex;
                });
            } else if (event.key === 'Enter') {
                event.preventDefault(); // Prevent default behavior of form submission
                handleRowClick(filteredUsers[highlightedIndex]); // Simulate click on the highlighted row
            }
        };

        if (open2) {
            window.addEventListener('keydown', handleKeyDown);
        }

        return () => {
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, [open2, filteredUsers, highlightedIndex]);

    const scrollToIndex = (index) => {
        const rowHeight = 40; // Approximate row height, adjust if necessary
        const modalBody = tableBodyRef.current;
        const offset = index * rowHeight;
        const scrollTop = modalBody.scrollTop;
        const modalHeight = modalBody.clientHeight;

        if (offset < scrollTop) {
            modalBody.scrollTop = offset;
        } else if (offset + rowHeight > scrollTop + modalHeight) {
            modalBody.scrollTop = offset + rowHeight - modalHeight;
        }
    };

    return (
        <Modal
            open={open2}
            onClose={handleClose2}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
        >
            <Box sx={style}>
                <CloseIcon style={closeButtonStyle} onClick={handleClose2} />
                <h3 style={{ textAlign: 'center' }}>Description</h3>
                <input
                    className='topinputs'
                    type="text"
                    placeholder="Search..."
                    value={searchQuery}
                    onChange={handleSearchChange}
                    style={{ width: '100%', marginBottom: 10, height: 32 }}
                />
                <div style={{ maxHeight: 400, overflow: 'auto' }} ref={tableBodyRef}>
                    <table style={{ width: '100%' }}>
                        <thead>
                            <tr>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredUsers.map((user, index) => (
                                <tr
                                    key={index}
                                    style={{ backgroundColor: index === highlightedIndex ? 'lightgray' : 'white', cursor: 'pointer' }}
                                    onClick={() => handleRowClick(user)}
                                >
                                    <td>{user}</td>
                                    <td>
                                        <Button variant="link" onClick={(e) => { e.stopPropagation(); handleUserClick(user); }}>
                                            Edit
                                        </Button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                <br />
                <label htmlFor="editedUser2">{isAddingNewUser2 ? 'Add new user:' : 'Edit selected user:'}</label>
                <input
                    className='topinputs'
                    style={{ marginTop: 20, width: 190, height: 30 }}
                    type="text"
                    id="editedUser2"
                    ref={inputRef}
                    value={editedUser2}
                    onChange={(e) => setEditedUser2(e.target.value)}
                />
                <Button className='button' style={{ backgroundColor: 'gold', width: 70, marginLeft: 90, borderColor: "transparent" }} onClick={handleAddClick}>Add</Button>
                <Button className='button' style={{ backgroundColor: 'green', width: 70, marginLeft: 10, borderColor: "transparent" }} onClick={handleSaveClick2} disabled={!editedUser2.trim()}>Save</Button>
            </Box>
        </Modal>
    );
};

export default ModalVehicle;
