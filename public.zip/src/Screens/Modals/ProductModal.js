// import React, { useState, useEffect, useRef } from 'react';
// import Modal from 'react-bootstrap/Modal';
// import Button from 'react-bootstrap/Button';
// import Table from 'react-bootstrap/Table';
// import {
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Paper,
//   FormControl,
//   InputLabel,
//   Select,
//   MenuItem,
// } from '@mui/material';
// import "./ProductModal.css";
// import CheckCircleIcon from '@mui/icons-material/CheckCircle';
// import NewStockAccount from "../NewStockAcc/NewStockAcc.js";

// const SelectModal = ({ allFields, selectedFields, handleFieldChange, onClose }) => {
//   return (
//     <Modal show onHide={onClose}>
//       <Modal.Header closeButton>
//         <Modal.Title>Select Fields</Modal.Title>
//       </Modal.Header>
//       <Modal.Body>
//         <FormControl fullWidth>
//           <InputLabel id="field-select-label">Select Fields</InputLabel>
//           <Select
//             labelId="field-select-label"
//             id="field-select"
//             multiple
//             value={selectedFields}
//             onChange={handleFieldChange}
//             IconComponent={CheckCircleIcon}
//             MenuProps={{
//               anchorOrigin: { horizontal: "left", vertical: "bottom" },
//               transformOrigin: { vertical: "top", horizontal: "left" },
//               getContentAnchorEl: null,
//             }}
//             className="select-field"
//             renderValue={(selected) => (
//               <div>
//                 {selected.map((value) => (
//                   <span key={value} className="selected-option">{value}</span>
//                 ))}
//               </div>
//             )}
//           >
//             {allFields.map(field => (
//               <MenuItem key={field} value={field} className={selectedFields.includes(field) ? 'selected' : ''}>
//                 {field}
//               </MenuItem>
//             ))}
//           </Select>
//         </FormControl>
//       </Modal.Body>
//       <Modal.Footer>
//         <Button variant="secondary" onClick={onClose}>
//           Close
//         </Button>
//       </Modal.Footer>
//     </Modal>
//   );
// };

// const ProductModal = ({ products, onSelect, onClose, allFields, initialKey }) => {
//   // const navigate = useNavigate();
//   const [filteredProducts, setFilteredProducts] = useState(products);
//   const [selectedIndex, setSelectedIndex] = useState(0);
//   const [selectedFields, setSelectedFields] = useState(allFields);
//   const inputRef = useRef(null);
//   const tableRef = useRef(null);
//   const [showSelectModal, setShowSelectModal] = useState(false);
//   const [showNewStockModal, setShowNewStockModal] = useState(false); // New state for NewStockAcc modal
//   const [searchTerm, setSearchTerm] = useState(initialKey || '');


//   useEffect(() => {
//     inputRef.current.focus();
//   }, []);

//   useEffect(() => {
//     if (tableRef.current) {
//       const selectedRow = tableRef.current.querySelector('.highlighted-row');
//       if (selectedRow) {
//         selectedRow.scrollIntoView({ block: 'nearest' });
//       }
//     }
//   }, [selectedIndex]);

//   useEffect(() => {
//     const handleKeyDown = (event) => {
//       if (showNewStockModal) return; // Disable key events when NewStockModal is open
  
//       if (event.key === 'ArrowUp') {
//         event.preventDefault();
//         setSelectedIndex(prevIndex => Math.max(prevIndex - 1, 0));
//       } else if (event.key === 'ArrowDown') {
//         event.preventDefault();
//         setSelectedIndex(prevIndex => Math.min(prevIndex + 1, filteredProducts.length - 1));
//       } else if (event.key === 'Enter') {
//         event.preventDefault();
//         onSelect(filteredProducts[selectedIndex]);
//         console.log(filteredProducts[selectedIndex]);
        
//       }
//     };
  
//     document.addEventListener('keydown', handleKeyDown);
//     return () => {
//       document.removeEventListener('keydown', handleKeyDown);
//     };
//   }, [filteredProducts, selectedIndex, onSelect, showNewStockModal]); // Include showNewStockModal in dependencies
  
//   useEffect(() => {
//     // Filter products based on the initial key
//     handleSearch({ target: { value: initialKey } });
//   }, [initialKey]);

//   const handleSearch = (e) => {
//     const keyword = e.target.value.toLowerCase();
//     const matchingProduct = products.find(product => 
//       product.Aheads.toLowerCase().split(' ').some(namePart => namePart.startsWith(keyword))
//     );
    
//     if (matchingProduct) {
//       setSearchTerm(e.target.value);
//       const filtered = products.filter(product =>
//         product.Aheads.toLowerCase().split(' ').some(namePart => namePart.startsWith(keyword))
//       );
//       setFilteredProducts(filtered);
//       setSelectedIndex(0);
//     } else {
//       e.target.value = searchTerm;
//     }
//   };

//   const handleRowClick = (product, index) => {
//     setSelectedIndex(index);
//     onSelect(product);
//   };

//   const handleFieldChange = (event) => {
//     const { value } = event.target;
//     setSelectedFields(value);
//   };

//   const handleDataGridScroll = (event) => {
//     event.stopPropagation();
//   };

//   // Instead of opening a new window, open the modal for NewStockAcc
//   const openNewStockModal = () => {
//     setShowNewStockModal(true);
//   };

//   const fetchProducts = async (highlightLast = false) => {
//     try {
//       const response = await fetch(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/stockmaster`);
//       if (!response.ok) {
//         throw new Error("Failed to fetch products");
//       }
//       const data = await response.json();
//       const flattenedData = data.map((item) => ({
//         ...item.formData,
//         _id: item._id,
//       }));
  
//       setFilteredProducts(flattenedData);
  
//       if (highlightLast) {
//         setSelectedIndex(flattenedData.length - 1); // Focus last item
//       }
//     } catch (error) {
//       console.error("Error fetching updated products:", error);
//     }
//   };
  
  
//   return (
//     <>
//       <Modal show onHide={onClose} fullscreen className="custom-modal" style={{ marginTop: 20 }}>
//         <Modal.Header closeButton>
//           <Modal.Title>STOCK ITEMS</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>
//           <div className="list-container" onScroll={handleDataGridScroll}>
//             <TableContainer component={Paper} className="table-container">
//               <Table bordered size="small" ref={tableRef}>
//                 <TableHead style={{ backgroundColor: "lightgray" }}>
//                   <TableRow>
//                     {selectedFields.map(field => (
//                       <TableCell style={{ textTransform: "uppercase" }} key={field}>{field}</TableCell>
//                     ))}
//                   </TableRow>
//                 </TableHead>
//                 <TableBody>
//                   {filteredProducts.map((product, index) => (
//                     <TableRow
//                       key={index}
//                       className={selectedIndex === index ? 'highlighted-row' : ''}
//                       onClick={() => handleRowClick(product, index)}
//                     >
//                       {selectedFields.map(field => (
//                         <TableCell key={field}>{product[field]}</TableCell>
//                       ))}
//                     </TableRow>
//                   ))}
//                 </TableBody>
//               </Table>
//             </TableContainer>
//           </div>
//         </Modal.Body>
//         <div className='searchdiv' style={{ marginBottom:20 }}>
//           <input
//             type="text"
//             className="search"
//             placeholder="Search..."
//             onChange={handleSearch}
//             value={searchTerm}
//             ref={inputRef}
//           />
//           <div className='buttondiv'>
//             {/* Replace window.open with modal trigger */}
//             <Button className='new' onClick={openNewStockModal}>New</Button>
//             <Button className='modify'>Modify</Button>
//             <Button className='select'>Select</Button>
//             <Button className='closebtn' variant="secondary" onClick={onClose}>
//               Close
//             </Button>
//           </div>
//         </div>
//       </Modal>

//       {showSelectModal && (
//         <SelectModal
//           allFields={allFields}
//           selectedFields={selectedFields}
//           handleFieldChange={handleFieldChange}
//           onClose={() => setShowSelectModal(false)}
//         />
//       )}

//       {showNewStockModal && (
//         <Modal
//           dialogClassName="custom-full-width-modal"
//           show
//           onHide={() => {
//             setShowNewStockModal(false);
//             fetchProducts(true); // 👈 highlight last item
//           }}
//           size="lg"
//           style={{ zIndex: 100000 }}
//         >
//           <Modal.Body>
//             <NewStockAccount />
//           </Modal.Body>
//           <Modal.Footer>
//             <Button
//               variant="secondary"
//               onClick={() => {
//                 setShowNewStockModal(false);
//                 fetchProducts(true); // 👈 highlight last item
//               }}
//             >
//               Close
//             </Button>
//           </Modal.Footer>
//         </Modal>
//       )}
//     </>
//   );
// };

// export default ProductModal;


import React, { useState, useEffect, useRef } from 'react';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import Table from 'react-bootstrap/Table';
import {
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from '@mui/material';
import "./ProductModal.css";
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import NewStockAccount from "../NewStockAcc/NewStockAcc.js";

const SelectModal = ({ allFields, selectedFields, handleFieldChange, onClose }) => {
  return (
    <Modal show onHide={onClose}>
      <Modal.Header closeButton>
        <Modal.Title>Select Fields</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <FormControl fullWidth>
          <InputLabel id="field-select-label">Select Fields</InputLabel>
          <Select
            labelId="field-select-label"
            id="field-select"
            multiple
            value={selectedFields}
            onChange={handleFieldChange}
            IconComponent={CheckCircleIcon}
            MenuProps={{
              anchorOrigin: { horizontal: "left", vertical: "bottom" },
              transformOrigin: { vertical: "top", horizontal: "left" },
              getContentAnchorEl: null,
            }}
            className="select-field"
            renderValue={(selected) => (
              <div>
                {selected.map((value) => (
                  <span key={value} className="selected-option">{value}</span>
                ))}
              </div>
            )}
          >
            {allFields.map(field => (
              <MenuItem key={field} value={field} className={selectedFields.includes(field) ? 'selected' : ''}>
                {field}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onClose}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

const ProductModal = ({ products, onSelect, onClose, allFields, initialKey }) => {
  // const navigate = useNavigate();
  const [filteredProducts, setFilteredProducts] = useState(products);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [selectedFields, setSelectedFields] = useState(allFields);
  const inputRef = useRef(null);
  const tableRef = useRef(null);
  const [showSelectModal, setShowSelectModal] = useState(false);
  const [showNewStockModal, setShowNewStockModal] = useState(false); // New state for NewStockAcc modal
  const [searchTerm, setSearchTerm] = useState(initialKey || '');


  useEffect(() => {
    inputRef.current.focus();
  }, []);

  useEffect(() => {
    if (tableRef.current) {
      const selectedRow = tableRef.current.querySelector('.highlighted-row');
      if (selectedRow) {
        selectedRow.scrollIntoView({ block: 'nearest' });
      }
    }
  }, [selectedIndex]);

  useEffect(() => {
    const handleKeyDown = (event) => {
      if (showNewStockModal) return; // Disable key events when NewStockModal is open
  
      if (event.key === 'ArrowUp') {
        event.preventDefault();
        setSelectedIndex(prevIndex => Math.max(prevIndex - 1, 0));
      } else if (event.key === 'ArrowDown') {
        event.preventDefault();
        setSelectedIndex(prevIndex => Math.min(prevIndex + 1, filteredProducts.length - 1));
      } else if (event.key === 'Enter') {
        event.preventDefault();
        console.log(filteredProducts[selectedIndex]);
                onSelect(filteredProducts[selectedIndex]);
        
      }
    };
  
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [filteredProducts, selectedIndex, onSelect, showNewStockModal]); // Include showNewStockModal in dependencies
  
  useEffect(() => {
    // Filter products based on the initial key
    handleSearch({ target: { value: initialKey } });
  }, [initialKey]);

  const handleSearch = (e) => {
    const keyword = e.target.value.toLowerCase();
    const matchingProduct = products.find(product => 
      product.Aheads.toLowerCase().split(' ').some(namePart => namePart.startsWith(keyword))
    );
    
    if (matchingProduct) {
      setSearchTerm(e.target.value);
      const filtered = products.filter(product =>
        product.Aheads.toLowerCase().split(' ').some(namePart => namePart.startsWith(keyword))
      );
      setFilteredProducts(filtered);
      setSelectedIndex(0);
    } else {
      e.target.value = searchTerm;
    }
  };

  const handleRowClick = (product, index) => {
    setSelectedIndex(index);
    onSelect(product);
  };

  const handleFieldChange = (event) => {
    const { value } = event.target;
    setSelectedFields(value);
  };

  const handleDataGridScroll = (event) => {
    event.stopPropagation();
  };

  // Instead of opening a new window, open the modal for NewStockAcc
  const openNewStockModal = () => {
    setShowNewStockModal(true);
  };

  const fetchProducts = async (highlightLast = false) => {
    try {
      const response = await fetch(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/stockmaster`);
      if (!response.ok) {
        throw new Error("Failed to fetch products");
      }
      const data = await response.json();
      const flattenedData = data.map((item) => ({
        ...item.formData,
        _id: item._id,
      }));
  
      setFilteredProducts(flattenedData);
  
      if (highlightLast) {
        setSelectedIndex(flattenedData.length - 1); // Focus last item
      }
    } catch (error) {
      console.error("Error fetching updated products:", error);
    }
  };
  
  
  return (
    <>
      <Modal show onHide={onClose} fullscreen className="custom-modal" style={{ marginTop: 20 }}>
        <Modal.Header closeButton>
          <Modal.Title>STOCK ITEMS</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="list-container" onScroll={handleDataGridScroll}>
            <TableContainer component={Paper} className="table-container">
              <Table bordered size="small" ref={tableRef}>
                <TableHead style={{ backgroundColor: "lightgray" }}>
                  <TableRow>
                    {selectedFields.map(field => (
                      <TableCell style={{ textTransform: "uppercase" }} key={field}>{field}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {filteredProducts.map((product, index) => (
                    <TableRow
                      key={index}
                      className={selectedIndex === index ? 'highlighted-row' : ''}
                      onClick={() => handleRowClick(product, index)}
                    >
                      {selectedFields.map(field => (
                        <TableCell key={field}>{product[field]}</TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </div>
        </Modal.Body>
        <div className='searchdiv' style={{ marginBottom:20 }}>
          <input
            type="text"
            className="search"
            placeholder="Search..."
            onChange={handleSearch}
            value={searchTerm}
            ref={inputRef}
          />
          <div className='buttondiv'>
            {/* Replace window.open with modal trigger */}
            <Button className='new' onClick={openNewStockModal}>New</Button>
            <Button className='modify'>Modify</Button>
            <Button className='select'>Select</Button>
            <Button className='closebtn' variant="secondary" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </Modal>

      {showSelectModal && (
        <SelectModal
          allFields={allFields}
          selectedFields={selectedFields}
          handleFieldChange={handleFieldChange}
          onClose={() => setShowSelectModal(false)}
        />
      )}

      {showNewStockModal && (
        <Modal
          dialogClassName="custom-full-width-modal"
          show
          onHide={() => {
            setShowNewStockModal(false);
            fetchProducts(true); // 👈 highlight last item
          }}
          size="lg"
          style={{ zIndex: 100000 }}
        >
        <Modal.Body>
  <NewStockAccount
    onSaveSuccess={() => {
      setShowNewStockModal(false);
      fetchProducts(true); // Refresh product list after save or close
    }}
    onEscClose={() => {
      setShowNewStockModal(false);
      fetchProducts(true); // ✅ Also refresh on ESC close
    }}
  />
</Modal.Body>

          <Modal.Footer>
            <Button
              variant="secondary"
              onClick={() => {
                setShowNewStockModal(false);
                fetchProducts(true); // 👈 highlight last item
              }}
            >
              Close
            </Button>
          </Modal.Footer>
        </Modal>
      )}
    </>
  );
};

export default ProductModal;
