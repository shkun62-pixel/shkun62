import React, { useEffect } from 'react';
import Modal from '@mui/material/Modal';
import { Button } from 'react-bootstrap';
import { Box } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
    borderRadius: 5
};
const closeButtonStyle = {
    position: 'absolute',
    top: 10,
    right: 10,
    cursor: 'pointer',
};

const ModalTransport = ({
    openT, handleCloseT, usersT, filteredUsersT, highlightedIndexT, sethighlightedIndexT,
    handleRowClickT, handleUserClickT, handleSaveClickT, handleAddClickT, editedUserT,
    seteditedUserT, isAddingNewUserT, searchQueryT, handleSearchChangeT, inputRefT, tableBodyRefT
}) => {
    useEffect(() => {
        const handleKeyDown = (event) => {
            if (event.key === 'ArrowDown') {
                sethighlightedIndexT((prevIndex) => {
                    const newIndex = (prevIndex + 1) % filteredUsersT.length;
                    scrollToIndex(newIndex);
                    return newIndex;
                });
            } else if (event.key === 'ArrowUp') {
                sethighlightedIndexT((prevIndex) => {
                    const newIndex = (prevIndex - 1 + filteredUsersT.length) % filteredUsersT.length;
                    scrollToIndex(newIndex);
                    return newIndex;
                });
            } else if (event.key === 'Enter') {
                event.preventDefault(); // Prevent default behavior of form submission
                handleRowClickT(filteredUsersT[highlightedIndexT]); // Simulate click on the highlighted row
            }
        };

        if (openT) {
            window.addEventListener('keydown', handleKeyDown);
        }

        return () => {
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, [openT, filteredUsersT, highlightedIndexT]);

    const scrollToIndex = (index) => {
        const rowHeight = 40; // Approximate row height, adjust if necessary
        const modalBody = tableBodyRefT.current;
        const offset = index * rowHeight;
        const scrollTop = modalBody.scrollTop;
        const modalHeight = modalBody.clientHeight;

        if (offset < scrollTop) {
            modalBody.scrollTop = offset;
        } else if (offset + rowHeight > scrollTop + modalHeight) {
            modalBody.scrollTop = offset + rowHeight - modalHeight;
        }
    };

    return (
        <Modal
            open={openT}
            onClose={handleCloseT}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
        >
            <Box sx={style}>
                <CloseIcon style={closeButtonStyle} onClick={handleCloseT} />
                <h3 style={{ textAlign: 'center' }}>Description</h3>
                <input
                    className='topinputs'
                    type="text"
                    placeholder="Search..."
                    value={searchQueryT}
                    onChange={handleSearchChangeT}
                    style={{ width: '100%', marginBottom: 10, height: 32 }}
                />
                <div style={{ maxHeight: 400, overflow: 'auto' }} ref={tableBodyRefT}>
                    <table style={{ width: '100%' }}>
                        <thead>
                            <tr>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredUsersT.map((user, index) => (
                                <tr
                                    key={index}
                                    style={{ backgroundColor: index === highlightedIndexT ? 'lightgray' : 'white', cursor: 'pointer' }}
                                    onClick={() => handleRowClickT(user)}
                                >
                                    <td>{user}</td>
                                    <td>
                                        <Button variant="link" onClick={(e) => { e.stopPropagation(); handleUserClickT(user); }}>
                                            Edit
                                        </Button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                <br />
                <label htmlFor="editedUserT">{isAddingNewUserT ? 'Add new user:' : 'Edit selected user:'}</label>
                <input
                    className='topinputs'
                    style={{ marginTop: 20, width: 190, height: 30 }}
                    type="text"
                    id="editedUserT"
                    ref={inputRefT}
                    value={editedUserT}
                    onChange={(e) => seteditedUserT(e.target.value)}
                />
                <Button className='button' style={{ backgroundColor: 'gold', width: 70, marginLeft: 90, borderColor: "transparent" }} onClick={handleAddClickT}>Add</Button>
                <Button className='button' style={{ backgroundColor: 'green', width: 70, marginLeft: 10, borderColor: "transparent" }} onClick={handleSaveClickT} disabled={!editedUserT.trim()}>Save</Button>
            </Box>
        </Modal>
    );
};

export default ModalTransport;
