
import React, { useState, useEffect, useRef } from 'react';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, FormControl, InputLabel, Select, MenuItem } from '@mui/material';
import "./ProductModal.css";
import CheckCircleIcon from '@mui/icons-material/CheckCircle'; // Import check circle icon

const SelectModal = ({ allFieldsDebit, selectedFieldsDebit, handleFieldChangeDebit, onCloseDebit }) => {
    return (
        <Modal show={true} onHide={onCloseDebit}>
            <Modal.Header closeButton>
                <Modal.Title>Select Fields</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <FormControl fullWidth>
                    <InputLabel id="field-select-label">Select Fields</InputLabel>
                    <Select
                        labelId="field-select-label"
                        id="field-select"
                        multiple
                        value={selectedFieldsDebit}
                        onChange={handleFieldChangeDebit}
                        IconComponent={CheckCircleIcon} // Use CheckCircleIcon as the select icon
                        MenuProps={{
                            anchorOrigin: {
                                horizontal: "left",
                                vertical: "bottom"
                            },
                            transformOrigin: {
                                vertical: "top",
                                horizontal: "left"
                            },
                            getContentAnchorEl: null
                        }}
                        className="select-field" // Add custom class for styling
                        renderValue={(selected) => (
                            <div>
                                {selected.map((value) => (
                                    <span key={value} className="selected-option">{value}</span>
                                ))}
                            </div>
                        )}
                    >
                        {allFieldsDebit.map(field => (
                            <MenuItem key={field} value={field} className={selectedFieldsDebit.includes(field) ? 'selected' : ''}>
                                {field}
                            </MenuItem>
                        ))}
                    </Select>
                </FormControl>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="secondary" onClick={onCloseDebit}>
                    Close
                </Button>
            </Modal.Footer>
        </Modal>
    );
};
const ModalDebit = ({ productsDebit, onSelectDebit, onCloseDebit, allFieldsDebit }) => {
    const [filteredproductsDebit, setFilteredproductsDebit] = useState(productsDebit);
    const [selectedIndexDebit, setselectedIndexDebit] = useState(0);
    const [selectedFieldsDebit, setselectedFieldsDebit] = useState(allFieldsDebit); // Initialize selectedFields with all fields
    const inputRef = useRef(null);
    const tableRef = useRef(null);
    const [showSelectModalDebit, setshowSelectModalDebit] = useState(false);

    useEffect(() => {
        inputRef.current.focus();
    }, []);

    useEffect(() => {
        if (tableRef.current) {
            const selectedRow = tableRef.current.querySelector('.highlighted-row');
            if (selectedRow) {
                selectedRow.scrollIntoView({ block: 'nearest' });
            }
        }
    }, [selectedIndexDebit]);

    useEffect(() => {
        const handleKeyDown = (event) => {
            if (event.key === 'ArrowUp') {
                event.preventDefault();
                setselectedIndexDebit(prevIndex => Math.max(prevIndex - 1, 0));
            } else if (event.key === 'ArrowDown') {
                event.preventDefault();
                setselectedIndexDebit(prevIndex => Math.min(prevIndex + 1, filteredproductsDebit.length - 1));
            } else if (event.key === 'Enter') {
                event.preventDefault();
                onSelectDebit(filteredproductsDebit[selectedIndexDebit]);
            }
        };

        document.addEventListener('keydown', handleKeyDown);

        return () => {
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, [filteredproductsDebit, selectedIndexDebit, onSelectDebit]);

    const handleSearch = (e) => {
        const keyword = e.target.value.toLowerCase();
        const filtered = productsDebit.filter(product =>
            product.ahead.toLowerCase().includes(keyword)
        );
        setFilteredproductsDebit(filtered);
        setselectedIndexDebit(0);
    };

    const handleRowClick = (product, index) => {
        setselectedIndexDebit(index);
        onSelectDebit(product);
    };

    const handleFieldChange = (event) => {
        const { value } = event.target;
        setselectedFieldsDebit(value);
    };

    const handleDataGridScroll = (event) => {
        event.stopPropagation(); // Prevent scroll event from reaching the select component
    };

    return (
        <>
            <Modal show={true} onHide={onCloseDebit} fullscreen className="custom-modal" style={{ height: "80%", marginTop: 20 }}>
                <Modal.Header closeButton>
                    <Modal.Title>Select Customer</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Button style={{ marginBottom: 10 }} variant="primary" onClick={() => setshowSelectModalDebit(true)}>Select Fields</Button>
                    <input
                        type="text"
                        className="form-control mb-3"
                        placeholder="Search..."
                        onChange={handleSearch}
                        ref={inputRef}
                    />
                    <div className="list-container" onScroll={handleDataGridScroll}>
                        <TableContainer component={Paper} className="table-container">
                            <Table size="small" ref={tableRef}>
                                <TableHead>
                                    <TableRow>
                                        {/* Dynamically generate table headers based on selected fields */}
                                        {selectedFieldsDebit.map(field => (
                                            <TableCell key={field} style={{ textTransform: 'uppercase' }}>{field}</TableCell>
                                        ))}
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {filteredproductsDebit.map((product, index) => (
                                        <TableRow
                                            key={index}
                                            className={selectedIndexDebit === index ? 'highlighted-row' : ''}
                                            onClick={() => handleRowClick(product, index)}
                                        >
                                            {/* Render cells based on selected fields */}
                                            {selectedFieldsDebit.map(field => (
                                                <TableCell key={field}>{product[field]}</TableCell>
                                            ))}
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </div>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={onCloseDebit}>
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>

            {showSelectModalDebit && (
                <SelectModal
                    allFieldsDebit={allFieldsDebit}
                    selectedFieldsDebit={selectedFieldsDebit}
                    handleFieldChangeDebit={handleFieldChange}
                    onCloseDebit={() => setshowSelectModalDebit(false)}
                />
            )}
        </>
    );
};

export default ModalDebit;
