import React, { useState, useEffect, useRef } from 'react';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, FormControl, InputLabel, Select, MenuItem } from '@mui/material';
import "./ProductModal.css";
import CheckCircleIcon from '@mui/icons-material/CheckCircle'; // Import check circle icon
import LedgerAcc from "../LedgerAcc/LedgerAcc"

const SelectModal = ({ allFieldsAcc, selectedFieldsAcc, handleFieldChangeAcc, onCloseAcc }) => {
    return (
        <Modal show={true} onHide={onCloseAcc}>
            <Modal.Header closeButton>
                <Modal.Title>Select Fields</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <FormControl fullWidth>
                    <InputLabel id="field-select-label">Select Fields</InputLabel>
                    <Select
                        labelId="field-select-label"
                        id="field-select"
                        multiple
                        value={selectedFieldsAcc}
                        onChange={handleFieldChangeAcc}
                        IconComponent={CheckCircleIcon} // Use CheckCircleIcon as the select icon
                        MenuProps={{
                            anchorOrigin: {
                                horizontal: "left",
                                vertical: "bottom"
                            },
                            transformOrigin: {
                                vertical: "top",
                                horizontal: "left"
                            },
                            getContentAnchorEl: null
                        }}
                        className="select-field" // Add custom class for styling
                        renderValue={(selected) => (
                            <div>
                                {selected.map((value) => (
                                    <span key={value} className="selected-option">{value}</span>
                                ))}
                            </div>
                        )}
                    >
                        {allFieldsAcc.map(field => (
                            <MenuItem key={field} value={field} className={selectedFieldsAcc.includes(field) ? 'selected' : ''}>
                                {field}
                            </MenuItem>
                        ))}
                    </Select>
                </FormControl>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="secondary" onClick={onCloseAcc}>
                    Close
                </Button>
            </Modal.Footer>
        </Modal>
    );
};

const ProductModalAccount = ({ productsAcc, onSelectAcc, onCloseAcc, allFieldsAcc, initialKey }) => {
    const [filteredProductsAcc, setFilteredProductsAcc] = useState(productsAcc);
    const [selectedIndexAcc, setSelectedIndexAcc] = useState(0);
    const [selectedFieldsAcc, setSelectedFieldsAcc] = useState(['ahead', 'gstNo', ...allFieldsAcc.filter(field => field !== 'ahead' && field !== 'gstNo')]); // Ensure 'ahead' is first and 'gstNo' is second
    const inputRef = useRef(null);
    const tableRef = useRef(null);
    const [showSelectModalAcc, setShowSelectModalAcc] = useState(false);
    const [searchTerm, setSearchTerm] = useState(initialKey || ''); // Initialize searchTerm with initialKey
    const [showLedgerModal, setShowLedgerModal] = useState(false); // New state for NewStockAcc modal
    useEffect(() => {
        inputRef.current.focus();
    }, []);

    useEffect(() => {
        if (tableRef.current) {
            const selectedRow = tableRef.current.querySelector('.highlighted-row');
            if (selectedRow) {
                selectedRow.scrollIntoView({ block: 'nearest' });
            }
        }
    }, [selectedIndexAcc]);

    useEffect(() => {
        const handleKeyDown = (event) => {
            if (showLedgerModal) return; // Disable key events when NewStockModal is open

            if (event.key === 'ArrowUp') {
                event.preventDefault();
                setSelectedIndexAcc(prevIndex => Math.max(prevIndex - 1, 0));
            } else if (event.key === 'ArrowDown') {
                event.preventDefault();
                setSelectedIndexAcc(prevIndex => Math.min(prevIndex + 1, filteredProductsAcc.length - 1));
            } else if (event.key === 'Enter') {
                event.preventDefault();
                onSelectAcc(filteredProductsAcc[selectedIndexAcc]);
            }
        };

        document.addEventListener('keydown', handleKeyDown);

        return () => {
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, [filteredProductsAcc, selectedIndexAcc, onSelectAcc]);

    useEffect(() => {
        // Filter products based on the initial key
        handleSearch({ target: { value: initialKey } });
    }, [initialKey]);
    // const handleSearch = (e) => {
    //     const keyword = e.target.value.toLowerCase();

    //     // Check if the current input matches any product names
    //     const matchingProduct = productsAcc.find(product => product.ahead.toLowerCase().startsWith(keyword));

    //     if (matchingProduct) {
    //         setSearchTerm(e.target.value); // Allow the input to be typed
    //         const filtered = productsAcc.filter(product =>
    //             product.ahead.toLowerCase().startsWith(keyword)
    //         );
    //         setFilteredProductsAcc(filtered);
    //         setSelectedIndexAcc(0);
    //     } else {
    //         // Prevent the input from being typed if no match is found
    //         e.preventDefault();
    //     }
    // };
    const handleSearch = (e) => {
        const keyword = e.target.value.toLowerCase();
    
        // Check if the current input matches any part of the product name (first name or surname)
        const matchingProduct = productsAcc.find(product => 
            product.ahead.toLowerCase().split(' ').some(namePart => namePart.startsWith(keyword))
        );
        console.log(matchingProduct);
    
        if (matchingProduct) {
            setSearchTerm(e.target.value); // Allow the input to be typed
            const filtered = productsAcc.filter(product =>
                product.ahead.toLowerCase().split(' ').some(namePart => namePart.startsWith(keyword))
            );
            setFilteredProductsAcc(filtered);
            setSelectedIndexAcc(0);
        } else {
            // Prevent the input from being typed if no match is found
            e.target.value = searchTerm;
        }
    };

    const handleRowClick = (product, index) => {
        setSelectedIndexAcc(index);
        onSelectAcc(product);
    };

    const handleFieldChange = (event) => {
        const { value } = event.target;
        setSelectedFieldsAcc(['ahead', 'gstNo', ...value.filter(field => field !== 'ahead' && field !== 'gstNo')]); // Ensure 'ahead' is first and 'gstNo' is second
    };

    const handleDataGridScroll = (event) => {
        event.stopPropagation(); // Prevent scroll event from reaching the select component
    };

   const openLedgerModal = () => {
    setShowLedgerModal(true);
  };
    return (
        <>
            <Modal show={true} onHide={onCloseAcc} fullscreen className="custom-modal" style={{marginTop: 20 }}>
                <Modal.Header closeButton>
                    <Modal.Title>Select Account Name</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {/* <Button style={{ marginBottom: 10 }} variant="primary" onClick={() => setShowSelectModalAcc(true)}>Select Fields</Button> */}
                    <div className="list-container" onScroll={handleDataGridScroll}>
                    <TableContainer component={Paper} className="table-container">
                            <Table bordered ref={tableRef}>
                                <TableHead style={{ backgroundColor: "lightgray",}}>
                                    <TableRow>
                                        {selectedFieldsAcc.map(field => (
                                            <TableCell style={{ textTransform: "uppercase" }} key={field}>{field}</TableCell>
                                        ))}
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {filteredProductsAcc.map((product, index) => (
                                        <TableRow
                                            key={index}
                                            className={selectedIndexAcc === index ? 'highlighted-row' : ''}
                                            onClick={() => handleRowClick(product, index)}
                                        >
                                            {selectedFieldsAcc.map(field => (
                                                <TableCell key={field}>{product[field]}</TableCell>
                                            ))}
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </div>
                </Modal.Body>
                <div className='searchdiv' style={{marginBottom:10}}>
                     <input
                        type="text"
                        className="searchs"
                        placeholder="Search..."
                        onChange={handleSearch}
                        value={searchTerm} // Set input value to searchTerm
                        ref={inputRef}
                    />
                    <div className='buttondiv'>
                        <Button className='new' onClick={openLedgerModal}>New</Button>
                        <Button className='modify'>Modify</Button>
                        <Button className='select'>Select</Button>
                        <Button className='closebtn' variant="secondary" onClick={onCloseAcc}>
                            Close
                        </Button>
                    </div>
                </div>
            </Modal>

            {showSelectModalAcc && (
                <SelectModal
                    allFieldsAcc={allFieldsAcc}
                    selectedFieldsAcc={selectedFieldsAcc}
                    handleFieldChangeAcc={handleFieldChange}
                    onCloseAcc={() => setShowSelectModalAcc(false)}
                />
            )}
               {showLedgerModal && (
                    <Modal
                    dialogClassName="custom-full-width-modal" // Add a custom class
                      show
                      onHide={() => setShowLedgerModal(false)}
                      size="lg"
                      style={{zIndex: 100000,marginTop:-30}}
                    >
                      <Modal.Body style={{marginTop:10,marginLeft:10}}>
                        <LedgerAcc />
                      </Modal.Body>
                    </Modal>
                  )}
        </>
    );
};

export default ProductModalAccount;
