import React, { useState, useEffect, useRef } from 'react';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import Table from 'react-bootstrap/Table';
import { TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, FormControl, InputLabel, Select, MenuItem } from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { useNavigate } from 'react-router-dom';
import "./ProductModal.css";
import LedgerAcc from "../LedgerAcc/LedgerAcc"

const SelectModal = ({ allFields, selectedFields, handleFieldChange, onClose }) => {
    return (
        <Modal show={true} onHide={onClose}>
            <Modal.Header closeButton>
                <Modal.Title>Select Fields</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <FormControl fullWidth>
                    <InputLabel id="field-select-label">Select Fields</InputLabel>
                    <Select
                        labelId="field-select-label"
                        id="field-select"
                        multiple
                        value={selectedFields}
                        onChange={handleFieldChange}
                        IconComponent={CheckCircleIcon}
                        MenuProps={{
                            anchorOrigin: {
                                horizontal: "left",
                                vertical: "bottom"
                            },
                            transformOrigin: {
                                vertical: "top",
                                horizontal: "left"
                            },
                            getContentAnchorEl: null
                        }}
                        className="select-field"
                        renderValue={(selected) => (
                            <div>
                                {selected.map((value) => (
                                    <span key={value} className="selected-option">{value}</span>
                                ))}
                            </div>
                        )}
                    >
                        {allFields.map(field => (
                            <MenuItem key={field} value={field} className={selectedFields.includes(field) ? 'selected' : ''}>
                                {field}
                            </MenuItem>
                        ))}
                    </Select>
                </FormControl>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="secondary" onClick={onClose}>
                    Close
                </Button>
            </Modal.Footer>
        </Modal>
    );
};

const ProductModalCustomer = ({ products, onSelect, onClose, allFields, initialKey }) => {
    const navigate = useNavigate();
    const [filteredProducts, setFilteredProducts] = useState(products);
    const [selectedIndex, setSelectedIndex] = useState(0);
    const [selectedFields, setSelectedFields] = useState(['ahead', 'gstNo', 'add1', 'city', 'pan', ...allFields.filter(field => field !== 'ahead' && field !== 'gstNo' && field !== 'add1' && field !== 'city' && field !== 'pan')]);
    const inputRef = useRef(null);
    const tableRef = useRef(null);
    const [showSelectModal, setShowSelectModal] = useState(false);
    const [modalOpen, setModalOpen] = useState(true);
    const [searchTerm, setSearchTerm] = useState(initialKey || ''); // Initialize searchTerm with initialKey
    const [searchField, setSearchField] = useState('ahead'); // Default search field
    const [showLedgerModal, setShowLedgerModal] = useState(false); // New state for NewStockAcc modal

    useEffect(() => {
        if (modalOpen && inputRef.current) {
            inputRef.current.focus();
        }
    }, [modalOpen]);

    useEffect(() => {
        if (tableRef.current) {
            const selectedRow = tableRef.current.querySelector('.highlighted-row');
            if (selectedRow) {
                selectedRow.scrollIntoView({ block: 'nearest' });
            }
        }
    }, [selectedIndex]);

    useEffect(() => {
        const handleKeyDown = (event) => {
            if (showLedgerModal) return; // Disable key events when NewStockModal is open

            if (event.key === 'ArrowUp') {
                event.preventDefault();
                setSelectedIndex(prevIndex => Math.max(prevIndex - 1, 0));
            } else if (event.key === 'ArrowDown') {
                event.preventDefault();
                setSelectedIndex(prevIndex => Math.min(prevIndex + 1, filteredProducts.length - 1));
            } else if (event.key === 'Enter') {
                event.preventDefault();
                onSelect(filteredProducts[selectedIndex]);
            }
        };

        document.addEventListener('keydown', handleKeyDown);

        return () => {
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, [filteredProducts, selectedIndex, onSelect,showLedgerModal]);

    useEffect(() => {
        // Filter products based on the initial key
        handleSearch({ target: { value: initialKey } });
    }, [initialKey]);

   const handleSearch = (e) => {
    const keyword = e.target.value.toLowerCase();

    // Filter products based on `searchField` or `ahead` logic
    const filtered = products.filter(product => 
        product[searchField]?.toLowerCase().includes(keyword) ||
        product.ahead.toLowerCase().split(' ').some(namePart => namePart.startsWith(keyword))
    );

    // Check if there's at least one matching product
    const hasMatches = filtered.length > 0;

    if (hasMatches) {
        // Update state if there's a match
        setSearchTerm(keyword);
        setFilteredProducts(filtered);
        setSelectedIndex(0);
    } else {
        // Prevent input update if no matches
        e.target.value = searchTerm;
    }
};


const handleFieldChange = (event) => {
    setSearchField(event.target.value);
    setSearchTerm(''); // Clear search term when switching fields
    setFilteredProducts(products); // Reset filtered products
};

    const handleRowClick = (product, index) => {
        setSelectedIndex(index);
        onSelect(product);
    };

    const handleDataGridScroll = (event) => {
        event.stopPropagation();
    };

    // Instead of opening a new window, open the modal for LedgerAcc
  const openLedgerModal = () => {
    setShowLedgerModal(true);
  };
    
    const handleModalHide = () => {
        setModalOpen(false);
        onClose();
    };

    return (
        <>
            <Modal show={true} onHide={handleModalHide} fullscreen={true} className="custom-modal" style={{ marginTop: 20 }}>
                <Modal.Header closeButton>
                    <Modal.Title>LEDGER ACCOUNTS</Modal.Title>
                      {/* <Button style={{ marginLeft: "60%" }} variant="primary" onClick={() => setShowSelectModal(true)}>Select Fields</Button> */}
                </Modal.Header>
                <Modal.Body>
                  <div className="list-container" onScroll={handleDataGridScroll}>
                        <TableContainer component={Paper} className="table-container">
                            <Table bordered ref={tableRef}>
                                <TableHead style={{ backgroundColor: "lightgray" }}>
                                    <TableRow>
                                        {selectedFields.map(field => (
                                            <TableCell style={{ textTransform: "uppercase" }} key={field}>{field}</TableCell>
                                        ))}
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {filteredProducts.map((product, index) => (
                                        <TableRow
                                            key={index}
                                            className={selectedIndex === index ? 'highlighted-row' : ''}
                                            onClick={() => handleRowClick(product, index)}
                                        >
                                            {selectedFields.map(field => (
                                                <TableCell key={field}>{product[field]}</TableCell>
                                            ))}
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </div>
                </Modal.Body>
                <div className='searchdiv' style={{marginBottom:10}}>
                    <input
                        type="text"
                        className="search"
                        placeholder="Search..."
                        onChange={handleSearch}
                        value={searchTerm} // Set input value to searchTerm
                        ref={inputRef}
                    />
                     <text style={{fontSize:20,marginLeft:20}} id="search-field-label">Search By:</text>
        <select
        style={{width:200,height:30,marginLeft:10,border:"1px solid black"}}
            labelId="search-field-label"
            value={searchField}
            onChange={handleFieldChange}
        >
            {selectedFields.map(field => (
                <option key={field} value={field}>
                    {field.toUpperCase()}
                </option>
            ))}
        </select>
                    <div className='buttondiv'>
                        <Button className='new' onClick={openLedgerModal}>New</Button>
                        <Button className='modify'>Modify</Button>
                        <Button className='select'>Select</Button>
                        <Button className='closebtn' variant="secondary" onClick={handleModalHide}>
                            Close
                        </Button>
                    </div>
                </div>
                {/* <Modal.Footer /> */}
            </Modal>
            {showSelectModal && (
                <SelectModal
                    allFields={allFields}
                    selectedFields={selectedFields}
                    handleFieldChange={handleFieldChange}
                    onClose={() => setShowSelectModal(false)}
                />
            )}
        {showLedgerModal && (
        <Modal
        dialogClassName="custom-full-width-modal" // Add a custom class
          show
          onHide={() => setShowLedgerModal(false)}
          size="lg"
          style={{zIndex: 100000}}
        >
          <Modal.Body style={{marginTop:10,marginLeft:10}}>
            <LedgerAcc />
          </Modal.Body>
          {/* <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowLedgerModal(false)}>
              Close
            </Button>
          </Modal.Footer> */}
        </Modal>
      )}
        </>
    );
};

export default ProductModalCustomer;
