import React, { useEffect, useRef } from 'react';
import Modal from '@mui/material/Modal';
import { Button } from 'react-bootstrap';
import { Box } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
    borderRadius: 5,
};

const closeButtonStyle = {
    position: 'absolute',
    top: 10,
    right: 10,
    cursor: 'pointer',
};

const ModalNarrtion = ({
    openN, handleCloseN, usersN, filteredUsersN, highlightedIndexN, setHighlightedIndexN,
    handleRowClickN, handleUserClickN, handleSaveClickN, handleAddClickN, editedUserN,
    setEditedUserN, isAddingNewUserN, searchQueryN, handleSearchChangeN, inputRefN, tableBodyRefN
}) => {
    // Handle click event to select narration for a specific row
    const handleRowClick = (userN) => {
        handleRowClickN(userN); // Call the passed function with the selected user
    };

    const searchInputRef = useRef(null);

    useEffect(() => {
        const handleKeyDown = (event) => {
            if (event.key === 'ArrowDown') {
                setHighlightedIndexN((prevIndex) => {
                    const newIndex = (prevIndex + 1) % filteredUsersN.length;
                    scrollToIndex(newIndex);
                    return newIndex;
                });
            } else if (event.key === 'ArrowUp') {
                setHighlightedIndexN((prevIndex) => {
                    const newIndex = (prevIndex - 1 + filteredUsersN.length) % filteredUsersN.length;
                    scrollToIndex(newIndex);
                    return newIndex;
                });
            } else if (event.key === 'Enter') {
                event.preventDefault();
                handleRowClickN(filteredUsersN[highlightedIndexN]);
            }
        };

        if (openN) {
            window.addEventListener('keydown', handleKeyDown);
        }

        return () => {
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, [openN, filteredUsersN, highlightedIndexN, handleRowClickN]);

    const scrollToIndex = (index) => {
        const rowHeight = 40; // Approximate row height, adjust if necessary
        const modalBody = tableBodyRefN.current;
        const offset = index * rowHeight;
        const scrollTop = modalBody.scrollTop;
        const modalHeight = modalBody.clientHeight;

        if (offset < scrollTop) {
            modalBody.scrollTop = offset;
        } else if (offset + rowHeight > scrollTop + modalHeight) {
            modalBody.scrollTop = offset + rowHeight - modalHeight;
        }
    };
    const handleSearchChange = (event) => {
        handleSearchChangeN(event);
        // Reset highlighted index to the first matching item
        setHighlightedIndexN(0);
    };

    // const handleSearchChange = (e) => {
    //     const keyword = e.target.value.toLowerCase();

    //     // Check if the current input matches any usersN names
    //     const matchingUser = usersN.find(user => user.toLowerCase().startsWith(keyword));

    //     if (matchingUser) {
    //         handleSearchChangeN(e); // Call the passed search handler with the event
    //     } else {
    //         e.preventDefault(); // Prevent the input from being typed if no match is found
    //     }
    // };

    return (
        <Modal
            open={openN}
            onClose={handleCloseN}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
        >
            <Box sx={style}>
                <CloseIcon style={closeButtonStyle} onClick={handleCloseN} />
                <h3 style={{ textAlign: 'center' }}>Description</h3>
                <input
                    className='topinputs'
                    type="text"
                    placeholder="Search..."
                    value={searchQueryN}
                    onChange={handleSearchChange} // Use the modified search handler
                    style={{ width: '100%', marginBottom: 10, height: 32 }}
                    ref={searchInputRef}
                />
                <div style={{ maxHeight: 400, overflow: 'auto' }} ref={tableBodyRefN}>
                    <table style={{ width: '100%' }}>
                        <thead>
                            <tr>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredUsersN.map((user, index) => (
                                <tr
                                    key={index}
                                    style={{ backgroundColor: index === highlightedIndexN ? 'skyblue' : 'white', cursor: 'pointer' }}
                                    onClick={() => handleRowClick(user)}
                                >
                                    <td>{user}</td>
                                    <td>
                                        <Button variant="link" onClick={(e) => { e.stopPropagation(); handleUserClickN(user); }}>
                                            Edit
                                        </Button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                <br />
                <label htmlFor="editedUserN">{isAddingNewUserN ? 'Add Narration:' : 'Edit Narration:'}</label>
                <input
                    className='topinputs'
                    style={{ marginTop: 20, width: 190, height: 30 }}
                    type="text"
                    id="editedUserN"
                    ref={inputRefN}
                    value={editedUserN}
                    onChange={(e) => setEditedUserN(e.target.value)}
                />
                <Button className='button' style={{ backgroundColor: 'gold', width: 70, marginLeft: 90, borderColor: "transparent" }} onClick={handleAddClickN}>Add</Button>
                <Button className='button' style={{ backgroundColor: 'green', width: 70, marginLeft: 10, borderColor: "transparent" }} onClick={handleSaveClickN} disabled={!editedUserN.trim()}>Save</Button>
            </Box>
        </Modal>
    );
};

export default ModalNarrtion;
