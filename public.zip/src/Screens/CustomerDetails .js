import React from "react";
import { Table } from "react-bootstrap";

const CustomerDetails = ({ selectedCustomer, goBack }) => {
  // Assuming these details are part of `selectedCustomer.details[0]`
  const { gstno, pan, Add1, city,Vcode } =
    selectedCustomer.details[0]?.customerDetails[0] || {};

  return (
    <div>
      <div style={{display:'flex',flexDirection:'row',marginTop:-35,backgroundColor:"lightyellow"}}>
      <div style={{display:'flex',flexDirection:'column',marginLeft:50}}>
      <div style={{display:'flex',flexDirection:'row'}}>
      <a style={{fontSize:20}}>Code: </a>
      <text style={{fontSize:20,marginLeft:5}}>{Vcode}</text>
        </div>
        <div style={{display:'flex',flexDirection:'row'}}>
      <a style={{fontSize:20}}>Ph: </a>
      <text style={{fontSize:20,marginLeft:5}}>{}</text>
        </div>
        <div style={{display:'flex',flexDirection:'row'}}>
      <a style={{fontSize:20}}>GST#: </a>
      <text style={{fontSize:20,marginLeft:5}}>{gstno}</text>
        </div>
        <div style={{display:'flex',flexDirection:'row'}}>
      <a style={{fontSize:20}}>Pan: </a>
      <text style={{fontSize:20,marginLeft:5}}>{pan}</text>
        </div>
        </div>
        <div style={{display:'flex',flexDirection:'column',textAlign:'center',marginLeft:"7%"}}>
          <h4>{selectedCustomer.vacode}</h4>
          <h4>{Add1}</h4>
          <h4>{city}</h4>
        </div>
        <div style={{marginLeft:40,marginTop:70,fontSize:18}}>
          <text>Press (+) for Remarks</text>
        </div>
        <div style={{display:'flex',flexDirection:'column',marginLeft:100}}>
        <div style={{display:'flex',flexDirection:'row'}}>
        <text style={{fontSize:20}}>Progressive Dr</text>
        <input style={{marginLeft:18.5}}/>
        </div>
        <div style={{display:'flex',flexDirection:'row'}}>
        <text style={{fontSize:20}}>Progressive Cr</text>
        <input style={{marginLeft:21}}/>
        </div>
        <div style={{display:'flex',flexDirection:'row'}}>
        <text style={{fontSize:20}}>Progressive Qty</text>
        <input style={{marginLeft:8.5}}/>
        </div>
        <div style={{display:'flex',flexDirection:'row',marginLeft:85}}>
        <text style={{fontSize:20}}>Period</text>
        <input style={{marginLeft:10}}/>
        <input/>
        </div>
        </div>
      </div>
      {/* <h2>Details for {selectedCustomer.vacode}</h2>
      <h2>GST No: {gstno || "N/A"}</h2>
      <h2>PAN: {pan || "N/A"}</h2>
      <h2>Address: {Add1 || "N/A"}</h2>
      <h2>City: {city || "N/A"}</h2>
      <h2>VCode: {Vcode || "N/A"}</h2> */}
      <div style={{maxHeight:450}} className="tablediv">
      <Table className="custom-table" style={{marginTop:5}}>
        <thead style={{backgroundColor:"skyblue"}}>
          <tr>
            <th>Date</th>
            <th>Type</th>
            <th>Narration</th>
            <th>Debit</th>
            <th>Credit</th>
          </tr>
        </thead>
        <tbody>
          {selectedCustomer.details.map((entry, index) => (
            <tr key={index}>
              <td>{entry.formData.date}</td>
              <td>{entry.formData.vtype}</td>
              <td>TO BillNo: {entry.formData.vbillno}</td>
              <td>{entry.formData.grandtotal}</td>
              <td>{/* Add Credit if available */}</td>
            </tr>
          ))}
        </tbody>
      </Table>
      </div>
    </div>
  );
};

export default CustomerDetails;
