// import React,{useState} from 'react'
// import ProductModal from './Modals/ProductModal'
// import { Table } from 'react-bootstrap';

// const Example = () => {
//     const [items, setItems] = useState([
//       {
//         id: 1,
//         vcode: "",
//         desc:"",
//       },
//     ]);
//     React.useEffect(() => {
//         // Fetch products from the API when the component mounts
//         fetchProducts();
//       }, []);
    
//       const fetchProducts = async () => {
//         try {
//           const response = await fetch(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/stockmaster`);
//           if (!response.ok) {
//             throw new Error("Failed to fetch products");
//           }
//           const data = await response.json();
//           const flattenedData = data.map((item) => ({
//             ...item.formData,
//             _id: item._id,
//           }));
//           setProducts(flattenedData); // Update state with the products
//           setLoading(false);
//         } catch (error) {
//           setError(error.message);
//           setLoading(false);
//         }
//       };
//       // Modal For Items
//       const [pressedKey, setPressedKey] = useState(""); // State to hold the pressed key
//       const [products, setProducts] = useState([]);
//       const [showModal, setShowModal] = useState(false);
//       const [selectedProduct, setSelectedProduct] = useState(null);
//       const [selectedItemIndex, setSelectedItemIndex] = useState(null);
//       const [loading, setLoading] = useState(true);
//       const [error, setError] = useState(null);
    
//       const handleItemChange = (index, key, value,field) => {
//         const updatedItems = [...items];
//         updatedItems[index][key] = value;
    
//         // If the key is 'name', find the corresponding product and set the price
//         if (key === "name") {
//           const selectedProduct = products.find((product) => product.Aheads === value);
//           if (selectedProduct) {
//             updatedItems[index]["vcode"] = selectedProduct.Acodes;
//             updatedItems[index]["desc"] = selectedProduct.Aheads;
//           } else {
//             updatedItems[index]["rate"] = ""; // Reset price if product not found
//             updatedItems[index]["gst"] = ""; // Reset gst if product not found
//           }
//         }
//         setItems(updatedItems);
//       };
    

//       const handleProductSelect = (product) => {
//         if (selectedItemIndex !== null) {
//           handleItemChange(selectedItemIndex, "name", product.Aheads);
//           setShowModal(false);
//           fetchProducts();
//         }
//       };
      
      
//       const openModalForItem = (index) => {
//           setSelectedItemIndex(index);
//           setShowModal(true);
//       };
    
//       const allFields = products.reduce((fields, product) => {
//         Object.keys(product).forEach((key) => {
//           if (!fields.includes(key)) {
//             fields.push(key);
//           }
//         });
    
//         return fields;
//       }, []);

//     const handleOpenModal = (event, index, field) => {
//       if (/^[a-zA-Z]$/.test(event.key) && field === "vcode") {
//         setPressedKey(event.key); // Set the pressed key
//         openModalForItem(index);
//         event.preventDefault(); // Prevent any default action
//       }
//     };
//   return (
//     <div>
//               <div className="tablediv">
//                 <Table  className="custom-table">
//                   <thead style={{background: "skyblue", textAlign: "center", position: "sticky", top: 0,}}>
//                     <tr style={{ color: "#575a5a" }}>
//                       <th>ITEMCODE</th>
//                       <th>DESCRIPTION</th>
//                     </tr>
//                   </thead>
//                   <tbody style={{ overflowY: "auto", maxHeight: "calc(320px - 40px)" }}>
//                     {items.map((item, index) => (
//                       <tr key={item.id}>
//                         <td style={{ padding: 0, width: 30 }}>
//                           <input
//                           className="ItemCode"
//                             style={{height: 40,width: "100%",boxSizing: "border-box",border: "none",padding: 5,}}
//                             type="text"
//                             value={item.vcode}
//                             readOnly
//                             onKeyDown={(e) => {handleOpenModal(e, index, "vcode") }}
//                           />
//                         </td>
//                         <td style={{ padding: 0, width: 30 }}>
//                           <input
//                           className="ItemCode"
//                             style={{height: 40,width: "100%",boxSizing: "border-box",border: "none",padding: 5,}}
//                             type="text"
//                             value={item.desc}
//                             readOnly
//                           />
//                         </td>
//                       </tr>
//                     ))}
//                   </tbody>
//                 </Table>
//               </div>
//               {showModal && (
//                 <ProductModal
//                   allFields={allFields}
//                   products={products}
//                   onSelect={handleProductSelect}
//                   onClose={() => {setShowModal(false)
//                     fetchProducts();
//                   }}
//                   initialKey={pressedKey} // Pass the pressed key to the modal
//                 />
//               )}
           
//     </div>
//   )
// }

// export default Example

import React,{useState} from 'react'
import ProductModal from './Modals/ProductModal'
import { Table } from 'react-bootstrap';

const Example = () => {
    const [items, setItems] = useState([
      {
        id: 1,
        vcode: "",
        desc:"",
      },
    ]);
    React.useEffect(() => {
        // Fetch products from the API when the component mounts
        fetchProducts();
      }, []);
    
      const fetchProducts = async () => {
        try {
          const response = await fetch(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/stockmaster`);
          if (!response.ok) {
            throw new Error("Failed to fetch products");
          }
          const data = await response.json();
          const flattenedData = data.map((item) => ({
            ...item.formData,
            _id: item._id,
          }));
          setProducts(flattenedData); // Update state with the products
          setLoading(false);
        } catch (error) {
          setError(error.message);
          setLoading(false);
        }
      };
      // Modal For Items
      const [pressedKey, setPressedKey] = useState(""); // State to hold the pressed key
      const [products, setProducts] = useState([]);
      const [showModal, setShowModal] = useState(false);
      const [selectedProduct, setSelectedProduct] = useState(null);
      const [selectedItemIndex, setSelectedItemIndex] = useState(null);
      const [loading, setLoading] = useState(true);
      const [error, setError] = useState(null);
    
      const handleItemChange = (index, key, value,field) => {
        const updatedItems = [...items];
        updatedItems[index][key] = value;
    
        // If the key is 'name', find the corresponding product and set the price
        if (key === "name") {
          const selectedProduct = products.find((product) => product.Aheads === value);
          if (selectedProduct) {
            updatedItems[index]["vcode"] = selectedProduct.Acodes;
            updatedItems[index]["desc"] = selectedProduct.Aheads;
          } else {
            updatedItems[index]["rate"] = ""; // Reset price if product not found
            updatedItems[index]["gst"] = ""; // Reset gst if product not found
          }
        }
        setItems(updatedItems);
      };
    

      // const handleProductSelect = (product) => {
      //   if (selectedItemIndex !== null) {
      //     handleItemChange(selectedItemIndex, "name", product.Aheads);
      //     setShowModal(false);
      //     fetchProducts();
      //   }
      // };
      const handleProductSelect = async (product) => {
        if (selectedItemIndex !== null) {
          setItems((prev) => {
            const updated = [...prev];
            updated[selectedItemIndex] = {
              ...updated[selectedItemIndex],
              vcode: product.Acodes,
              desc: product.Aheads,
            };
            return updated;
          });
          setShowModal(false);
          await fetchProducts(); // keep if you want to refresh master list too
        }
      };
      
      
      
      const openModalForItem = (index) => {
          setSelectedItemIndex(index);
          setShowModal(true);
      };
    
      const allFields = products.reduce((fields, product) => {
        Object.keys(product).forEach((key) => {
          if (!fields.includes(key)) {
            fields.push(key);
          }
        });
    
        return fields;
      }, []);

    const handleOpenModal = (event, index, field) => {
      if (/^[a-zA-Z]$/.test(event.key) && field === "vcode") {
        setPressedKey(event.key); // Set the pressed key
        openModalForItem(index);
        event.preventDefault(); // Prevent any default action
      }
    };
  return (
    <div>
              <div className="tablediv">
                <Table  className="custom-table">
                  <thead style={{background: "skyblue", textAlign: "center", position: "sticky", top: 0,}}>
                    <tr style={{ color: "#575a5a" }}>
                      <th>ITEMCODE</th>
                      <th>DESCRIPTION</th>
                    </tr>
                  </thead>
                  <tbody style={{ overflowY: "auto", maxHeight: "calc(320px - 40px)" }}>
                    {items.map((item, index) => (
                      <tr key={item.id}>
                        <td style={{ padding: 0, width: 30 }}>
                          <input
                          className="ItemCode"
                            style={{height: 40,width: "100%",boxSizing: "border-box",border: "none",padding: 5,}}
                            type="text"
                            value={item.vcode}
                            readOnly
                            onKeyDown={(e) => {handleOpenModal(e, index, "vcode") }}
                          />
                        </td>
                        <td style={{ padding: 0, width: 30 }}>
                          <input
                          className="ItemCode"
                            style={{height: 40,width: "100%",boxSizing: "border-box",border: "none",padding: 5,}}
                            type="text"
                            value={item.desc}
                            readOnly
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </div>
              {showModal && (
                <ProductModal
                  allFields={allFields}
                  products={products}
                  onSelect={handleProductSelect}
                  onClose={() => {setShowModal(false)
                    fetchProducts();
                  }}
                  initialKey={pressedKey} // Pass the pressed key to the modal
                />
              )}
           
    </div>
  )
}

export default Example

