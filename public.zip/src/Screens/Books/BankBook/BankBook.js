import React, { useState, useEffect } from "react";
import { Modal, Box, Button, Select, MenuItem } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import axios from "axios";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import BankBookPrint from "./BankBookPrint";
import "./BankBook.css"
import { CompanyContext } from "../../Context/CompanyContext";
import { useContext } from "react";
const BankBook = ({ isOpen, handleClose, onNavigate }) => {

  const { company } = useContext(CompanyContext);
  const tenant = company?.databaseName;

  if (!tenant) {
    // you may want to guard here or show an error state,
    // since without a tenant you can’t hit the right API
    console.error("No tenant selected!");
  }

  const [fromDate, setFromDate] = useState(null);
  const [uptoDate, setUptoDate] = useState(null);
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState({});
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [selectedType, setSelectedType] = useState("all");
  const [selectedBank, setSelectedBank] = useState("all");
  const [bankList, setBankList] = useState([]);
  const [isSplitByDate, setIsSplitByDate] = useState(false);

  useEffect(() => {
    if (isOpen) fetchData();
  }, [isOpen]);

  const fetchData = async () => {
    try {
      const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/bank`);
      setData(response.data);

      // Extract unique bank names from bankdetails
      const banks = new Set();
      response.data.forEach((entry) => {
        entry.bankdetails.forEach((bank) => {
          banks.add(bank.Bankname);
        });
      });

      setBankList([...banks]);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleFilter = () => {
    if (!fromDate || !uptoDate) {
      alert("Please select both dates.");
      return;
    }

    const from = new Date(fromDate);
    const upto = new Date(uptoDate);
    const groupedData = {};

    data.forEach((entry) => {
      const entryDate = new Date(entry.formData.date);
      if (entryDate >= from && entryDate <= upto) {
        if (!groupedData[entry.formData.date]) {
          groupedData[entry.formData.date] = { receipts: [], payments: [] };
        }

        // Check if the entry matches the selected bank
        const isMatchingBank =
          selectedBank === "all" || entry.bankdetails.some((bank) => bank.Bankname === selectedBank);

        if (isMatchingBank) {
          entry.items.forEach((item) => {
            if (selectedType === "all" || selectedType === "receipt_credit") {
              if (parseFloat(item.receipt_credit) > 0) {
                groupedData[entry.formData.date].receipts.push({
                  ...item,
                  voucherno: entry.formData.voucherno,
                });
              }
            }

            if (selectedType === "all" || selectedType === "payment_debit") {
              if (parseFloat(item.payment_debit) > 0) {
                groupedData[entry.formData.date].payments.push({
                  ...item,
                  voucherno: entry.formData.voucherno,
                });
              }
            }
          });
        }
      }
    });

    setFilteredData(groupedData);
    setIsPrintModalOpen(true); // Open Print Modal after filtering
  };

  const handleClose2 = () => {
    handleClose();
    onNavigate();
  };

  return (
    <>
      {/* Date Selection & Filter Modal */}
      <Modal open={isOpen} onClose={handleClose2}>
        <Box
          sx={{
            bgcolor: "white",
            p: 4,
            width: "40%",
            margin: "auto",
            mt: 5,
            borderRadius: 4,
            // textAlign: "center",
          }}
        >
          <button
            onClick={handleClose2}
            style={{
              position: "absolute",
              right: 10,
              top: 10,
              background: "none",
              border: "none",
              cursor: "pointer",
            }}
          >
            <CloseIcon />
          </button>
          <h3  style={{textAlign:'center',fontStyle:'oblique',textDecoration:'underline'}}>Bank Book Printing</h3>

          <div style={{marginTop:30}}>
            <label>From Date:</label>
            <DatePicker
              selected={fromDate}
              onChange={(date) => setFromDate(date)}
              dateFormat="dd/MM/yyyy"
              className="datepickerBank"
            />
          </div>

          <div style={{marginTop:5}}>
            <label>Upto Date:</label>
            <DatePicker
              selected={uptoDate}
              onChange={(date) => setUptoDate(date)}
              dateFormat="dd/MM/yyyy"
              className="datepickerBank2"
            />
          </div>

          {/* New Select Field */}
          <div style={{display:'flex',flexDirection:'row',marginTop:5}}>
            <label>Filter By:</label>
            <select
            className="Type"
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
            >
              <option value="all">All</option>
              <option value="receipt_credit">Receipts</option>
              <option value="payment_debit">Payments</option>
            </select>
          </div>

          {/* Bank Name Select */}
          <div style={{ marginBottom: 20,marginTop:8 }}>
            <label>Bank Name:</label>
            <select
             className="Type2"
              value={selectedBank}
              onChange={(e) => setSelectedBank(e.target.value)}
            >
              <option value="all">All Banks</option>
              {bankList.map((bank, index) => (
                <option key={index} value={bank}>
                  {bank}
                </option>
              ))}
            </select>
          </div>
          
          <div style={{marginTop:5}}>
          <label>
            <input
              type="checkbox"
              checked={isSplitByDate}
              onChange={(e) => setIsSplitByDate(e.target.checked)}
              style={{ marginRight: 8 }}
            />
            Print each date on a new page
          </label>
        </div>

          <Button
            variant="contained"
            color="primary"
            onClick={handleFilter}
            style={{ marginRight: 10 }}
          >
            View & Print
          </Button>
          <Button
            variant="contained"
            color="secondary"
            onClick={handleClose2}
          >
            Close
          </Button>
        </Box>
      </Modal>

      {/* Print Preview Modal */}
      <BankBookPrint
        isOpen={isPrintModalOpen}
        handleClose={() => setIsPrintModalOpen(false)}
        filteredData={filteredData}
        fromDate={fromDate}   // Pass From Date
        uptoDate={uptoDate}   // Pass Upto Date
        splitByDate={isSplitByDate}
      />
    </>
  );
};

export default BankBook;
