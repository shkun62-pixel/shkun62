import React, { useRef } from "react";
import { Modal, Box, Button, Table, TableContainer, Paper } from "@mui/material";
import { useReactToPrint } from "react-to-print";

const PrintJBook = ({ isOpen, handleClose, filteredData,splitByDate  }) => {
  const componentRef = useRef();

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });

 // Helper function to format date to dd/mm/yyyy
    const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-GB"); // 'en-GB' formats to dd/mm/yyyy
  };

  return (
    <Modal open={isOpen} onClose={handleClose}>
      <Box
        sx={{
          bgcolor: "white",
          p: 4,
          width: "90%",
          margin: "auto",
          mt: 5,
          overflowY: "auto",
          maxHeight: "80vh",
        }}
      >
          <Button variant="contained" color="primary" onClick={handlePrint} style={{ }}>
          Print
        </Button>
        <Button variant="contained" color="secondary" onClick={handleClose} style={{ marginLeft: 10 }}>
          Close
        </Button>
        {/* Printable Area */}
        <div ref={componentRef} style={{ padding: 10 }}>
           {/* Print-Specific Styles */}
           <style>
            {`
            @media print {
  * {
    -webkit-print-color-adjust: exact;
  }

  body {
    margin: 0;
    padding: 0;
  }

  div.page-break {
    page-break-before: always;
    padding-top: 20px; /* This adds space after page break */
  }

  div.page-break:first-of-type {
    page-break-before: auto;
  }

  /* Add safe margin to avoid cutting at top */
  .print-page-inner {
    margin-top: 20px;
  }

  table {
    page-break-inside: auto;
  }

  tr {
    page-break-inside: avoid;
    page-break-after: auto;
  }
}

            `}
          </style>
            {/* Print Header Once If Not Splitting Pages */}
{!splitByDate && (
  <>
    <h4 style={{ textAlign: "center" }}>SHADOW PVT LTD.</h4>
    <h4 style={{ textAlign: "center" }}>Tower-II, Floor No.2</h4>
    <h4 style={{ textAlign: "center" }}>Mandi Gobindgarh</h4>
  </>
)}
          {Object.keys(filteredData).map((date, idx) => {
            const { receipts, payments } = filteredData[date];
            const receiptTotal = receipts.reduce((sum, item) => sum + parseFloat(item.debit || 0), 0);
            const paymentTotal = payments.reduce((sum, item) => sum + parseFloat(item.credit || 0), 0);

            const showReceipts = receipts.length > 0 && receiptTotal > 0;
            const showPayments = payments.length > 0 && paymentTotal > 0;

            return (
              <div key={idx} style={{ marginBottom: 30, border: "1px solid black", padding: 15,marginTop:20 }} className={splitByDate ? "page-break" : "no-break"}>
                {splitByDate && (
        <>
          <h4 style={{ textAlign: "center" }}>SHADOW PVT LTD.</h4>
          <h4 style={{ textAlign: "center" }}>Tower-II, Floor No.2</h4>
          <h4 style={{ textAlign: "center" }}>Mandi Gobindgarh</h4>
        </>
      )}
                <h4 style={{ textAlign: "center", textDecoration: "underline" }}>Date: {formatDate(date)}</h4>

                <div style={{ display: "flex", justifyContent: "center", gap: 10 }}>
                  {/* Receipts Table */}
                  {showReceipts && (
                    <TableContainer component={Paper} style={{ width: showPayments ? "50%" : "100%" }}>
                      <h4 style={{ textAlign: "center" }}>Receipts</h4>
                      <Table>
                        <thead>
                          <tr style={{ backgroundColor: "lightgrey" }}>
                            <th style={styles.tableHeader}>Account Name</th>
                            <th style={styles.tableHeader}>Narration</th>
                            <th style={styles.tableHeader}>Debit</th>
                          </tr>
                        </thead>
                        <tbody>
                          {receipts.map((item, idx) => (
                            <tr key={idx}>
                              <td style={styles.tableCell}>{item.accountname}</td>
                              <td style={styles.tableCell}>{item.narration}</td>
                              <td style={{ ...styles.tableCell, textAlign: "right" }}>{item.debit}</td>
                            </tr>
                          ))}
                          <tr style={{ fontWeight: "bold" }}>
                            <td style={styles.subTotalCell}>Sub Total</td>
                            <td style={styles.subTotalCell}></td>
                            <td style={{ ...styles.subTotalCell, textAlign: "right" }}>{receiptTotal.toFixed(2)}</td>
                          </tr>
                        </tbody>
                      </Table>
                    </TableContainer>
                  )}

                  {/* Payments Table */}
                  {showPayments && (
                    <TableContainer component={Paper} style={{ width: showReceipts ? "50%" : "100%" }}>
                      <h4 style={{ textAlign: "center" }}>Payments</h4>
                      <Table>
                        <thead>
                          <tr style={{ backgroundColor: "lightgrey" }}>
                            <th style={styles.tableHeader}>Account Name</th>
                            <th style={styles.tableHeader}>Narration</th>
                            <th style={styles.tableHeader}>Credit</th>
                          </tr>
                        </thead>
                        <tbody>
                          {payments.map((item, idx) => (
                            <tr key={idx}>
                              <td style={styles.tableCell}>{item.accountname}</td>
                              <td style={styles.tableCell}>{item.narration}</td>
                              <td style={{ ...styles.tableCell, textAlign: "right" }}>{item.credit}</td>
                            </tr>
                          ))}
                          <tr style={{ fontWeight: "bold" }}>
                            <td style={styles.subTotalCell}>Sub Total</td>
                            <td style={styles.subTotalCell}></td>
                            <td style={{ ...styles.subTotalCell, textAlign: "right" }}>{paymentTotal.toFixed(2)}</td>
                          </tr>
                        </tbody>
                      </Table>
                    </TableContainer>
                  )}
                </div>

                {/* Cash in Hand Display */}
                <div style={{ textAlign: "right", fontWeight: "bold", marginTop: 10 }}>
                  Cash in Hand: {(receiptTotal - paymentTotal).toFixed(2)}
                </div>
              </div>
            );
          })}
        </div>
      </Box>
    </Modal>
  );
};

// Styles for table elements
const styles = {
  tableHeader: {
    border: "1px solid black",
    padding: "8px",
    textAlign: "center",
    fontWeight: "bold",
  },
  tableCell: {
    border: "1px solid black",
    padding: "8px",
    textAlign: "left",
  },
  subTotalCell: {
    border: "1px solid black",
    padding: "8px",
    fontWeight: "bold",
    backgroundColor: "#f0f0f0",
  },
};

export default PrintJBook;
