// import React, { useEffect, useState } from "react";
// import { Table, Button } from "react-bootstrap";
// import * as XLSX from "xlsx";
// import PurBookPrint from "./PurBookPrint";

// const PurchaseBook = () => {
//   const [entries, setEntries] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const [modalOpen, setModalOpen] = useState(false); // State for modal visibility

//   // Fetch data from API
//   useEffect(() => {
//     const fetchEntries = async () => {
//       try {
//         const response = await fetch("http://103.154.233.29:3007/auth/api/purchase"); // Replace with your API endpoint
//         if (!response.ok) {
//           throw new Error("Failed to fetch data");
//         }
//         const data = await response.json();
//         setEntries(data);
//       } catch (err) {
//         setError(err.message);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchEntries();
//   }, []);

//   // Calculate total of grandtotal
//   const totalGrandTotal = entries.reduce((acc, entry) => {
//     const formData = entry.formData || {};
//     return acc + parseFloat(formData.grandtotal || 0);
//   }, 0);

//     // Calculate total of CGST
//     const totalCGST = entries.reduce((acc, entry) => {
//         const formData = entry.formData || {};
//         return acc + parseFloat(formData.cgst || 0);
//       }, 0);
//        // Calculate total of SGST
//     const totalSGST = entries.reduce((acc, entry) => {
//         const formData = entry.formData || {};
//         return acc + parseFloat(formData.sgst || 0);
//       }, 0);
//        // Calculate total of IGST
//     const totalIGST = entries.reduce((acc, entry) => {
//         const formData = entry.formData || {};
//         return acc + parseFloat(formData.igst || 0);
//       }, 0);
//        // Calculate total of IGST
//     const totalTAX = entries.reduce((acc, entry) => {
//         const formData = entry.formData || {};
//         return acc + parseFloat(formData.tax || 0);
//       }, 0);
//   // Export to Excel
//   const exportToExcel = () => {
//     const excelData = entries.map((entry) => {
//       const formData = entry.formData || {};
//       const supplierdetails = entry.supplierdetails?.[0] || {};
//       const items = entry.items?.[0] || {};
//       return [
//         formData.date || "",
//         formData.vno || "",
//         supplierdetails.vacode?.trim() || "",
//         supplierdetails.city || "",
//         supplierdetails.gstno || "",
//         formData.grandtotal || "0",
//         formData.tax || "0",
//         formData.cgst || "0",
//         formData.sgst || "0",
//         formData.igst || "0",
//         items.Exp1 || "0",
//         items.Exp2 || "0",
//         items.Exp3 || "0",
//         items.Exp4 || "0",
//         items.Exp5 || "0",
//         items.Exp6 || "0",
//         formData.Exp7 || "0",
//         formData.Exp8 || "0",
//         formData.Exp9 || "0",
//         formData.Exp10 || "0",
//         formData.Exp11 || "0",
//         formData.Exp12 || "0",
//         formData.sub_total || "0",
//         formData.trpt || "",
//         formData.v_tpt || "",
//         formData.gr || "",
//         formData.broker || "",
//         formData.rem2 || "",
//         formData.exfor || "",
//         supplierdetails.state || "",
//         supplierdetails.Add1 || "",
//         supplierdetails.pan || "",
//       ];
//     });

//     // Add header and title
//     const header = [
//       ["SHKUNSOFT INNOVATIONS"], // Title
//       ["Date", "Bill No.", "Name", "City", "GSTIN", "Bill Amount", "Tax", "CGST", "SGST", "IGST", "Exp1", "Exp2", "Exp3", "Exp4", "Exp5", "Exp6", "Exp7", "Exp8", "Exp9", "Exp10", "Exp11", "Exp12", "NetValue", "VehicleNo", "Transporter", "GrNo", "Broker", "Rem", "Terms", "State", "Add", "Pan"], // Table headers
//     ];

//     // Combine title, header, and data
//     const worksheetData = [...header, ...excelData];

//     // Create worksheet
//     const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);

//     // Merge title cell across all columns
//     XLSX.utils.sheet_add_aoa(worksheet, [["SHKUNSOFT INNOVATIONS"]], { origin: "A1" });
//     worksheet["!merges"] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: 6 } }]; // Merge A1:G1

//     // Create workbook and append worksheet
//     const workbook = XLSX.utils.book_new();
//     XLSX.utils.book_append_sheet(workbook, worksheet, "Entries");

//     // Export the workbook as an Excel file
//     XLSX.writeFile(workbook, "PurBook.xlsx");
//   };

//   // Render loading, error, or table
//   if (loading) return <p>Loading...</p>;
//   if (error) return <p>Error: {error}</p>;
// // Function to handle modal open
// const handleOpenModal = (entry) => {
//     setModalOpen(true);
//   };

//   // Function to close modal
//   const handleCloseModal = () => {
//     setModalOpen(false);
//   };

//   return (
//     <div>
//       <h3 style={{textAlign:"center"}}>PURCHASE BOOK</h3>
//       <Button onClick={exportToExcel} variant="success" style={{ }}>
//         Export to Excel
//       </Button>
//      <Button style={{marginLeft:10}} variant="info" onClick={() => handleOpenModal()}>
//                         Print
//                       </Button>
//       <div style={{maxHeight:540,overflowY:"auto",margin:5}}>
//       <Table className="custom-table" bordered>
//         <thead style={{ backgroundColor: "skyblue", position: "sticky", top: 0,}}>
//           <tr>
//             <th>Date</th>
//             <th>Bill No.</th>
//             <th>A/C Name</th>
//             <th>City</th>
//             <th>Value</th>
//             <th>C.Tax</th>
//             <th>S.Tax</th>
//             <th>I.Tax</th>
//             <th>Tax</th>
//           </tr>
//         </thead>
//         <tbody>
//           {entries.map((entry, index) => {
//             const formData = entry.formData || {};
//             const supplierdetails = entry.supplierdetails?.[0] || {};
//             return (
//               <tr key={index}>
//               <td>
//   {formData.date ? new Date(formData.date).toLocaleDateString("en-GB") : ""}
// </td>
//                 <td>{formData.vno || ""}</td>
//                 <td>{supplierdetails.vacode?.trim() || ""}</td>
//                 <td>{supplierdetails.city || ""}</td>
//                 <td>{formData.grandtotal || ""}</td>
//                 <td>{formData.cgst || ""}</td>
//                 <td>{formData.sgst || ""}</td>
//                 <td>{formData.igst || ""}</td>
//                 <td>{formData.tax || ""}</td>
//               </tr>
//             );
//           })}
//         </tbody>
//         <tfoot>
//             <tr>
//                 <td></td>
//                 <td></td>
//                 <td></td>
//                 <td style={{fontWeight:'bold'}}>TOTAL</td>
//                 <td style={{fontWeight:'bold',color:'red'}}>{totalGrandTotal.toFixed(2)}</td>
//                 <td style={{fontWeight:'bold',color:'red'}}>{totalCGST.toFixed(2)}</td>
//                 <td style={{fontWeight:'bold',color:'red'}}>{totalSGST.toFixed(2)}</td>
//                 <td style={{fontWeight:'bold',color:'red'}}>{totalIGST.toFixed(2)}</td>
//                 <td style={{fontWeight:'bold',color:'red'}}>{totalTAX.toFixed(2)}</td>
//             </tr>
//         </tfoot>
//       </Table>
//       </div>
//       <div style={{ display: "none" }}>
//         <PurBookPrint
//           // ref={invoiceRef}
//           formData={{}}
//           items={entries}
//           supplierdetails={[]}
//           shipped={false}
//           isOpen={modalOpen}
//           handleClose={handleCloseModal}
//           shopName="SHKUNSOFT INNOVATIONS"
//           description="Sales Book Table"
//           GSTIN="Your GSTIN"
//           PAN="Your PAN"
//           address="Motia Khan"
//         />
//       </div>
//     </div>
//   );
// };

// export default PurchaseBook;

// import React, { useEffect, useState } from "react";
// import { Table, Button, Form } from "react-bootstrap";
// import * as XLSX from "xlsx";
// import PurBookPrint from "./PurBookPrint";

// const PurchaseBook = () => {
//   const [entries, setEntries] = useState([]);
//   const [filteredEntries, setFilteredEntries] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const [modalOpen, setModalOpen] = useState(false);
//   const [fromDate, setFromDate] = useState("");
//   const [toDate, setToDate] = useState("");

//   useEffect(() => {
//     const fetchEntries = async () => {
//       try {
//         const response = await fetch("http://103.154.233.29:3007/auth/api/purchase");
//         if (!response.ok) {
//           throw new Error("Failed to fetch data");
//         }
//         const data = await response.json();
//         setEntries(data);
//         setFilteredEntries(data); // Initially show all data
//       } catch (err) {
//         setError(err.message);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchEntries();
//   }, []);

//   // Filter data based on date range
//   useEffect(() => {
//     if (!fromDate || !toDate) {
//       setFilteredEntries(entries);
//       return;
//     }

//     const filtered = entries.filter((entry) => {
//       const entryDate = new Date(entry.formData?.date);
//       return entryDate >= new Date(fromDate) && entryDate <= new Date(toDate);
//     });

//     setFilteredEntries(filtered);
//   }, [fromDate, toDate, entries]);

//   // Calculate totals based on filtered data
//   const totalGrandTotal = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.grandtotal || 0), 0);
//   const totalCGST = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.cgst || 0), 0);
//   const totalSGST = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.sgst || 0), 0);
//   const totalIGST = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.igst || 0), 0);
//   const totalTAX = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.tax || 0), 0);

//   // Function to open modal
//   const handleOpenModal = () => setModalOpen(true);
//   const handleCloseModal = () => setModalOpen(false);

//   // Export to Excel
//   const exportToExcel = () => {
//     const excelData = entries.map((entry) => {
//       const formData = entry.formData || {};
//       const supplierdetails = entry.supplierdetails?.[0] || {};
//       const items = entry.items?.[0] || {};
//       return [
//         formData.date || "",
//         formData.vno || "",
//         supplierdetails.vacode?.trim() || "",
//         supplierdetails.city || "",
//         supplierdetails.gstno || "",
//         formData.grandtotal || "0",
//         formData.tax || "0",
//         formData.cgst || "0",
//         formData.sgst || "0",
//         formData.igst || "0",
//         items.Exp1 || "0",
//         items.Exp2 || "0",
//         items.Exp3 || "0",
//         items.Exp4 || "0",
//         items.Exp5 || "0",
//         items.Exp6 || "0",
//         formData.Exp7 || "0",
//         formData.Exp8 || "0",
//         formData.Exp9 || "0",
//         formData.Exp10 || "0",
//         formData.Exp11 || "0",
//         formData.Exp12 || "0",
//         formData.sub_total || "0",
//         formData.trpt || "",
//         formData.v_tpt || "",
//         formData.gr || "",
//         formData.broker || "",
//         formData.rem2 || "",
//         formData.exfor || "",
//         supplierdetails.state || "",
//         supplierdetails.Add1 || "",
//         supplierdetails.pan || "",
//       ];
//     });

//     // Add header and title
//     const header = [
//       ["SHKUNSOFT INNOVATIONS"], // Title
//       ["Date", "Bill No.", "Name", "City", "GSTIN", "Bill Amount", "Tax", "CGST", "SGST", "IGST", "Exp1", "Exp2", "Exp3", "Exp4", "Exp5", "Exp6", "Exp7", "Exp8", "Exp9", "Exp10", "Exp11", "Exp12", "NetValue", "VehicleNo", "Transporter", "GrNo", "Broker", "Rem", "Terms", "State", "Add", "Pan"], // Table headers
//     ];

//     // Combine title, header, and data
//     const worksheetData = [...header, ...excelData];

//     // Create worksheet
//     const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);

//     // Merge title cell across all columns
//     XLSX.utils.sheet_add_aoa(worksheet, [["SHKUNSOFT INNOVATIONS"]], { origin: "A1" });
//     worksheet["!merges"] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: 6 } }]; // Merge A1:G1

//     // Create workbook and append worksheet
//     const workbook = XLSX.utils.book_new();
//     XLSX.utils.book_append_sheet(workbook, worksheet, "Entries");

//     // Export the workbook as an Excel file
//     XLSX.writeFile(workbook, "PurBook.xlsx");
//   };


//   if (loading) return <p>Loading...</p>;
//   if (error) return <p>Error: {error}</p>;

//   return (
//     <div>
//       <h3 style={{ textAlign: "center" }}>PURCHASE BOOK</h3>

//       {/* Date Pickers */}
//       <div style={{ display: "flex", justifyContent: "center", marginBottom: 10 }}>
//         <Form.Control
//           type="date"
//           value={fromDate}
//           onChange={(e) => setFromDate(e.target.value)}
//           style={{ width: "200px", marginRight: "10px" }}
//         />
//         <Form.Control
//           type="date"
//           value={toDate}
//           onChange={(e) => setToDate(e.target.value)}
//           style={{ width: "200px", marginRight: "10px" }}
//         />
//       </div>

//       <Button onClick={handleOpenModal} variant="info" style={{ marginLeft: 10 }}>
//         Print
//       </Button>
//       <Button onClick={exportToExcel} variant="info" style={{ marginLeft: 10 }}>
//         Export
//       </Button>

//       <div style={{ maxHeight: 540, overflowY: "auto", margin: 5 }}>
//         <Table className="custom-table" bordered>
//           <thead style={{ backgroundColor: "skyblue", position: "sticky", top: 0 }}>
//             <tr>
//               <th>Date</th>
//               <th>Bill No.</th>
//               <th>A/C Name</th>
//               <th>City</th>
//               <th>Value</th>
//               <th>C.Tax</th>
//               <th>S.Tax</th>
//               <th>I.Tax</th>
//               <th>Tax</th>
//             </tr>
//           </thead>
//           <tbody>
//             {filteredEntries.map((entry, index) => {
//               const formData = entry.formData || {};
//               const supplierdetails = entry.supplierdetails?.[0] || {};
//               return (
//                 <tr key={index}>
//                   <td>{formData.date ? new Date(formData.date).toLocaleDateString("en-GB") : ""}</td>
//                   <td>{formData.vno || ""}</td>
//                   <td>{supplierdetails.vacode?.trim() || ""}</td>
//                   <td>{supplierdetails.city || ""}</td>
//                   <td>{formData.grandtotal || ""}</td>
//                   <td>{formData.cgst || ""}</td>
//                   <td>{formData.sgst || ""}</td>
//                   <td>{formData.igst || ""}</td>
//                   <td>{formData.tax || ""}</td>
//                 </tr>
//               );
//             })}
//           </tbody>
//           <tfoot>
//             <tr>
//               <td colSpan="4" style={{ fontWeight: "bold" }}>TOTAL</td>
//               <td style={{ fontWeight: "bold", color: "red" }}>{totalGrandTotal.toFixed(2)}</td>
//               <td style={{ fontWeight: "bold", color: "red" }}>{totalCGST.toFixed(2)}</td>
//               <td style={{ fontWeight: "bold", color: "red" }}>{totalSGST.toFixed(2)}</td>
//               <td style={{ fontWeight: "bold", color: "red" }}>{totalIGST.toFixed(2)}</td>
//               <td style={{ fontWeight: "bold", color: "red" }}>{totalTAX.toFixed(2)}</td>
//             </tr>
//           </tfoot>
//         </Table>
//       </div>

//       <div style={{ display: "none" }}>
//         <PurBookPrint
//           isOpen={modalOpen}
//           handleClose={handleCloseModal}
//           items={filteredEntries}
//           shopName="SHKUNSOFT INNOVATIONS"
//           description="Sales Book Table"
//           GSTIN="Your GSTIN"
//           PAN="Your PAN"
//           address="Motia Khan"
//         />
//       </div>
//     </div>
//   );
// };

// export default PurchaseBook;


// import React, { useEffect, useState } from "react";
// import { Table, Button, Form, Modal } from "react-bootstrap";
// import * as XLSX from "xlsx";
// import PurBookPrint from "./PurBookPrint";

// const PurchaseBook = () => {
//   const [entries, setEntries] = useState([]);
//   const [filteredEntries, setFilteredEntries] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const [modalOpen, setModalOpen] = useState(false);
//   const [moreModalOpen, setMoreModalOpen] = useState(false);
//   const [fromDate, setFromDate] = useState("");
//   const [toDate, setToDate] = useState("");
//   const [selectedSupplier, setSelectedSupplier] = useState("");

//   useEffect(() => {
//     const fetchEntries = async () => {
//       try {
//         const response = await fetch("http://103.154.233.29:3007/auth/api/purchase");
//         if (!response.ok) {
//           throw new Error("Failed to fetch data");
//         }
//         const data = await response.json();
//         setEntries(data);
//         setFilteredEntries(data);
//       } catch (err) {
//         setError(err.message);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchEntries();
//   }, []);

//   useEffect(() => {
//     let filtered = entries;
//     if (fromDate && toDate) {
//       filtered = filtered.filter((entry) => {
//         const entryDate = new Date(entry.formData?.date);
//         return entryDate >= new Date(fromDate) && entryDate <= new Date(toDate);
//       });
//     }
//     if (selectedSupplier) {
//       filtered = filtered.filter(
//         (entry) => entry.supplierdetails?.[0]?.vacode === selectedSupplier
//       );
//     }
//     setFilteredEntries(filtered);
//   }, [fromDate, toDate, selectedSupplier, entries]);

//   const uniqueSuppliers = [...new Set(entries.map((entry) => entry.supplierdetails?.[0]?.vacode).filter(Boolean))];

//   //   // Function to close modal
//   const handleCloseModal = () => {
//     setModalOpen(false);
//   };

//     // Export to Excel
//     const exportToExcel = () => {
//       const excelData = entries.map((entry) => {
//         const formData = entry.formData || {};
//         const supplierdetails = entry.supplierdetails?.[0] || {};
//         const items = entry.items?.[0] || {};
//         return [
//           formData.date || "",
//           formData.vno || "",
//           supplierdetails.vacode?.trim() || "",
//           supplierdetails.city || "",
//           supplierdetails.gstno || "",
//           formData.grandtotal || "0",
//           formData.tax || "0",
//           formData.cgst || "0",
//           formData.sgst || "0",
//           formData.igst || "0",
//           items.Exp1 || "0",
//           items.Exp2 || "0",
//           items.Exp3 || "0",
//           items.Exp4 || "0",
//           items.Exp5 || "0",
//           items.Exp6 || "0",
//           formData.Exp7 || "0",
//           formData.Exp8 || "0",
//           formData.Exp9 || "0",
//           formData.Exp10 || "0",
//           formData.Exp11 || "0",
//           formData.Exp12 || "0",
//           formData.sub_total || "0",
//           formData.trpt || "",
//           formData.v_tpt || "",
//           formData.gr || "",
//           formData.broker || "",
//           formData.rem2 || "",
//           formData.exfor || "",
//           supplierdetails.state || "",
//           supplierdetails.Add1 || "",
//           supplierdetails.pan || "",
//         ];
//       });
  
//       // Add header and title
//       const header = [
//         ["SHKUNSOFT INNOVATIONS"], // Title
//         ["Date", "Bill No.", "Name", "City", "GSTIN", "Bill Amount", "Tax", "CGST", "SGST", "IGST", "Exp1", "Exp2", "Exp3", "Exp4", "Exp5", "Exp6", "Exp7", "Exp8", "Exp9", "Exp10", "Exp11", "Exp12", "NetValue", "VehicleNo", "Transporter", "GrNo", "Broker", "Rem", "Terms", "State", "Add", "Pan"], // Table headers
//       ];
  
//       // Combine title, header, and data
//       const worksheetData = [...header, ...excelData];
  
//       // Create worksheet
//       const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
  
//       // Merge title cell across all columns
//       XLSX.utils.sheet_add_aoa(worksheet, [["SHKUNSOFT INNOVATIONS"]], { origin: "A1" });
//       worksheet["!merges"] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: 6 } }]; // Merge A1:G1
  
//       // Create workbook and append worksheet
//       const workbook = XLSX.utils.book_new();
//       XLSX.utils.book_append_sheet(workbook, worksheet, "Entries");
  
//       // Export the workbook as an Excel file
//       XLSX.writeFile(workbook, "PurBook.xlsx");
//     };
  
//   // Calculate totals based on filtered data
//   const totalGrandTotal = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.grandtotal || 0), 0);
//   const totalCGST = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.cgst || 0), 0);
//   const totalSGST = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.sgst || 0), 0);
//   const totalIGST = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.igst || 0), 0);
//   const totalTAX = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.tax || 0), 0);

//   if (loading) return <p>Loading...</p>;
//   if (error) return <p>Error: {error}</p>;

//   return (
//     <div>
//       <h3 style={{ textAlign: "center" }}>PURCHASE BOOK</h3>
//       <div style={{ display: "flex", justifyContent: "center", marginBottom: 10 }}>
//         <Form.Control type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} style={{ width: "200px", marginRight: "10px" }} />
//         <Form.Control type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} style={{ width: "200px", marginRight: "10px" }} />
//       </div>

//       <Button onClick={exportToExcel} variant="info" style={{ marginLeft: 10 }}>Export</Button>
//       <Button onClick={() => setModalOpen(true)} variant="info" style={{ marginLeft: 10 }}>Print</Button>
//       <div style={{ display: "none" }}>
//          <PurBookPrint
//           isOpen={modalOpen}
//           handleClose={handleCloseModal}
//           items={filteredEntries}
//           shopName="SHKUNSOFT INNOVATIONS"
//           description="Sales Book Table"
//           GSTIN="Your GSTIN"
//           PAN="Your PAN"
//           address="Motia Khan"
//         />
//       </div>
//       <Button onClick={() => setMoreModalOpen(true)} variant="info" style={{ marginLeft: 10 }}>More</Button>

//       <div style={{ maxHeight: 520, overflowY: "auto",padding:5}}>
//         <Table className="custom-table" bordered>
//           <thead style={{ backgroundColor: "skyblue", position: "sticky", top: -6 }}>
//             <tr>
//               <th>Date</th>
//               <th>Bill No.</th>
//               <th>A/C Name</th>
//               <th>City</th>
//               <th>Value</th>
//               <th>C.Tax</th>
//               <th>S.Tax</th>
//               <th>I.Tax</th>
//               <th>Tax</th>
//             </tr>
//           </thead>
//           <tbody>
//             {filteredEntries.map((entry, index) => {
//               const formData = entry.formData || {};
//               const supplierdetails = entry.supplierdetails?.[0] || {};
//               return (
//                 <tr key={index} style={{fontSize:18}}>
//                   <td>{formData.date ? new Date(formData.date).toLocaleDateString("en-GB") : ""}</td>
//                   <td>{formData.vno || ""}</td>
//                   <td>{supplierdetails.vacode?.trim() || ""}</td>
//                   <td>{supplierdetails.city || ""}</td>
//                   <td>{formData.grandtotal || ""}</td>
//                   <td>{formData.cgst || ""}</td>
//                   <td>{formData.sgst || ""}</td>
//                   <td>{formData.igst || ""}</td>
//                   <td>{formData.tax || ""}</td>
//                 </tr>
//               );
//             })}
//           </tbody>
//           <tfoot style={{ backgroundColor: "skyblue", position: "sticky", bottom: -6 }}>
//             <tr>
//               <td colSpan="4" style={{ fontWeight: "bold" }}>TOTAL</td>
//               <td style={{ fontWeight: "bold", color: "red" }}>{totalGrandTotal.toFixed(2)}</td>
//               <td style={{ fontWeight: "bold", color: "red" }}>{totalCGST.toFixed(2)}</td>
//               <td style={{ fontWeight: "bold", color: "red" }}>{totalSGST.toFixed(2)}</td>
//               <td style={{ fontWeight: "bold", color: "red" }}>{totalIGST.toFixed(2)}</td>
//               <td style={{ fontWeight: "bold", color: "red" }}>{totalTAX.toFixed(2)}</td>
//             </tr>
//           </tfoot>
//         </Table>
//       </div>

//       {/* More Modal */}
//       <Modal show={moreModalOpen} onHide={() => setMoreModalOpen(false)}>
//         <Modal.Header closeButton>
//           <Modal.Title>Filter by Supplier</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>
//           <Form.Select value={selectedSupplier} onChange={(e) => setSelectedSupplier(e.target.value)}>
//             <option value="">All</option>
//             {uniqueSuppliers.map((vacode, index) => (
//               <option key={index} value={vacode}>{vacode}</option>
//             ))}
//           </Form.Select>
//         </Modal.Body>
//         <Modal.Footer>
//           <Button variant="secondary" onClick={() => setMoreModalOpen(false)}>Close</Button>
//         </Modal.Footer>
//       </Modal>
//     </div>
//   );
// };

// export default PurchaseBook;


import React, { useEffect, useState } from "react";
import { Table, Button, Form, Modal } from "react-bootstrap";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import * as XLSX from "xlsx";
import PurBookPrint from "./PurBookPrint";
import "./PurchaseBook.css";
import { CompanyContext } from "../../Context/CompanyContext";
import { useContext } from "react";

const PurchaseBook = () => {

  const { company } = useContext(CompanyContext);
  const tenant = company?.databaseName;

  if (!tenant) {
    // you may want to guard here or show an error state,
    // since without a tenant you can’t hit the right API
    console.error("No tenant selected!");
  }

  const [entries, setEntries] = useState([]);
  const [filteredEntries, setFilteredEntries] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [moreModalOpen, setMoreModalOpen] = useState(false);
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);
  const [showDateModal, setShowDateModal] = useState(true); // Open modal first
  const [selectedSupplier, setSelectedSupplier] = useState("");

  useEffect(() => {
    if (!fromDate || !toDate) return;

    const fetchEntries = async () => {
      setLoading(true);
      try {
        const response = await fetch(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/purchase`);
        if (!response.ok) throw new Error("Failed to fetch data");

        const data = await response.json();
        const filteredData = data.filter((entry) => {
          const entryDate = new Date(entry.formData?.date);
          return entryDate >= fromDate && entryDate <= toDate;
        });

        setEntries(data);
        setFilteredEntries(filteredData);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchEntries();
  }, [fromDate, toDate]);

  // Handle account filtering
  useEffect(() => {
    if (selectedSupplier) {
      setFilteredEntries(entries.filter(entry => entry.supplierdetails?.[0]?.vacode === selectedSupplier));
    } else {
      setFilteredEntries(entries);
    }
  }, [selectedSupplier, entries]);

  const handleDateSubmit = () => {
    if (fromDate && toDate) setShowDateModal(false);
  };

  const handleCloseModal = () => {
    setModalOpen(false);
  };

  const uniqueSuppliers = [...new Set(entries.map(entry => entry.supplierdetails?.[0]?.vacode))].filter(Boolean);

    // Calculate totals based on filtered data
  const totalGrandTotal = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.grandtotal || 0), 0);
  const totalCGST = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.cgst || 0), 0);
  const totalSGST = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.sgst || 0), 0);
  const totalIGST = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.igst || 0), 0);
  const totalTAX = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.tax || 0), 0);

  const exportToExcel = () => {
    const excelData = entries.map((entry) => {
      const formData = entry.formData || {};
      const supplierdetails = entry.supplierdetails?.[0] || {};
      const items = entry.items?.[0] || {};
      return [
        formData.date ? new Date(formData.date).toLocaleDateString("en-GB") : "",
        formData.vno || "",
        supplierdetails.vacode?.trim() || "",
        supplierdetails.city || "",
        supplierdetails.gstno || "",
        formData.grandtotal || "0",
        formData.tax || "0",
        formData.cgst || "0",
        formData.sgst || "0",
        formData.igst || "0",
        items.Exp1 || "0",
        items.Exp2 || "0",
        items.Exp3 || "0",
        items.Exp4 || "0",
        items.Exp5 || "0",
        items.Exp6 || "0",
        formData.Exp7 || "0",
        formData.Exp8 || "0",
        formData.Exp9 || "0",
        formData.Exp10 || "0",
        formData.Exp11 || "0",
        formData.Exp12 || "0",
        formData.sub_total || "0",
        formData.trpt || "",
        formData.v_tpt || "",
        formData.gr || "",
        formData.broker || "",
        formData.rem2 || "",
        formData.exfor || "",
        supplierdetails.state || "",
        supplierdetails.Add1 || "",
        supplierdetails.pan || "",
      ];
    });

    // Add header and title
    const header = [
      ["SHKUNSOFT INNOVATIONS"], // Title
      ["Date", "Bill No.", "Name", "City", "GSTIN", "Bill Amount", "Tax", "CGST", "SGST", "IGST", "Exp1", "Exp2", "Exp3", "Exp4", "Exp5", "Exp6", "Exp7", "Exp8", "Exp9", "Exp10", "Exp11", "Exp12", "NetValue", "VehicleNo", "Transporter", "GrNo", "Broker", "Rem", "Terms", "State", "Add", "Pan"], // Table headers
    ];

    // Combine title, header, and data
    const worksheetData = [...header, ...excelData];

    // Create worksheet
    const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);

    // Merge title cell across all columns
    XLSX.utils.sheet_add_aoa(worksheet, [["SHKUNSOFT INNOVATIONS"]], { origin: "A1" });
    worksheet["!merges"] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: 6 } }]; // Merge A1:G1

    // Create workbook and append worksheet
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Entries");

    // Export the workbook as an Excel file
    XLSX.writeFile(workbook, "PurBook.xlsx");
  };


  // Show modal until user selects a date range
  if (showDateModal) {
    return (
      <Modal show={true} backdrop="static" keyboard={false} centered>
        <Modal.Header>
          <Modal.Title>Select Date Range</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group>
              <Form.Label>From Date</Form.Label>
              <DatePicker
                selected={fromDate}
                onChange={(date) => setFromDate(date)}
                // selectsStart
                // startDate={fromDate}
                // endDate={toDate}
                dateFormat="dd/MM/yyyy"
                className="form-control"
              />
            </Form.Group>
            <Form.Group className="mt-3">
              <Form.Label>To Date</Form.Label>
              <DatePicker
                selected={toDate}
                onChange={(date) => setToDate(date)}
                // selectsEnd
                // startDate={fromDate}
                // endDate={toDate}
                // minDate={fromDate}
                dateFormat="dd/MM/yyyy"
                className="form-control"
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={handleDateSubmit} disabled={!fromDate || !toDate}>
            Show Data
          </Button>
        </Modal.Footer>
      </Modal>
    );
  }

  // Show loading only after user selects the dates
  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div>
      <h3 style={{ textAlign: "center" }}>PURCHASE BOOK</h3>

      <div style={{ display: "flex",flexDirection:"column", marginBottom: 10,marginTop:-40,marginLeft:10 }}>
      <div style={{ display: "flex",flexDirection:"row" }}>
        <text>Period From:</text>
        <DatePicker
          selected={fromDate}
          onChange={(date) => setFromDate(date)}
          // startDate={fromDate}
          // endDate={toDate}
          dateFormat="dd/MM/yyyy"
          className="DateFrom"
          placeholderText="From Date"
        />
        </div>
        <div style={{ display: "flex",flexDirection:"row",marginTop:5 }}>
        <text>UpTo:</text>
        <DatePicker
          selected={toDate}
          onChange={(date) => setToDate(date)}
          // startDate={fromDate}
          // endDate={toDate}
          // minDate={fromDate}
          dateFormat="dd/MM/yyyy"
          className="DateUpto"
          placeholderText="To Date"
          style={{ marginLeft: "40px" }}
        />
        </div>
      </div>
      <Button onClick={exportToExcel} variant="info" style={{ marginLeft: 10 }}>Export</Button>
      <Button onClick={() => setModalOpen(true)} variant="info" style={{ marginLeft: 10 }}>Print</Button>
      <Button onClick={() => setMoreModalOpen(true)} variant="info" style={{ marginLeft: 10 }}>More</Button>
      <div style={{ display: "none" }}>
          <PurBookPrint
          isOpen={modalOpen}
          handleClose={handleCloseModal}
          items={filteredEntries}
          shopName="SHKUNSOFT INNOVATIONS"
          description="Sales Book Table"
          GSTIN="Your GSTIN"
          PAN="Your PAN"
          address="Motia Khan"
        />
      </div>
         {/* More Modal */}
         <Modal show={moreModalOpen} onHide={() => setMoreModalOpen(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Filter by Supplier</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Select value={selectedSupplier} onChange={(e) => setSelectedSupplier(e.target.value)}>
            <option value="">All</option>
            {uniqueSuppliers.map((vacode, index) => (
              <option key={index} value={vacode}>{vacode}</option>
            ))}
          </Form.Select>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setMoreModalOpen(false)}>Close</Button>
        </Modal.Footer>
      </Modal>

      <div style={{ maxHeight: 460, overflowY: "auto",padding:5}}>
        <Table className="custom-table" bordered>
          <thead style={{ backgroundColor: "skyblue", position: "sticky", top: -6 }}>
            <tr>
              <th>Date</th>
              <th>Bill No.</th>
              <th>A/C Name</th>
              <th>City</th>
              <th>Value</th>
              <th>C.Tax</th>
              <th>S.Tax</th>
              <th>I.Tax</th>
              <th>Tax</th>
            </tr>
          </thead>
          <tbody>
            {filteredEntries.map((entry, index) => {
              const formData = entry.formData || {};
              const supplierdetails = entry.supplierdetails?.[0] || {};
              return (
                <tr key={index} style={{}}>
                  <td>{formData.date ? new Date(formData.date).toLocaleDateString("en-GB") : ""}</td>
                  <td>{formData.vno || ""}</td>
                  <td>{supplierdetails.vacode?.trim() || ""}</td>
                  <td>{supplierdetails.city || ""}</td>
                  <td>{formData.grandtotal || ""}</td>
                  <td>{formData.cgst || ""}</td>
                  <td>{formData.sgst || ""}</td>
                  <td>{formData.igst || ""}</td>
                  <td>{formData.tax || ""}</td>
                </tr>
              );
            })}
          </tbody>
          <tfoot style={{ backgroundColor: "skyblue", position: "sticky", bottom: -6 }}>
            <tr>
              <td colSpan="4" style={{ fontWeight: "bold" }}>TOTAL</td>
              <td style={{ fontWeight: "bold", color: "red" }}>{totalGrandTotal.toFixed(2)}</td>
              <td style={{ fontWeight: "bold", color: "red" }}>{totalCGST.toFixed(2)}</td>
              <td style={{ fontWeight: "bold", color: "red" }}>{totalSGST.toFixed(2)}</td>
              <td style={{ fontWeight: "bold", color: "red" }}>{totalIGST.toFixed(2)}</td>
              <td style={{ fontWeight: "bold", color: "red" }}>{totalTAX.toFixed(2)}</td>
            </tr>
          </tfoot>
        </Table>
      </div>
    </div>
  );
};

export default PurchaseBook;
