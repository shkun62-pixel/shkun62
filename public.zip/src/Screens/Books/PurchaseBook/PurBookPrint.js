// import React, { useRef, useEffect, useState } from 'react';
// import { useReactToPrint } from 'react-to-print';
// import { Modal, Box, Button } from '@mui/material';
// import CloseIcon from '@mui/icons-material/Close';

// const PurBookPrint = React.forwardRef(({
//     formData,
//     items,
//     supplierdetails,
//     shipped,
//     isOpen, // Changed from 'open' to 'isOpen'
//     handleClose,
//     GSTIN,
//     PAN,
//     shopName,
//     description,
//     address
//   }, ref) => {
//     const chunkItems = (items, firstChunkSize, otherChunkSize) => {
//       const chunks = [];
//       let i = 0;
//       // Handle the first chunk with a specific size
//       if (items.length > 0) {
//         chunks.push(items.slice(i, i + firstChunkSize));
//         i += firstChunkSize;
//       }
//       // Handle all other chunks with a different size
//       while (i < items.length) {
//         chunks.push(items.slice(i, i + otherChunkSize));
//         i += otherChunkSize;
//       }
//       return chunks;
//     };
//     // Split items into chunks of 10
//     const chunks = chunkItems(items, 10, 20);

//     const [totalQuantity, setTotalQuantity] = useState(0);
//     // Function to calculate total quantity
//     const calculateTotalQuantity = () => {
//       const total = items.reduce((accumulator, currentItem) => {
//         return accumulator + Number(currentItem.weight);
//       }, 0);
//       setTotalQuantity(total);
//     };
//     useEffect(() => {
//       calculateTotalQuantity();
//     }, [items]);

//     const style = {
//       bgcolor: "white",
//       boxShadow: 24,
//       p: 4,
//       overflowY: "auto",
//     };

//     const componentRef = useRef();
//     const handlePrint = useReactToPrint({
//       content: () => componentRef.current,
//     });

//     return (
//       <Modal
//         open={isOpen}
//         style={{ overflow: "auto" }}
//         onClose={handleClose}
//         aria-labelledby="modal-modal-title"
//         aria-describedby="modal-modal-description"
//       >
//         <Box sx={style}>
//           <button className="close-button" onClick={handleClose}>
//             <CloseIcon />
//           </button>
//           <Button
//             className="Button"
//             style={{ color: "black", backgroundColor: "lightcoral" }}
//             onClick={handlePrint}
//           >
//             Print
//           </Button>
//           {/* <text style={{ fontWeight: "bold", fontSize: 30, marginLeft: "32%" }}>
//             This Is The Preview of Bill
//           </text> */}
//          <div
//   ref={componentRef}
//   style={{
//     width: "390mm",
//     minHeight: "390mm",
//     margin: "auto",
//     padding: "20px",
//     borderRadius: "5px",
//     boxSizing: "border-box",
//   }}
// >
//   <h3 style={{ textAlign: "center" }}>{shopName}</h3>
//   <h3 style={{ textAlign: "center" }}>{address}</h3>
//   <h3 style={{ textAlign: "center" }}>Mandi Gobindagarh</h3>
//   <table
//     style={{
//       width: "100%",
//       borderCollapse: "collapse",
//       border: "1px solid #000",
//       marginTop: "20px",
//     }}
//   >
//     <thead style={{ backgroundColor: "lightgrey" }}>
//       <tr>
//         <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center"}}>Date</th>
//         <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>Bill No.</th>
//         <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>A/C Name</th>
//         <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>City</th>
//         <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>Bags</th>
//         <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>Weight</th>
//         <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>Bill Amount</th>
//         <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>VAT</th>
//         <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>CST</th>
//         <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>Freight</th>
//         <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>Expenses</th>
//         <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>NetSale</th>
//       </tr>
//     </thead>
//     <tbody>
//       {items.map((entry, index) => (
//         <tr key={index}>
//           <td style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>
//             {entry.formData.date || ""}
//           </td>
//           <td style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>
//             {entry.formData.vbillno || ""}
//           </td>
//           <td style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>
//             {entry.supplierdetails?.[0]?.vacode?.trim() || ""}
//           </td>
//           <td style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>
//             {entry.supplierdetails?.[0]?.city || ""}
//           </td>
//           <td style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>
//             {entry.formData.bags || "0"}
//           </td>
//           <td style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>
//             {entry.formData.weight || "0"}
//           </td>
//           <td style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>
//             {entry.formData.grandtotal || "0"}
//           </td>
//           <td style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>
//             {entry.formData.vat || "0"}
//           </td>
//           <td style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>
//             {entry.formData.cst || "0"}
//           </td>
//           <td style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>
//             {entry.formData.freight || "0"}
//           </td>
//           <td style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>
//             {entry.formData.expafterGST || "0"}
//           </td>
//           <td style={{ border: "1px solid #000", padding: "8px", textAlign: "center" }}>
//             {entry.formData.sub_total || "0"}
//           </td>
//         </tr>
//       ))}
//     </tbody>
//   </table>
// </div>
//         </Box>
//       </Modal>
//     );
//   });
//   export default PurBookPrint;

import React, { useRef, useEffect, useState } from 'react';
import { useReactToPrint } from 'react-to-print';
import { Modal, Box, Button } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

const PurBookPrint = React.forwardRef(({
  formData,
  items,
  supplierdetails,
  isOpen,
  handleClose,
  GSTIN,
  PAN,
  shopName,
  address,
}, ref) => {
  const [totals, setTotals] = useState({
    subTotal: 0,
    tax: 0,
    expAfterGST: 0,
    grandTotal: 0
  });

  useEffect(() => {
    const calculateTotals = () => {
      let subTotal = 0, tax = 0, expAfterGST = 0, grandTotal = 0;

      items.forEach(entry => {
        subTotal += Number(entry.formData.sub_total || 0);
        tax += Number(entry.formData.tax || 0);
        expAfterGST += Number(entry.formData.expafterGST || 0);
        grandTotal += Number(entry.formData.grandtotal || 0);
      });

      setTotals({ subTotal, tax, expAfterGST, grandTotal });
    };

    calculateTotals();
  }, [items]);

  const style = {
    bgcolor: "white",
    boxShadow: 24,
    p: 4,
    overflowY: "auto",
  };

  const componentRef = useRef();
  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });

  return (
    <Modal
      open={isOpen}
      style={{ overflow: "auto" }}
      onClose={handleClose}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box sx={style}>
        <button className="close-button" onClick={handleClose}>
          <CloseIcon />
        </button>
        <Button
          className="Button"
          style={{ color: "black", backgroundColor: "lightcoral" }}
          onClick={handlePrint}
        >
          Print
        </Button>

        <div
          ref={componentRef}
          style={{
            width: "390mm",
            minHeight: "390mm",
            margin: "auto",
            padding: "20px",
            borderRadius: "5px",
            boxSizing: "border-box",
            overflow:"auto"
          }}
        >
          <h2 style={{ textAlign: "center", marginTop: -5 }}>{shopName}</h2>
          <h2 style={{ textAlign: "center" }}>{address}</h2>
          <h2 style={{ textAlign: "center" }}>Mandi Gobindagarh</h2>
          <h4 style={{ textAlign: "center", textDecoration: 'underline' }}>Purchase Book</h4>
          <table
            style={{
              width: "100%",
              borderCollapse: "collapse",
              border: "1px solid #000",
              marginTop: "20px",
            }}
          >
            <thead style={{ backgroundColor: "lightgrey" }}>
              <tr>
                <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center", fontSize: 25 }}>Date</th>
                <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center", fontSize: 25 }}>Bill No.</th>
                <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center", fontSize: 25 }}>A/C Name</th>
                <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center", fontSize: 25 }}>City</th>
                <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center", fontSize: 25 }}>NetSale</th>
                <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center", fontSize: 25 }}>Tax</th>
                <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center", fontSize: 25 }}>Expenses</th>
                <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center", fontSize: 25 }}>Bill Amount</th>
              </tr>
            </thead>
            <tbody>
              {items.map((entry, index) => (
                <tr key={index}>
                  <td style={{ border: "1px solid #000", padding: "8px", fontSize: 25 }}>
                    {entry.formData.date ? new Date(entry.formData.date).toLocaleDateString("en-GB") : ""}
                  </td>
                  <td style={{ border: "1px solid #000", padding: "8px", fontSize: 25 }}>
                    {entry.formData.vno || ""}
                  </td>
                  <td style={{ border: "1px solid #000", padding: "8px", fontSize: 25 }}>
                    {entry.supplierdetails?.[0]?.vacode?.trim() || ""}
                  </td>
                  <td style={{ border: "1px solid #000", padding: "8px", fontSize: 25 }}>
                    {entry.supplierdetails?.[0]?.city || ""}
                  </td>
                  <td style={{ border: "1px solid #000", padding: "8px", textAlign: "right", fontSize: 25 }}>
                    {entry.formData.sub_total || "0"}
                  </td>
                  <td style={{ border: "1px solid #000", padding: "8px", textAlign: "right", fontSize: 25 }}>
                    {entry.formData.tax || ""}
                  </td>
                  <td style={{ border: "1px solid #000", padding: "8px", textAlign: "right", fontSize: 25 }}>
                    {entry.formData.expafterGST || "0"}
                  </td>
                  <td style={{ border: "1px solid #000", padding: "8px", textAlign: "right", fontSize: 25 }}>
                    {entry.formData.grandtotal || "0"}
                  </td>
                </tr>
              ))}
              {/* Total Row */}
              <tr style={{ backgroundColor: "lightgrey", fontWeight: "bold" }}>
                <td colSpan={4} style={{ border: "1px solid #000", padding: "8px", textAlign: "center", fontSize: 25 }}>Total</td>
                <td style={{ border: "1px solid #000", padding: "8px", textAlign: "right", fontSize: 25 }}>{totals.subTotal.toFixed(2)}</td>
                <td style={{ border: "1px solid #000", padding: "8px", textAlign: "right", fontSize: 25 }}>{totals.tax.toFixed(2)}</td>
                <td style={{ border: "1px solid #000", padding: "8px", textAlign: "right", fontSize: 25 }}>{totals.expAfterGST.toFixed(2)}</td>
                <td style={{ border: "1px solid #000", padding: "8px", textAlign: "right", fontSize: 25 }}>{totals.grandTotal.toFixed(2)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </Box>
    </Modal>
  );
});

export default PurBookPrint;
