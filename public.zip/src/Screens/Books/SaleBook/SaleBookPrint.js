import React, { useRef, useEffect, useState } from 'react';
import { useReactToPrint } from 'react-to-print';
import { Modal, Box, Button } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

const SaleBookPrint = React.forwardRef(({
    formData,
    items,
    customerDetails,
    shipped,
    isOpen, // Changed from 'open' to 'isOpen'
    handleClose,
    GSTIN,
    PAN,
    shopName,
    address
  }, ref) => {
    const chunkItems = (items, firstChunkSize, otherChunkSize) => {
      const chunks = [];
      let i = 0;
      // Handle the first chunk with a specific size
      if (items.length > 0) {
        chunks.push(items.slice(i, i + firstChunkSize));
        i += firstChunkSize;
      }
      // Handle all other chunks with a different size
      while (i < items.length) {
        chunks.push(items.slice(i, i + otherChunkSize));
        i += otherChunkSize;
      }
      return chunks;
    };
    // Split items into chunks of 10
    const chunks = chunkItems(items, 10, 20);

    const [totalQuantity, setTotalQuantity] = useState(0);
    // Function to calculate total quantity
    const calculateTotalQuantity = () => {
      const total = items.reduce((accumulator, currentItem) => {
        return accumulator + Number(currentItem.weight);
      }, 0);
      setTotalQuantity(total);
    };
    useEffect(() => {
      calculateTotalQuantity();
    }, [items]);

    const style = {
      bgcolor: "white",
      boxShadow: 24,
      p: 4,
      overflowY: "auto",
    };

    const componentRef = useRef();
    const handlePrint = useReactToPrint({
      content: () => componentRef.current,
    });

    return (
      <Modal
        open={isOpen}
        style={{ overflow: "auto" }}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <button className="close-button" onClick={handleClose}>
            <CloseIcon />
          </button>
          <Button
            className="Button"
            style={{ color: "black", backgroundColor: "lightcoral" }}
            onClick={handlePrint}
          >
            Print
          </Button>
          {/* <text style={{ fontWeight: "bold", fontSize: 30, marginLeft: "32%" }}>
            This Is The Preview of Bill
          </text> */}
         <div
  ref={componentRef}
  style={{
    width: "390mm",
    minHeight: "390mm",
    margin: "auto",
    padding: "20px",
    borderRadius: "5px",
    boxSizing: "border-box",
  }}
>
  <h2 style={{ textAlign: "center",marginTop:-5}}>{shopName}</h2>
  <h2 style={{ textAlign: "center" }}>{address}</h2>
  <h2 style={{ textAlign: "center" }}>Mandi Gobindagarh</h2>
  <h4 style={{ textAlign:"center",textDecoration:'underline'}}>Sale Book</h4>
  <table
    style={{
      width: "100%",
      borderCollapse: "collapse",
      border: "1px solid #000",
      marginTop: "20px",
      marginLeft:-20
    }}
  >
    <thead style={{ backgroundColor: "lightgrey" }}>
      <tr>
        <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center",fontSize:25}}>Date</th>
        <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center",fontSize:25 }}>Bill No.</th>
        <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center",fontSize:25 }}>A/C Name</th>
        <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center",fontSize:25 }}>City</th>
        <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center",fontSize:25 }}>NetSale</th>
        <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center" ,fontSize:25}}>Tax</th>
        <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center",fontSize:25 }}>Expenses</th>
        <th style={{ border: "1px solid #000", padding: "8px", textAlign: "center" ,fontSize:25}}>Bill Amount</th>
      </tr>
    </thead>
    <tbody>
      {items.map((entry, index) => (
        <tr key={index}>
         <td style={{ border: "1px solid #000", padding: "8px", fontSize: 25 }}>
  {entry.formData.date ? new Date(entry.formData.date).toLocaleDateString("en-GB") : ""}
</td>

          <td style={{ border: "1px solid #000", padding: "8px",fontSize:25 }}>
            {entry.formData.vbillno || ""}
          </td>
          <td style={{ border: "1px solid #000", padding: "8px" ,fontSize:25}}>
            {entry.customerDetails?.[0]?.vacode?.trim() || ""}
          </td>
          <td style={{ border: "1px solid #000", padding: "8px",fontSize:25 }}>
            {entry.customerDetails?.[0]?.city || ""}
          </td>
          <td style={{ border: "1px solid #000", padding: "8px", textAlign: "right", fontSize:25 }}>
            {entry.formData.sub_total || "0"}
          </td>
          <td style={{ border: "1px solid #000", padding: "8px", textAlign: "right",fontSize:25 }}>
            {entry.formData.tax || ""}
          </td>
          <td style={{ border: "1px solid #000", padding: "8px", textAlign: "right",fontSize:25 }}>
            {entry.formData.expafterGST || "0"}
          </td>
          <td style={{ border: "1px solid #000", padding: "8px", textAlign: "right",fontSize:25 }}>
            {entry.formData.grandtotal || "0"}
          </td>
        </tr>
      ))}
    </tbody>
  </table>
</div>
        </Box>
      </Modal>
    );
  });
  export default SaleBookPrint;
