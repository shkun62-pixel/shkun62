// import React, { useEffect, useState } from "react";
// import { Table, Button } from "react-bootstrap";
// import * as XLSX from "xlsx";
// import SaleBookPrint from "./SaleBookPrint";

// const SaleBook = () => {
//   const [entries, setEntries] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const [modalOpen, setModalOpen] = useState(false); // State for modal visibility

//   // Fetch data from API
//   useEffect(() => {
//     const fetchEntries = async () => {
//       try {
//         const response = await fetch("http://103.154.233.29:3007/auth/api/sale"); // Replace with your API endpoint
//         if (!response.ok) {
//           throw new Error("Failed to fetch data");
//         }
//         const data = await response.json();
//         setEntries(data);
//       } catch (err) {
//         setError(err.message);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchEntries();
//   }, []);

//   // Export to Excel
//   const exportToExcel = () => {
//     const excelData = entries.map((entry) => {
//       const formData = entry.formData || {};
//       const customerDetails = entry.customerDetails?.[0] || {};
//       const supplierDetails = entry.shipped?.[0] || {};
//       const items = entry.items?.[0] || {};
//       return [
//         formData.date || "",
//         formData.vbillno || "",
//         customerDetails.vacode?.trim() || "",
//         customerDetails.city || "",
//         customerDetails.gstno || "",
//         formData.grandtotal || "0",
//         formData.tax || "0",
//         formData.cgst || "0",
//         formData.sgst || "0",
//         formData.igst || "0",
//         items.Exp1 || "0",
//         items.Exp2 || "0",
//         items.Exp3 || "0",
//         items.Exp4 || "0",
//         items.Exp5 || "0",
//         items.Exp6 || "0",
//         formData.Exp7 || "0",
//         formData.Exp8 || "0",
//         formData.Exp9 || "0",
//         formData.Exp10 || "0",
//         formData.Exp11 || "0",
//         formData.Exp12 || "0",
//         formData.sub_total || "0",
//         formData.trpt || "",
//         formData.v_tpt || "",
//         formData.gr || "",
//         formData.broker || "",
//         formData.rem2 || "",
//         formData.exfor || "",
//         customerDetails.state || "",
//         customerDetails.Add1 || "",
//         customerDetails.pan || "",
//       ];
//     });

//     // Add header and title
//     const header = [
//       ["SHKUNSOFT INNOVATIONS"], // Title
//       ["Date", "Bill No.", "Name", "City", "GSTIN", "Bill Amount", "Tax", "CGST", "SGST", "IGST", "Exp1", "Exp2", "Exp3", "Exp4", "Exp5", "Exp6", "Exp7", "Exp8", "Exp9", "Exp10", "Exp11", "Exp12", "NetValue", "VehicleNo", "Transporter", "GrNo", "Broker", "Rem", "Terms", "State", "Add", "Pan"], // Table headers
//     ];

//     // Combine title, header, and data
//     const worksheetData = [...header, ...excelData];

//     // Create worksheet
//     const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);

//     // Merge title cell across all columns
//     XLSX.utils.sheet_add_aoa(worksheet, [["SHKUNSOFT INNOVATIONS"]], { origin: "A1" });
//     worksheet["!merges"] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: 6 } }]; // Merge A1:G1

//     // Create workbook and append worksheet
//     const workbook = XLSX.utils.book_new();
//     XLSX.utils.book_append_sheet(workbook, worksheet, "Entries");

//     // Export the workbook as an Excel file
//     XLSX.writeFile(workbook, "SaleBook.xlsx");
//   };

//   // Render loading, error, or table
//   if (loading) return <p>Loading...</p>;
//   if (error) return <p>Error: {error}</p>;
// // Function to handle modal open
// const handleOpenModal = (entry) => {
//     setModalOpen(true);
//   };

//   // Function to close modal
//   const handleCloseModal = () => {
//     setModalOpen(false);
//   };

  
//   // Calculate total of grandtotal
//   const totalGrandTotal = entries.reduce((acc, entry) => {
//     const formData = entry.formData || {};
//     return acc + parseFloat(formData.grandtotal || 0);
//   }, 0);

//     // Calculate total of CGST
//     const totalCGST = entries.reduce((acc, entry) => {
//         const formData = entry.formData || {};
//         return acc + parseFloat(formData.cgst || 0);
//       }, 0);
//        // Calculate total of SGST
//     const totalSGST = entries.reduce((acc, entry) => {
//         const formData = entry.formData || {};
//         return acc + parseFloat(formData.sgst || 0);
//       }, 0);
//        // Calculate total of IGST
//     const totalIGST = entries.reduce((acc, entry) => {
//         const formData = entry.formData || {};
//         return acc + parseFloat(formData.igst || 0);
//       }, 0);
//        // Calculate total of IGST
//     const totalTAX = entries.reduce((acc, entry) => {
//         const formData = entry.formData || {};
//         return acc + parseFloat(formData.tax || 0);
//       }, 0);
//   return (
//     <div>
//       <h2>SALE BOOK</h2>
//       <Button onClick={exportToExcel} variant="success" style={{ }}>
//         Export to Excel
//       </Button>
//      <Button style={{marginLeft:10}} variant="info" onClick={() => handleOpenModal()}>
//                         Print
//                       </Button>
//       <div style={{maxHeight:540,overflowY:"auto",margin:5}}>
//       <Table className="custom-table" bordered>
//         <thead style={{ backgroundColor: "skyblue", position: "sticky", top: 0,}}>
//           <tr>
//             <th>Date</th>
//             <th>Bill No.</th>
//             <th>A/C Name</th>
//             <th>City</th>
//             <th>Value</th>
//             <th>C.Tax</th>
//             <th>S.Tax</th>
//             <th>I.Tax</th>
//             <th>Tax</th>
//           </tr>
//         </thead>
//         <tbody>
//           {entries.map((entry, index) => {
//             const formData = entry.formData || {};
//             const customerDetails = entry.customerDetails?.[0] || {};
//             const supplierDetails = entry.shipped?.[0] || {};
//             return (
//               <tr key={index}>
//                 <td>{formData.date || ""}</td>
//                 <td>{formData.vbillno || ""}</td>
//                 <td>{customerDetails.vacode?.trim() || ""}</td>
//                 <td>{customerDetails.city || ""}</td>
//                 <td>{formData.grandtotal || ""}</td>
//                 <td>{formData.cgst || ""}</td>
//                 <td>{formData.sgst || ""}</td>
//                 <td>{formData.igst || ""}</td>
//                 <td>{formData.tax || ""}</td>
//               </tr>
//             );
//           })}
//         </tbody>
//         <tfoot>
//             <tr>
//                 <td></td>
//                 <td></td>
//                 <td></td>
//                 <td style={{fontWeight:'bold'}}>TOTAL</td>
//                 <td style={{fontWeight:'bold',color:'red'}}>{totalGrandTotal.toFixed(2)}</td>
//                 <td style={{fontWeight:'bold',color:'red'}}>{totalCGST.toFixed(2)}</td>
//                 <td style={{fontWeight:'bold',color:'red'}}>{totalSGST.toFixed(2)}</td>
//                 <td style={{fontWeight:'bold',color:'red'}}>{totalIGST.toFixed(2)}</td>
//                 <td style={{fontWeight:'bold',color:'red'}}>{totalTAX.toFixed(2)}</td>
//             </tr>
//         </tfoot>
//       </Table>
//       </div>
//       <div style={{ display: "none" }}>
//         <SaleBookPrint
//           // ref={invoiceRef}
//           formData={{}}
//           items={entries}
//           customerDetails={[]}
//           shipped={false}
//           isOpen={modalOpen}
//           handleClose={handleCloseModal}
//           shopName="SHKUNSOFT INNOVATIONS"
//           description="Sales Book Table"
//           GSTIN="Your GSTIN"
//           PAN="Your PAN"
//           address="Motia Khan"
//         />
//       </div>
//     </div>
//   );
// };

// export default SaleBook;

import React, { useEffect, useState } from "react";
import { Table, Button, Form } from "react-bootstrap";
import * as XLSX from "xlsx";
import SaleBookPrint from "./SaleBookPrint";
import { CompanyContext } from "../../Context/CompanyContext";
import { useContext } from "react";

const SaleBook = () => {

  const { company } = useContext(CompanyContext);
  const tenant = company?.databaseName;

  if (!tenant) {
    // you may want to guard here or show an error state,
    // since without a tenant you can’t hit the right API
    console.error("No tenant selected!");
  }

  const [entries, setEntries] = useState([]);
  const [filteredEntries, setFilteredEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  useEffect(() => {
    const fetchEntries = async () => {
      try {
        const response = await fetch(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/sale`);
        if (!response.ok) {
          throw new Error("Failed to fetch data");
        }
        const data = await response.json();
        setEntries(data);
        setFilteredEntries(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchEntries();
  }, []);

  useEffect(() => {
    if (!fromDate || !toDate) {
      setFilteredEntries(entries);
      return;
    }

    const filtered = entries.filter((entry) => {
      const entryDate = new Date(entry.formData?.date);
      return entryDate >= new Date(fromDate) && entryDate <= new Date(toDate);
    });
    setFilteredEntries(filtered);
  }, [fromDate, toDate, entries]);

  const totalGrandTotal = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.grandtotal || 0), 0);
  const totalCGST = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.cgst || 0), 0);
  const totalSGST = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.sgst || 0), 0);
  const totalIGST = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.igst || 0), 0);
  const totalTAX = filteredEntries.reduce((acc, entry) => acc + parseFloat(entry.formData?.tax || 0), 0);

  const exportToExcel = () => {
    const excelData = entries.map((entry) => {
      const formData = entry.formData || {};
      const customerDetails = entry.customerDetails?.[0] || {};
      const supplierDetails = entry.shipped?.[0] || {};
      const items = entry.items?.[0] || {};
      return [
        formData.date || "",
        formData.vbillno || "",
        customerDetails.vacode?.trim() || "",
        customerDetails.city || "",
        customerDetails.gstno || "",
        formData.grandtotal || "0",
        formData.tax || "0",
        formData.cgst || "0",
        formData.sgst || "0",
        formData.igst || "0",
        items.Exp1 || "0",
        items.Exp2 || "0",
        items.Exp3 || "0",
        items.Exp4 || "0",
        items.Exp5 || "0",
        items.Exp6 || "0",
        formData.Exp7 || "0",
        formData.Exp8 || "0",
        formData.Exp9 || "0",
        formData.Exp10 || "0",
        formData.Exp11 || "0",
        formData.Exp12 || "0",
        formData.sub_total || "0",
        formData.trpt || "",
        formData.v_tpt || "",
        formData.gr || "",
        formData.broker || "",
        formData.rem2 || "",
        formData.exfor || "",
        customerDetails.state || "",
        customerDetails.Add1 || "",
        customerDetails.pan || "",
      ];
    });

    // Add header and title
    const header = [
      ["SHKUNSOFT INNOVATIONS"], // Title
      ["Date", "Bill No.", "Name", "City", "GSTIN", "Bill Amount", "Tax", "CGST", "SGST", "IGST", "Exp1", "Exp2", "Exp3", "Exp4", "Exp5", "Exp6", "Exp7", "Exp8", "Exp9", "Exp10", "Exp11", "Exp12", "NetValue", "VehicleNo", "Transporter", "GrNo", "Broker", "Rem", "Terms", "State", "Add", "Pan"], // Table headers
    ];

    // Combine title, header, and data
    const worksheetData = [...header, ...excelData];

    // Create worksheet
    const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);

    // Merge title cell across all columns
    XLSX.utils.sheet_add_aoa(worksheet, [["SHKUNSOFT INNOVATIONS"]], { origin: "A1" });
    worksheet["!merges"] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: 6 } }]; // Merge A1:G1

    // Create workbook and append worksheet
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Entries");

    // Export the workbook as an Excel file
    XLSX.writeFile(workbook, "SaleBook.xlsx");
  };

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div>
     <h3 style={{ textAlign: "center" }}>SALE BOOK</h3>
      <div style={{ display: "flex", justifyContent: "center", marginBottom: 10 }}>
        <Form.Control type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} style={{ width: "200px", marginRight: "10px" }} />
        <Form.Control type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} style={{ width: "200px", marginRight: "10px" }} />
      </div>
      <Button style={{ marginLeft: 10 }} variant="info" onClick={() => setModalOpen(true)}>
        Print
      </Button>
      <Button style={{ marginLeft: 10 }} variant="info" onClick={() => exportToExcel()}>
        Export
      </Button>
      <div style={{ maxHeight: 540, overflowY: "auto", margin: 5 }}>
        <Table className="custom-table" bordered>
          <thead style={{ backgroundColor: "skyblue", position: "sticky", top: 0 }}>
            <tr>
              <th>Date</th>
              <th>Bill No.</th>
              <th>A/C Name</th>
              <th>City</th>
              <th>Value</th>
              <th>C.Tax</th>
              <th>S.Tax</th>
              <th>I.Tax</th>
              <th>Tax</th>
            </tr>
          </thead>
          <tbody>
            {filteredEntries.map((entry, index) => {
              const formData = entry.formData || {};
              const customerDetails = entry.customerDetails?.[0] || {};
              return (
                <tr key={index}>
                  <td>{formData.date ? new Date(formData.date).toLocaleDateString("en-GB") : ""}</td>
                  <td>{formData.vbillno || ""}</td>
                  <td>{customerDetails.vacode?.trim() || ""}</td>
                  <td>{customerDetails.city || ""}</td>
                  <td>{formData.grandtotal || ""}</td>
                  <td>{formData.cgst || ""}</td>
                  <td>{formData.sgst || ""}</td>
                  <td>{formData.igst || ""}</td>
                  <td>{formData.tax || ""}</td>
                </tr>
              );
            })}
          </tbody>
          <tfoot>
            <tr>
              <td colSpan="4" style={{ fontWeight: "bold" }}>TOTAL</td>
              <td style={{ fontWeight: "bold", color: "red" }}>{totalGrandTotal.toFixed(2)}</td>
              <td style={{ fontWeight: "bold", color: "red" }}>{totalCGST.toFixed(2)}</td>
              <td style={{ fontWeight: "bold", color: "red" }}>{totalSGST.toFixed(2)}</td>
              <td style={{ fontWeight: "bold", color: "red" }}>{totalIGST.toFixed(2)}</td>
              <td style={{ fontWeight: "bold", color: "red" }}>{totalTAX.toFixed(2)}</td>
            </tr>
          </tfoot>
        </Table>
      </div>
      <div style={{ display: "none" }}>
        <SaleBookPrint isOpen={modalOpen} handleClose={() => setModalOpen(false)} items={filteredEntries} shopName="SHKUNSOFT INNOVATIONS" description="Sales Book Table" GSTIN="Your GSTIN" PAN="Your PAN" address="Motia Khan" />
      </div>
    </div>
  );
};

export default SaleBook;
