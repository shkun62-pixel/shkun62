import React, { useRef } from "react";
import { Modal, Box, Button, Table, TableContainer, Paper } from "@mui/material";
import { useReactToPrint } from "react-to-print";

const PrintModal = ({ isOpen, handleClose, filteredData,splitByDate  }) => {
  const componentRef = useRef();

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });

  // Helper function to format date to dd/mm/yyyy
  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-GB"); // 'en-GB' formats to dd/mm/yyyy
  };

  return (
    <Modal open={isOpen} onClose={handleClose}>
      <Box
        sx={{
          bgcolor: "white",
          p: 4,
          width: "90%",
          margin: "auto",
          mt: 5,
          overflowY: "auto",
          maxHeight: "80vh",
        }}
      >
        <Button variant="contained" color="primary" onClick={handlePrint}>
          Print
        </Button>
        <Button variant="contained" color="secondary" onClick={handleClose} style={{ marginLeft: 10 }}>
          Close
        </Button>

        {/* Printable Area */}
        <div ref={componentRef} style={{ padding: 28,marginLeft:-5 }}>
          {/* Print-Specific Styles */}
          <style>
            {`
            @media print {
  * {
    -webkit-print-color-adjust: exact;
  }

  body {
    margin: 0;
    padding: 0;
  }

  div.page-break {
    page-break-before: always;
    padding-top: 20px; /* This adds space after page break */
  }

  div.page-break:first-of-type {
    page-break-before: auto;
  }

  /* Add safe margin to avoid cutting at top */
  .print-page-inner {
    margin-top: 20px;
  }

  table {
    page-break-inside: auto;
  }

  tr {
    page-break-inside: avoid;
    page-break-after: auto;
  }
}

            `}
          </style>

          {/* Print Header Once If Not Splitting Pages */}
{!splitByDate && (
  <>
    <h4 style={{ textAlign: "center",marginTop:10 }}>SHADOW PVT LTD.</h4>
    <h4 style={{ textAlign: "center" }}>Tower-II, Floor No.2</h4>
    <h4 style={{ textAlign: "center" }}>Mandi Gobindgarh</h4>
  </>
)}

          {Object.keys(filteredData).map((date, idx) => {
            const { receipts, payments } = filteredData[date];
            const receiptTotal = receipts.reduce((sum, item) => sum + parseFloat(item.receipt_credit || 0), 0);
            const paymentTotal = payments.reduce((sum, item) => sum + parseFloat(item.payment_debit || 0), 0);

            const showReceipts = receipts.length > 0 && receiptTotal > 0;
            const showPayments = payments.length > 0 && paymentTotal > 0;

            return (
              <div key={idx} style={{ marginBottom: 30, border: "1px solid black", padding: 10,marginTop:20 }}  className={splitByDate ? "page-break" : "no-break"}>
             {/* Conditionally include header per page if split is on */}
      {splitByDate && (
        <>
          <h4 style={{ textAlign: "center" }}>SHADOW PVT LTD.</h4>
          <h4 style={{ textAlign: "center" }}>Tower-II, Floor No.2</h4>
          <h4 style={{ textAlign: "center" }}>Mandi Gobindgarh</h4>
        </>
      )}
      <h4 style={{ textAlign: "center", textDecoration: "underline" }}>Date: {formatDate(date)}</h4>
                <div style={{ display: "flex", justifyContent: "center", gap: 10 }}>
                  {/* Receipts Table */}
                  {showReceipts && (
                    <TableContainer component={Paper} style={{ width: showPayments ? "50%" : "100%" }}>
                      <h4 style={{ textAlign: "center" }}>Receipts</h4>
                      <Table>
                        <thead>
                          <tr style={{ backgroundColor: "lightgrey" }}>
                            <th style={styles.tableHeader}>Account Name</th>
                            <th style={styles.tableHeader}>Narration</th>
                            <th style={styles.tableHeader}>Receipts</th>
                          </tr>
                        </thead>
                        <tbody>
                          {receipts.map((item, idx) => (
                            <tr key={idx}>
                              <td style={styles.tableCell}>{item.accountname}</td>
                              <td style={styles.tableCell}>{item.narration}</td>
                              <td style={{ ...styles.tableCell, textAlign: "right" }}>{item.receipt_credit}</td>
                            </tr>
                          ))}
                          <tr style={{ fontWeight: "bold" }}>
                            <td style={styles.subTotalCell}>Sub Total</td>
                            <td style={styles.subTotalCell}></td>
                            <td style={{ ...styles.subTotalCell, textAlign: "right" }}>{receiptTotal.toFixed(2)}</td>
                          </tr>
                        </tbody>
                      </Table>
                    </TableContainer>
                  )}

                  {/* Payments Table */}
                  {showPayments && (
                    <TableContainer component={Paper} style={{ width: showReceipts ? "50%" : "100%" }}>
                      <h4 style={{ textAlign: "center" }}>Payments</h4>
                      <Table>
                        <thead>
                          <tr style={{ backgroundColor: "lightgrey" }}>
                            <th style={styles.tableHeader}>Account Name</th>
                            <th style={styles.tableHeader}>Narration</th>
                            <th style={styles.tableHeader}>Payments</th>
                          </tr>
                        </thead>
                        <tbody>
                          {payments.map((item, idx) => (
                            <tr key={idx}>
                              <td style={styles.tableCell}>{item.accountname}</td>
                              <td style={styles.tableCell}>{item.narration}</td>
                              <td style={{ ...styles.tableCell, textAlign: "right" }}>{item.payment_debit}</td>
                            </tr>
                          ))}
                          <tr style={{ fontWeight: "bold" }}>
                            <td style={styles.subTotalCell}>Sub Total</td>
                            <td style={styles.subTotalCell}></td>
                            <td style={{ ...styles.subTotalCell, textAlign: "right" }}>{paymentTotal.toFixed(2)}</td>
                          </tr>
                        </tbody>
                      </Table>
                    </TableContainer>
                  )}
                </div>

                {/* Cash in Hand Display */}
                <div style={{ textAlign: "right", fontWeight: "bold", marginTop: 10 }}>
                  Cash in Hand: {(receiptTotal - paymentTotal).toFixed(2)}
                </div>
              </div>
            );
          })}
        </div>
      </Box>
    </Modal>
  );
};

// Styles for table elements
const styles = {
  tableHeader: {
    border: "1px solid black",
    padding: "8px",
    textAlign: "center",
    fontWeight: "bold",
  },
  tableCell: {
    border: "1px solid black",
    padding: "8px",
    textAlign: "left",
  },
  subTotalCell: {
    border: "1px solid black",
    padding: "8px",
    fontWeight: "bold",
    backgroundColor: "#f0f0f0",
  },
};

export default PrintModal;

// import React, { useRef } from "react";
// import { Modal, Box, Button, Table, TableContainer, Paper } from "@mui/material";
// import { useReactToPrint } from "react-to-print";

// const PrintModal = ({ isOpen, handleClose, filteredData }) => {
//   const componentRef = useRef();

//   const handlePrint = useReactToPrint({
//     content: () => componentRef.current,
//   });

//   // Helper function to format date to dd/mm/yyyy
//   const formatDate = (dateStr) => {
//     const date = new Date(dateStr);
//     return date.toLocaleDateString("en-GB"); // 'en-GB' formats to dd/mm/yyyy
//   };

//   // Convert filteredData into a single flat array sorted by date
//   let allEntries = [];
//   Object.keys(filteredData).forEach((date) => {
//     const { receipts, payments } = filteredData[date];

//     // Add date to each entry and classify as receipt or payment
//     allEntries = [
//       ...allEntries,
//       ...receipts.map((item) => ({ ...item, date, type: "receipt" })),
//       ...payments.map((item) => ({ ...item, date, type: "payment" })),
//     ];
//   });

//   // Sort all entries by date (oldest first)
//   allEntries.sort((a, b) => new Date(a.date) - new Date(b.date));

//   // Compute grand totals
//   let grandTotalReceipts = 0;
//   let grandTotalPayments = 0;

//   return (
//     <Modal open={isOpen} onClose={handleClose}>
//       <Box
//         sx={{
//           bgcolor: "white",
//           p: 4,
//           width: "90%",
//           margin: "auto",
//           mt: 5,
//           overflowY: "auto",
//           maxHeight: "80vh",
//         }}
//       >
//         <Button variant="contained" color="primary" onClick={handlePrint}>
//           Print
//         </Button>
//         <Button variant="contained" color="secondary" onClick={handleClose} style={{ marginLeft: 10 }}>
//           Close
//         </Button>

//         {/* Printable Area */}
//         <div ref={componentRef} style={{ padding: 10 }}>
//           {/* Print-Specific Styles */}
//           <style>
//             {`
//               @media print {
//                 * {
//                   -webkit-print-color-adjust: exact;
//                 }

//                 body {
//                   margin: 0;
//                   padding: 0;
//                 }

//                 .no-break {
//                   page-break-inside: avoid;
//                   break-inside: avoid;
//                 }

//                 table {
//                   page-break-inside: auto;
//                 }

//                 tr {
//                   page-break-inside: avoid;
//                   page-break-after: auto;
//                 }
//               }
//             `}
//           </style>

//           {/* Company Name Header */}
//           {/* <h3 style={{ textAlign: "center" }}>SHADOW PVT LTD.</h3>
//           <h3 style={{ textAlign: "center" }}>Tower-II, Floor No.2</h3>
//           <h3 style={{ textAlign: "center" }}>Mandi Gobindgarh</h3> */}

//           {/* Single Continuous Table */}
//           <TableContainer component={Paper} style={{ marginTop: 20 }}>
//             <Table>
//               <thead>
//                 <tr style={{ backgroundColor: "lightgrey" }}>
//                   <th style={styles.tableHeader}>Date</th>
//                   <th style={styles.tableHeader}>Account Name</th>
//                   <th style={styles.tableHeader}>Narration</th>
//                   <th style={styles.tableHeader}>Receipts</th>
//                   <th style={styles.tableHeader}>Payments</th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {allEntries.map((item, index) => {
//                   const receiptAmount = item.type === "receipt" ? parseFloat(item.receipt_credit || 0) : 0;
//                   const paymentAmount = item.type === "payment" ? parseFloat(item.payment_debit || 0) : 0;
                  
//                   // Update grand totals
//                   grandTotalReceipts += receiptAmount;
//                   grandTotalPayments += paymentAmount;

//                   return (
//                     <tr key={index} className="no-break">
//                       <td style={styles.tableCell}>{formatDate(item.date)}</td>
//                       <td style={styles.tableCell}>{item.accountname}</td>
//                       <td style={styles.tableCell}>{item.narration}</td>
//                       <td style={{ ...styles.tableCell, textAlign: "right" }}>
//                         {receiptAmount > 0 ? receiptAmount.toFixed(2) : ""}
//                       </td>
//                       <td style={{ ...styles.tableCell, textAlign: "right" }}>
//                         {paymentAmount > 0 ? paymentAmount.toFixed(2) : ""}
//                       </td>
//                     </tr>
//                   );
//                 })}

//                 {/* Grand Total Row */}
//                 <tr style={{ fontWeight: "bold", backgroundColor: "#ccc" }}>
//                   <td colSpan="3" style={styles.subTotalCell}>Grand Total</td>
//                   <td style={{ ...styles.subTotalCell, textAlign: "right" }}>{grandTotalReceipts.toFixed(2)}</td>
//                   <td style={{ ...styles.subTotalCell, textAlign: "right" }}>{grandTotalPayments.toFixed(2)}</td>
//                 </tr>
//               </tbody>
//             </Table>
//           </TableContainer>
//         </div>
//       </Box>
//     </Modal>
//   );
// };

// // Styles for table elements
// const styles = {
//   tableHeader: {
//     border: "1px solid black",
//     padding: "8px",
//     textAlign: "center",
//     fontWeight: "bold",
//   },
//   tableCell: {
//     border: "1px solid black",
//     padding: "8px",
//     textAlign: "left",
//   },
//   subTotalCell: {
//     border: "1px solid black",
//     padding: "8px",
//     fontWeight: "bold",
//     backgroundColor: "#f0f0f0",
//   },
// };

// export default PrintModal;


