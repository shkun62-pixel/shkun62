import React, { useState, useEffect, useRef } from "react";
import "./ProductionCard.css"
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Table from "react-bootstrap/Table";
import Button from "react-bootstrap/Button";
import { BiTrash } from "react-icons/bi";
import axios from "axios";
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useEditMode } from "../../EditModeContext";
import ProductModal from "../Modals/ProductModal";
import ProductionPDF from "../InvoicePDF/ProductionPDF";
import ProductionReport from "./ProductionReport";
import { CompanyContext } from '../Context/CompanyContext';
import { useContext } from "react";

const ProductionCard = () => {

   const { company } = useContext(CompanyContext);
    const tenant = company?.databaseName;
  
    if (!tenant) {
      // you may want to guard here or show an error state,
      // since without a tenant you can’t hit the right API
      console.error("No tenant selected!");
    }
  
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [fontSize, setFontSize] = useState(17); // Initial font size in pixels
  const [currentDate, setCurrentDate] = useState("");
  const [currentDay, setCurrentDay] = useState("");
  const datePickerRef = useRef(null);
  const voucherRef = useRef(null);
  const StockNameRef = useRef([]);
  const AcCodeRef = useRef([]);
  const NarrationRef = useRef([]);
  const qtyReceiptRef = useRef([]);
  const qtyIssueRef = useRef([]);
  const pcsissueRef = useRef([]);
  const pcsreceiptRef = useRef([]);
  const SaveButtonRef = useRef([]);
  const [title, setTitle] = useState("View");
  const initialColors = ["#E9967A","#F0E68C","#FFDEAD","#ADD8E6","#87CEFA","#FFF0F5","#FFC0CB","#D8BFD8","#DC143C","#DCDCDC","#8FBC8F",];
  const [buttonColors, setButtonColors] = useState(initialColors);
  const [formData, setFormData] = useState({
    date: "",
    voucherno: 0,
    owner: "Owner",
    UnitNo:"",
    SelectAuto:"",
    totalIssue:"",
    totalReceipt:"",
  });
  const [items, setItems] = useState([
    {
      id: 1,
      Aheads: "",
      Acodes: "",
      Narration:"",
      pcsIssue:"",
      pcsReceipt:"",
      qtyIssue:"",
      qtyReceipt:"",
      Types:"",
      Psrno:"",
      PUnitno:"",
      Percentage:"",
    },
  ]);

  useEffect(() => {
    const date = new Date();
    const options = { weekday: "long" };
    const day = new Intl.DateTimeFormat("en-US", options).format(date);

    const formattedDate = date.toLocaleDateString();

    setCurrentDate(formattedDate);
    setCurrentDay(day);
  }, []);

  const [selectedDate, setSelectedDate] = useState(new Date());
  const [dayName, setDayName] = useState("");
  const getDayName = (date) => {
    const daysOfWeek = [
      "Sunday",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
    ];
    return daysOfWeek[date.getDay()];
  };
 
     useEffect(() => {
       // If formData.date has a valid date string, parse it and set selectedDate
       if (formData.date) {
         try {
           const date = new Date(formData.date);
           if (!isNaN(date.getTime())) {
             setSelectedDate(date);
           } else {
             console.error("Invalid date value in formData.date:", formData.date);
           }
         } catch (error) {
           console.error("Error parsing date:", error);
         }
       } else {
         // If there's no date, we keep selectedDate as null so the DatePicker is blank,
         // but we can still have it open on today's date via openToDate
         setSelectedDate(null);
       }
     }, [formData.date]);


  const handleDateChange = (date) => {
    if (date instanceof Date && !isNaN(date)) {
      setSelectedDate(date);

      // Format or store date in formData as needed
      const formattedDate = date.toISOString().split("T")[0]; // e.g. "2025-03-10"
      setFormData((prev) => ({ ...prev, date: date , duedate: date }));
      setDayName(getDayName(date));
    } else {
      console.error("Invalid date value");
    }
  };

  const handleCalendarClose = () => {
    // If no date is selected when the calendar closes, default to today's date
    if (!selectedDate) {
      const today = new Date();
      setSelectedDate(today);
    }
  };

  const handleChangevalues = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

   const [data, setData] = useState([]);
   const [data1, setData1] = useState([]);
   const [index, setIndex] = useState(0);
   const [isAddEnabled, setIsAddEnabled] = useState(true);
   const [isSubmitEnabled, setIsSubmitEnabled] = useState(false);
   const [isPreviousEnabled, setIsPreviousEnabled] = useState(true);
   const [isNextEnabled, setIsNextEnabled] = useState(true);
   const [isFirstEnabled, setIsFirstEnabled] = useState(true);
   const [isLastEnabled, setIsLastEnabled] = useState(true);
   const [isSearchEnabled, setIsSearchEnabled] = useState(true);
   const [isPrintEnabled, setIsSPrintEnabled] = useState(true);
   const [isDeleteEnabled, setIsDeleteEnabled] = useState(true);
   const { isEditMode, setIsEditMode } = useEditMode(); // Access the context
   const [isAbcmode, setIsAbcmode] = useState(false);
   const [isDisabled, setIsDisabled] = useState(false); // State to track field disablement

   const fetchData = async () => {
       try {
         const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/productioncard/last`);
     
         if (response.status === 200 && response.data && response.data.data) {
           const lastEntry = response.data.data;
           // Ensure date is valid
           const isValidDate = (date) => {
             return !isNaN(Date.parse(date));
           };
     
           // Update form data, use current date if date is invalid or not available
           const updatedFormData = {
             ...lastEntry.formData,
             date: isValidDate(lastEntry.formData.date) ? lastEntry.formData.date : new Date().toLocaleDateString(),
           };

           setFormData(updatedFormData);
           // Update items and supplier details
           const updatedItems = lastEntry.items.map(item => ({
             ...item,
           }));
           setItems(updatedItems);
           // Set data and index
           setData1({ ...lastEntry, formData: updatedFormData });
           setIndex(lastEntry.voucherno);
         } else {
           console.log("No data available");
           initializeEmptyData();
         }
       } catch (error) {
         console.error("Error fetching data", error);
         initializeEmptyData();
       }
     };
     // Function to initialize empty data
     const initializeEmptyData = () => {
       const emptyFormData = {
       date: "",
       voucherno: 0,
       owner: "Owner",
       UnitNo:"",
       SelectAuto:"",
       totalIssue:"",
       totalReceipt:"",
       };
       const emptyItems = [
        {
          id: 1,
          Aheads: "",
          Acodes: "",
          Narration:"",
          pcsIssue:"",
          pcsReceipt:"",
          qtyIssue:"",
          qtyReceipt:"",
          Types:"",
          Psrno:"",
          PUnitno:"",
          Percentage:"",
        },
       ];
       // Set the empty data
       setFormData(emptyFormData);
       setItems(emptyItems);
       setData1({
         formData: emptyFormData,
         items: emptyItems,
       });
       setIndex(0);
     };
     
     useEffect(() => {
       fetchData();
       setIsDisabled(true); 
       // Add this line to set isDisabled to true initially
     }, []);

  const [pressedKey, setPressedKey] = useState(""); // State to hold the pressed key
  const handleKeyDown = (event, index, field) => {
    if (event.key === "Enter") {
      switch (field) {
        case "Aheads":
          if (items[index].Aheads.trim() === "") {
            SaveButtonRef.current.focus();
          } else {
            NarrationRef.current[index]?.focus();
          }
          break;
        case "Acodes":
          NarrationRef.current[index]?.focus();
          break;
        case "Narration":
          if (pcsissueRef.current[index]?.disabled) {
          pcsreceiptRef.current[index]?.focus();
          } 
          if (pcsissueRef.current[index]?.disabled && qtyReceiptRef.current[index]?.disabled ) {
            qtyIssueRef.current[index]?.focus();
          }
          if (pcsissueRef.current[index]?.disabled && pcsreceiptRef.current[index]?.disabled ) {
            qtyReceiptRef.current[index]?.focus();
          }
          else {
          pcsissueRef.current[index]?.focus();
          }
          break;
        case "pcsIssue":
          if (index === items.length - 1) {
            handleAddItem();
          }
          StockNameRef.current[index + 1]?.focus();
          break;
        case "pcsReceipt":
          if (index === items.length - 1) {
            handleAddItem();
          }
          StockNameRef.current[index + 1]?.focus();
          break;
          // case "qtyIssue":
          //   qtyReceiptRef.current[index]?.focus();
          //   break;
          case "qtyReceipt":
          if (index === items.length - 1) {
            handleAddItem();
          }
          StockNameRef.current[index + 1]?.focus();
          break;
        case "qtyIssue":
          if (index === items.length - 1) {
            handleAddItem();
          }
          StockNameRef.current[index + 1]?.focus();
          break;
        default:
          break;
      }
    }
  };
  
  const calculateTotalIssue = () => {
    // Calculate the total payment by summing up all payment_debit values
    const QtyIssue = items.reduce((acc, item) => {
      return acc + parseFloat(item.qtyIssue || 0);
    }, 0);
    const PcsIssue = items.reduce((acc, item) => {
      return acc + parseFloat(item.pcsIssue || 0);
    }, 0);
    let TotalIssue = QtyIssue + PcsIssue
    setFormData((prevFormData) => ({
      ...prevFormData,
      totalIssue: TotalIssue.toFixed(2),
    }));
  };

  const calculateTotalReceipt = () => {
    // Calculate the total receipt by summing up all receipt_credit values
    const QtyReceipt = items.reduce((acc, item) => {
      return acc + parseFloat(item.qtyReceipt || 0);
    }, 0);
    const PcsReceipt = items.reduce((acc, item) => {
      return acc + parseFloat(item.pcsReceipt || 0);
    }, 0);
    let TotalReceipt = QtyReceipt + PcsReceipt
    setFormData((prevFormData) => ({
      ...prevFormData,
      totalReceipt: TotalReceipt.toFixed(2),
    }));
  };

   useEffect(() => {
      fetchProducts();
      if (!isAddEnabled && formData.SelectAuto === "Auto Selection One by One") {
        fetchProducts2();
      } else {
        setItems([{
          id: 1,
          Aheads: "",
          Acodes: "",
          Narration: "",
          pcsIssue: "",
          pcsReceipt: "",
          qtyIssue: "",
          qtyReceipt: "",
          Types: "",
          Psrno: "",
          PUnitno: "",
          Percentage: "",
        },]); // Clear items for manual selection
      }
    }, [formData.SelectAuto]);
  
    const fetchProducts = async () => {
      try {
        const response = await fetch(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/stockmaster`);
        if (!response.ok) {
          throw new Error("Failed to fetch products");
        }
        const data = await response.json();
        const flattenedData = data.map((item) => ({
          ...item.formData,
          _id: item._id,
        }));
        setProducts(flattenedData); // Update state with the products
        setLoading(false);
      } catch (error) {
        setError(error.message);
        setLoading(false);
      }
    };
    
  const fetchProducts2 = async () => {
    try {
      const response = await fetch(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/stockmaster`);
      const data = await response.json();
      const filteredData = data
        .filter(item => item.formData?.T1 === true)
        .sort((a, b) => (a.formData.Psrno || 0) - (b.formData.Psrno || 0))
        .map((item, index) => ({
          id: index + 1,
          Aheads: item.formData.Aheads || "",
          Acodes: item.formData.Acodes || "",
          Narration: "",
          pcsIssue: "",
          pcsReceipt: "",
          qtyIssue: "",
          qtyReceipt: "",
          Types: item.formData.Types || "",
          Psrno: item.formData.Psrno || "",
          PUnitno: item.formData.PUnitno || "",
          Percentage: item.formData.percentage || "",
        }));
      setItems(filteredData);
    } catch (error) {
      console.error("Failed to fetch products", error);
    }
  };

    // Modal For Items
    const [products, setProducts] = useState([]);
    const [showModal, setShowModal] = useState(false);
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [selectedItemIndex, setSelectedItemIndex] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
  
    const handleItemChange = (index, key, value,field) => {

       // If key is "pkgs" or "weight", allow only numbers and a single decimal point
       if ((key === "pcsIssue" || key === "pcsReceipt"|| key === "qtyIssue"|| key === "qtyReceipt") && !/^\d*\.?\d*$/.test(value)) {
        return; // reject invalid input
      }
      const updatedItems = [...items];
      updatedItems[index][key] = value;
  
      // If the key is 'name', find the corresponding product and set the price
      if (key === "name") {
        const selectedProduct = products.find((product) => product.Aheads === value);
        if (selectedProduct) {
          updatedItems[index]["Acodes"] = selectedProduct.Acodes;
          updatedItems[index]["Aheads"] = selectedProduct.Aheads;
          updatedItems[index]["Types"] = selectedProduct.Types;
          updatedItems[index]["Psrno"] = selectedProduct.Psrno;
          updatedItems[index]["PUnitno"] = selectedProduct.PUnitno;
          updatedItems[index]["Percentage"] = selectedProduct.percentage;
        } else {
          updatedItems[index]["Acodes"] = ""; // Reset price if product not found
          updatedItems[index]["Aheads"] = ""; // Reset gst if product not found
        }
      }
  // Get Raw Material issue values
  const rawMaterial = updatedItems.find(item => item.Types === 'Raw Material');
  const pcsIssueValue = rawMaterial ? parseFloat(rawMaterial.pcsIssue) || 0 : 0;
  const qtyIssueValue = rawMaterial ? parseFloat(rawMaterial.qtyIssue) || 0 : 0;

  // Initialize total receipts
  let totalPcsReceipt = 0;
  let totalQtyReceipt = 0;
  let wastageIndex = -1;

  updatedItems.forEach((item, idx) => {
    if (item.Types === 'Wastage') {
      wastageIndex = idx; // Track wastage index for later adjustment
    }

    if (
      (item.Types === 'Finished Product' || item.Types === 'Semi-Finished Product') &&
      parseFloat(item.Percentage) > 0
    ) {
      // Calculate based on pcsIssue and update pcsReceipt
      if (pcsIssueValue > 0) {
        const pcsReceiptValue = ((pcsIssueValue * parseFloat(item.Percentage)) / 100).toFixed(2);
        updatedItems[idx]["pcsReceipt"] = pcsReceiptValue;
        totalPcsReceipt += parseFloat(pcsReceiptValue);
      } else {
        updatedItems[idx]["pcsReceipt"] = "0";
      }

      // Calculate based on qtyIssue and update qtyReceipt
      if (qtyIssueValue > 0) {
        const qtyReceiptValue = ((qtyIssueValue * parseFloat(item.Percentage)) / 100).toFixed(2);
        updatedItems[idx]["qtyReceipt"] = qtyReceiptValue;
        totalQtyReceipt += parseFloat(qtyReceiptValue);
      } else {
        updatedItems[idx]["qtyReceipt"] = "0";
      }
    }
  });

  // Adjust wastage for both pcsReceipt and qtyReceipt
  if (wastageIndex !== -1) {
    updatedItems[wastageIndex]["pcsReceipt"] = (pcsIssueValue > 0 ? (pcsIssueValue - totalPcsReceipt).toFixed(2) : "0");
    updatedItems[wastageIndex]["qtyReceipt"] = (qtyIssueValue > 0 ? (qtyIssueValue - totalQtyReceipt).toFixed(2) : "0");
  }

  // Handle Manual Selection for matching items
  if (formData.SelectAuto === 'Mannauly Selection') {
    const matchingItems = updatedItems.filter(
      (item, idx) =>
        idx !== index &&
        item.Aheads === updatedItems[index].Aheads &&
        item.Types !== 'Raw Material' &&
        parseFloat(item.Percentage) > 0
    );

    matchingItems.forEach((match) => {
      if (pcsIssueValue > 0) {
        const pcsReceiptValue = ((pcsIssueValue * parseFloat(match.Percentage)) / 100).toFixed(2);
        match["pcsReceipt"] = pcsReceiptValue;
      } else {
        match["pcsReceipt"] = "0";
      }

      if (qtyIssueValue > 0) {
        const qtyReceiptValue = ((qtyIssueValue * parseFloat(match.Percentage)) / 100).toFixed(2);
        match["qtyReceipt"] = qtyReceiptValue;
      } else {
        match["qtyReceipt"] = "0";
      }
    });
  }
      calculateTotalIssue();
      calculateTotalReceipt();
      setItems(updatedItems);
    };
    // Function to handle adding a new item
    const handleAddItem = () => {
      if (isEditMode) {
        const newItem = {
        id: items.length + 1,
        Aheads: "",
        Acodes: "",
        Narration:"",
        pcsIssue:"",
        pcsReceipt:"",
        qtyIssue:"",
        qtyReceipt:"",
        Types:"",
        Percentage:"",
        };
        setItems((prevItems) => [...prevItems, newItem]);
        setTimeout(() => {
        StockNameRef.current[items.length].focus();
        }, 100);
      }
    };
    const handleDeleteItem = (index) => {
      if (isEditMode) {
          const confirmDelete = window.confirm("Do you really want to delete this item?");
          // Proceed with deletion if the user confirms
          if (confirmDelete) {
              const filteredItems = items.filter((item, i) => i !== index);
              setItems(filteredItems);
          }
      }
  };
  
    const handleProductSelect = (product) => {
      if (selectedItemIndex !== null) {
        handleItemChange(selectedItemIndex, "name", product.Aheads);
        setShowModal(false);
      }
    };
  
    const openModalForItem = (index) => {
      if(isEditMode){
        setSelectedItemIndex(index);
        setShowModal(true);
      }
    };
  
    const allFields = products.reduce((fields, product) => {
      Object.keys(product).forEach((key) => {
        if (!fields.includes(key)) {
          fields.push(key);
        }
      });
  
      return fields;
    }, []);
  
  const handleOpenModal = (event, index, field) => {
    if (/^[a-zA-Z]$/.test(event.key) && field === "Aheads") {
      setPressedKey(event.key); // Set the pressed key
      openModalForItem(index);
      event.preventDefault(); // Prevent any default action
    }
  };

  const handleSelectAuto = (event) => {
    const { value } = event.target; // Get the selected value from the event
    setFormData((prevState) => ({
      ...prevState,
      SelectAuto: value, // Update the ratecalculate field in FormData
    }));
  };
  
  const handleNext = async () => {
      document.body.style.backgroundColor = "white";
      setTitle("View");
      // console.log(data1._id)
      try {
        if (data1) {
          const response = await axios.get(
            `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/productioncard/next/${data1._id}`
          );
          if (response.status === 200 && response.data) {
            const nextData = response.data.data;
            setData1(response.data.data);
            setIndex(index + 1);
            setFormData(nextData.formData);
            const updatedItems = nextData.items.map((item) => ({
              ...item,
              disableReceipt: item.disableReceipt || false,
            }));
            setItems(updatedItems);
            setIsDisabled(true);
          }
        }
      } catch (error) {
        console.error("Error fetching next record:", error);
      }
  };
  
  const handlePrevious = async () => {
      document.body.style.backgroundColor = "white";
      setTitle("View");
      try {
        if (data1) {
          const response = await axios.get(
            `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/productioncard/previous/${data1._id}`
          );
          if (response.status === 200 && response.data) {
            // console.log(response);
            setData1(response.data.data);
            const prevData = response.data.data;
            setIndex(index - 1);
            setFormData(prevData.formData);
            const updatedItems = prevData.items.map((item) => ({
              ...item,
              disableReceipt: item.disableReceipt || false,
            }));
            setItems(updatedItems);
            setIsDisabled(true);
          }
        }
      } catch (error) {
        console.error("Error fetching previous record:", error);
      }
  };
  
  const handleFirst = async () => {
      document.body.style.backgroundColor = "white";
      setTitle("View");
  
      try {
        const response = await axios.get(
          `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/productioncard/first`
        );
        if (response.status === 200 && response.data) {
          const firstData = response.data.data;
          setIndex(0);
          setFormData(firstData.formData);
          setData1(response.data.data);
          const updatedItems = firstData.items.map((item) => ({
            ...item,
            disableReceipt: item.disableReceipt || false,
          }));
          setItems(updatedItems);
          setIsDisabled(true);
        }
      } catch (error) {
        console.error("Error fetching first record:", error);
      }
  };
  
  const handleLast = async () => {
      document.body.style.backgroundColor = "white";
      setTitle("View");
  
      try {
        const response = await axios.get(
          `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/productioncard/last`
        );
        if (response.status === 200 && response.data) {
          const lastData = response.data.data;
          const lastIndex = response.data.length - 1;
          setIndex(lastIndex);
          setFormData(lastData.formData);
          setData1(response.data.data);
          const updatedItems = lastData.items.map((item) => ({
            ...item,
            disableReceipt: item.disableReceipt || false,
          }));
          setItems(updatedItems);
          setIsDisabled(true);
        }
      } catch (error) {
        console.error("Error fetching last record:", error);
      }
  };

  const handleAdd = async () => {
    // document.body.style.backgroundColor = "#D5ECF3";
    try {
      let lastvoucherno = formData.voucherno ? parseInt(formData.voucherno) + 1 : 1;
      const newData = {
       date: "",
      voucherno: lastvoucherno,
      owner: "Owner",
      UnitNo:"",
      SelectAuto:"",
      totalIssue:"",
      totalReceipt:"",
      };
      setData([...data, newData]);
      setFormData(newData);
      setItems([
        {
          id: 1,
          Aheads: "",
          Acodes: "",
          Narration: "",
          pcsIssue:"",
          pcsReceipt:"",
          qtyIssue:"",
          qtyReceipt:"",
          Types:"",
          Psrno:"",
          PUnitno:"",
          Percentage:"",
        },
      ]);
      setIndex(data.length);
      setIsAddEnabled(false);
      setIsSubmitEnabled(true);
      setIsPreviousEnabled(false);
      setIsNextEnabled(false);
      setIsFirstEnabled(false);
      setIsLastEnabled(false);
      setIsSearchEnabled(false);
      setIsSPrintEnabled(false);
      setIsDeleteEnabled(false);
      setIsDisabled(false);
      setIsEditMode(true);
      setTitle('(NEW)')
      if (datePickerRef.current) {
        datePickerRef.current.setFocus();
      }
    } catch (error) {
      console.error("Error adding new entry:", error);
    }
  };

  const handleDeleteClick = async (id) => {
      if (!id) {
        toast.error("Invalid ID. Please select an item to delete.", {
          position: "top-center",
        });
        return;
      }
      const userConfirmed = window.confirm("Are you sure you want to delete this item?");
      if (!userConfirmed) return;
      try {
        const apiEndpoint = `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/productioncard/${data1._id}`;
        const response = await axios.delete(apiEndpoint);
  
        if (response.status === 200) {
          toast.success("Data deleted successfully!", { position: "top-center" });
          fetchData(); // Refresh the data after successful deletion
        } else {
          throw new Error(`Failed to delete data: ${response.statusText}`);
        }
      } catch (error) {
        console.error("Error deleting data:", error);
        toast.error(`Failed to delete data. Error: ${error.message}`, {
          position: "top-center",
        });
      } finally {
      }
  };

  const handleEditClick = () => {
    setTitle("(Edit)");
    setIsDisabled(false);
    setIsEditMode(true);
    setIsAddEnabled(false);
    setIsSubmitEnabled(true);
    setIsPreviousEnabled(false);
    setIsNextEnabled(false);
    setIsFirstEnabled(false);
    setIsLastEnabled(false);
    setIsSearchEnabled(false);
    setIsSPrintEnabled(false);
    setIsDeleteEnabled(false);
    setIsAbcmode(true);
    if (StockNameRef.current[0]) {
      StockNameRef.current[0].focus();
    }
  };
  const handleExit = async () => {
    document.body.style.backgroundColor = "white"; // Reset background color
    setTitle("View");
    try {
      const response = await axios.get(
        `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/productioncard/last`
      ); // Fetch the latest data

      if (response.status === 200 && response.data.data) {
        // If data is available
        const lastEntry = response.data.data;
        setFormData(lastEntry.formData); // Set form data
        const updatedItems = lastEntry.items.map((item) => ({
          ...item,
        }));
        setItems(updatedItems);
        setIsDisabled(true);
        setIndex(lastEntry.formData);
        setIsAddEnabled(true);
        setIsSubmitEnabled(false);
        setIsPreviousEnabled(true);
        setIsNextEnabled(true);
        setIsFirstEnabled(true);
        setIsLastEnabled(true);
        setIsSearchEnabled(true);
        setIsSPrintEnabled(true);
        setIsDeleteEnabled(true);
      } else {
        // If no data is available, initialize with default values
        console.log("No data available");
        const newData = {
          date: "",
          voucherno: 0,
          owner: "Owner",
          UnitNo:"",
          SelectAuto:"",
          totalIssue:"",
          totalReceipt:"",
        };
        setFormData(newData); // Set default form data
        setItems([
          {
            id: 1,
            Aheads: "",
            Acodes: "",
            Narration:"",
            pcsIssue:"",
            pcsReceipt:"",
            qtyIssue:"",
            qtyReceipt:"",
            Types:"",
            Psrno:"",
            PUnitno:"",
            Percentage:"",
          },
        ]);
        setIsDisabled(true); // Disable fields after loading the default data
      }
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const handleSaveClick = async () => {
      document.body.style.backgroundColor = "white";
      let isDataSaved = false;
      try {
        const nonEmptyItems = items.filter((item) => item.Aheads.trim() !== "");
        if (nonEmptyItems.length === 0) {
          toast.error("Please fill in at least one Items name.", {
            position: "top-center",
          });
          return;
        }
      // Ensure that total Issue and total Receipt are equal
        const totalIssue = formData.totalIssue
        const totalReceipt = formData.totalReceipt
        if (totalIssue !== totalReceipt) {
          toast.error("Total Issue and Total Receipt must be equal.", { position: "top-center" });
          return;
        }
        const userConfirmed = window.confirm("Are you sure you want to save the data?");
        if (!userConfirmed) {
          return;
        }
        setIsSubmitEnabled(false);
        
        let combinedData;
        if (isAbcmode) {
          combinedData = {
            _id: formData._id,
            formData: {
              date: selectedDate.toLocaleDateString("en-IN"),
              voucherno: formData.voucherno,
              owner: formData.owner,
              UnitNo: formData.UnitNo,
              SelectAuto: formData.SelectAuto,
              totalIssue: formData.totalIssue,
              totalReceipt: formData.totalReceipt,
            },
            items: nonEmptyItems.map((item) => ({
              id: item.id,
              Aheads: item.Aheads,
              Acodes: item.Acodes,
              Narration: item.Narration,
              pcsIssue: item.pcsIssue,
              pcsReceipt: item.pcsReceipt,
              qtyIssue: item.qtyIssue,
              qtyReceipt: item.qtyReceipt,
              Types:item.Types,
              Psrno: item.Psrno,
              PUnitno: item.PUnitno,
              Percentage: item.Percentage,
            }))
          };
        } else {
          combinedData = {
            _id: formData._id,
            formData: {
              date: selectedDate.toLocaleDateString("en-IN"),
              voucherno: formData.voucherno,
              owner: formData.owner,
              UnitNo: formData.UnitNo,
              SelectAuto: formData.SelectAuto,
              totalIssue: formData.totalIssue,
              totalReceipt: formData.totalReceipt,
            },
            items: nonEmptyItems.map((item) => ({
              id: item.id,
              Aheads: item.Aheads,
              Acodes: item.Acodes,
              Narration: item.Narration,
              pcsIssue: item.pcsIssue,
              pcsReceipt: item.pcsReceipt,
              qtyIssue: item.qtyIssue,
              qtyReceipt: item.qtyReceipt,
              Types: item.Types,
              Psrno: item.Psrno,
              PUnitno: item.PUnitno,
              Percentage: item.Percentage,
            }))
          };
        }
        // Debugging
        console.log("Combined Data:", combinedData);
        const apiEndpoint = `http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/productioncard${isAbcmode ? `/${data1._id}` : ""}`;
        const method = isAbcmode ? "put" : "post";
        const response = await axios({
          method,
          url: apiEndpoint,
          data: combinedData,
        });  
        if (response) {
          // console.log("Response1234:",response);
          fetchData();
          isDataSaved = true;
        }
      } catch (error) {
        console.error("Error saving data:", error);
        toast.error("Failed to save data. Please try again.", {
          position: "top-center",
        });
      } finally {
        if (isDataSaved) {
          setTitle("(View)");
          setIsAddEnabled(true);
          setIsDisabled(true);
          setIsEditMode(false);
          setIsPreviousEnabled(true);
          setIsNextEnabled(true);
          setIsFirstEnabled(true);
          setIsLastEnabled(true);
          setIsSPrintEnabled(true);
          setIsNextEnabled(true);
          setIsSearchEnabled(true);
          setIsDeleteEnabled(true);
          toast.success("Data Saved Successfully!", { position: "top-center" });
        } else {
          setIsAddEnabled(true);
          setIsDisabled(false);
          setIsSubmitEnabled(true); // re-enable submit if saving failed or was skipped
        }
      }
  };
  
  const handleItemRateBlur = (id, field) => {
      const decimalPlaces = 3; // Default to 3 decimal places
      setItems((prevItems) =>
        prevItems.map((item) =>
        item.id === id? { ...item,[field]: isNaN(parseFloat(item[field])) ? "": parseFloat(item[field]).toFixed(decimalPlaces),}: item)
      );
  };

  const [shopName, setShopName] = useState("SHADOW ARISE PVT LTD."); // Set default value here
    const [description, setDescription] = useState(
      "STOCKISTS IN : FRESH FRUITS ARE AVAIABLE HERE"
    );
    const [address, setAddress] = useState(
      "AMLOH ROAD, OPP. FRIENDS INDS., MANDI GOBINDGARH (PB)"
    );
    const [GSTIN, setGSTIN] = useState("07AAAHT5580L1ZX");
    const [PAN, setPAN] = useState("BNV5855MN6");
  
    // Function to save data to local storage
    const saveToLocalStorage = () => {
      localStorage.setItem("shopName", shopName);
      localStorage.setItem("description", description);
      localStorage.setItem("address", address);
      localStorage.setItem("GSTIN", GSTIN);
      localStorage.setItem("PAN", PAN);
    };

    const [openReport, setOpenReport] = useState(false);
    const [showModalReport, setShowModalReport] = useState(false);
    const [reportType, setReportType] = useState('Date-wise');
    const [ahead, setAhead] = useState('All');
    const [transactionType, setTransactionType] = useState('All'); // New state for Receipt/Issue/All
    const [aheadOptions, setAheadOptions] = useState([]);

    const handleOpenModalReport = () => setShowModalReport(true);
    const handleCloseModalReport = () => setShowModalReport(false);

    const handleOpenPDF = () => {
        setShowModalReport(false);
        setOpenReport(true);
    };

    const handleClosePDF = () => setOpenReport(false);

    // Fetch unique Aheads from API
    useEffect(() => {
        const fetchAheads = async () => {
            try {
                const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/productioncard`);
                const allAheads = response.data.flatMap(entry => entry.items.map(item => item.Aheads));
                const uniqueAheads = ["All", ...new Set(allAheads)];
                setAheadOptions(uniqueAheads);
            } catch (error) {
                console.error("Error fetching Aheads:", error);
            }
        };

        fetchAheads();
    }, []);

  return (
    <div>
      <ToastContainer />
      <h1 className="Header">PRODUCTION CARD</h1>
      <text className="tittle">{title}</text>
      <div className="containers">
        <span style={styles2.dates}>{currentDate}</span>
        <span style={styles2.days}>{currentDay}</span>
      </div>
      <div className="Tops" style={{ padding: 5 }}>
            <div className="datediv"
              style={{display: "flex",flexDirection: "row",alignItems: "center",}}
            >
              <text style={{ marginRight: 8 }}>VOUCHER DATE:</text>
                      <DatePicker
                      ref={datePickerRef}
                      className="cashdate"
                      id="date"
                      selected={selectedDate || null}
                      openToDate={new Date()}
                      onCalendarClose={handleCalendarClose}
                      dateFormat="dd-MM-yyyy"
                      onChange={handleDateChange}
                    />
              <span style={{ fontWeight: "bold", marginLeft: 10 }}>
                {dayName}
              </span>
            </div>
            <div>
              <text style={{ marginTop: 5 }}>VOUCHER NO:</text>
              <input
              ref={voucherRef}
                className="VoucherNo"
                style={{
                  marginTop: 5,
                  marginLeft: 32,
                  height: "30px",
                  fontSize: `${fontSize}px`,
                }}
                id="voucherno"
                value={formData.voucherno}
                placeholder="Voucher NO."
                onFocus={(e) => e.target.select()}  // Select text on focus
                readOnly={!isEditMode || isDisabled}
              />
            </div>
      </div>
      <div style={{display:'flex',flexDirection:'row',marginLeft:"60%",marginTop:20}}>
      <text style={{color:'black'}}>Unit No.</text>
      <input
      name="UnitNo"
      value={formData.UnitNo}
      onChange={handleChangevalues}
      style={{border:"1px solid black",fontWeight:'bold',paddingLeft:5,width:120,borderRadius:5}}
      readOnly={!isEditMode || isDisabled}
      />
      <select
      className="billcashz"
      id="SelectAuto"
      style={{
      height: "30px",
      backgroundColor: "white",
      fontSize: `${fontSize}px`,
      color: "black",
      }}
      value={formData.SelectAuto}
      onChange={handleSelectAuto}
      disabled={!isEditMode || isDisabled}
      >
      <option value=""></option>
      <option value="Auto Selection One by One">Auto Selection One by One</option>
      <option value="Mannauly Selection">Mannauly Selection</option>
      </select>
      </div>
      <div style={{marginTop:5}} className="tablediv">
              <Table  className="custom-table">
                <thead style={{background: "skyblue", textAlign: "center", position: "sticky", top: 0,}}>
                  <tr style={{ color: "#575a5a" }}>
                    <th>STOCK ITEM NAME</th>
                    <th>A.CODE</th>
                    <th>NARRATION</th>
                    <th>PCS ISSUE</th>
                    <th>PCS RECEIPT</th>
                    <th>QTY ISSUE</th>
                    <th>QTY RECEIPT</th>
                    <th className="text-center">ACTION</th>
                  </tr>
                </thead>
                <tbody style={{ overflowY: "auto", maxHeight: "calc(320px - 40px)" }}>
                {items.map((item, index) => {
                const pcsIssue = parseFloat(item.pcsIssue) || 0;
                const pcsReceipt = parseFloat(item.pcsReceipt) || 0;
                const qtyIssue = parseFloat(item.qtyIssue) || 0;
                const qtyReceipt = parseFloat(item.qtyReceipt) || 0;

                const disablePcsIssue = pcsReceipt > 0 || qtyIssue > 0 || qtyReceipt > 0;
                const disablePcsReceipt = pcsIssue > 0 || qtyIssue > 0 || qtyReceipt > 0;
                const disableQtyIssue = pcsIssue > 0 || pcsReceipt > 0 || qtyReceipt > 0;
                const disableQtyReceipt = pcsIssue > 0 || pcsReceipt > 0 || qtyIssue > 0;

                return (
                  <tr key={item.id}>
                    <td style={{ padding: 0,width:400}}>
                                      <input
                                      className="ItemCode"
                                        style={{height: 40,fontSize: `${fontSize}px`,width: "100%",boxSizing: "border-box",border: "none",padding: 5,}}
                                        type="text"
                                        value={item.Aheads}
                                        onKeyDown={(e) => {handleOpenModal(e, index, "Aheads");
                                        //  handleOpenModalBack(e, index, "vcode");
                                        handleKeyDown(e, index, "Aheads");
                                        }}
                                        onFocus={(e) => e.target.select()}  // Select text on focus
                                        readOnly={!isEditMode || isDisabled}
                                        ref={(el) => (StockNameRef.current[index] = el)}
                                      />
                                    </td>
                                    <td style={{ padding: 0,width:120}}>
                                      <input
                                      className="desc"
                                        style={{
                                          height: 40,
                                          fontSize: `${fontSize}px`,
                                          width: "100%",
                                          boxSizing: "border-box",
                                          border: "none",
                                          padding: 5,color:'black'
                                        }}
                                        maxLength={48}
                                        value={item.Acodes}
                                        onChange={(e) =>handleItemChange(index, "Acodes", e.target.value)}
                                        onFocus={(e) => e.target.select()}  // Select text on focus
                                        disabled
                                        onKeyDown={(e) => {handleKeyDown(e, index, "Acodes")}}
                                        ref={(el) => (AcCodeRef.current[index] = el)}
                                      />
                                    </td>
                                    <td style={{ padding: 0,width:400}}>
                                      <input
                                        className="Hsn"
                                        style={{
                                          height: 40,
                                          fontSize: `${fontSize}px`,
                                          width: "100%",
                                          boxSizing: "border-box",
                                          border: "none",
                                          padding: 5,
                                        }}
                                        value={item.Narration}
                                        onChange={(e) =>handleItemChange(index, "Narration", e.target.value)}
                                        onFocus={(e) => e.target.select()}  // Select text on focus
                                        readOnly={!isEditMode || isDisabled}
                                        onKeyDown={(e) => {handleKeyDown(e, index, "Narration")}}
                                        ref={(el) => (NarrationRef.current[index] = el)}
                                      />
                                    </td>
                    <td style={{ padding: 0 }}>
                      <input
                        className="Amount"
                        style={{
                          height: 40,
                          fontSize: `${fontSize}px`,
                          width: "100%",
                          boxSizing: "border-box",
                          border: "none",
                          padding: 5,
                          textAlign: "right",
                        }}
                        name="pcsIssue"
                        value={item.pcsIssue}
                        onChange={(e) => handleItemChange(index, "pcsIssue", e.target.value)}
                        onFocus={(e) => e.target.select()}
                        onBlur={() => handleItemRateBlur(item.id, "pcsIssue")}
                        readOnly={!isEditMode || isDisabled}
                        onKeyDown={(e) => handleKeyDown(e, index, "pcsIssue")}
                        ref={(el) => (pcsissueRef.current[index] = el)}
                        disabled={disablePcsIssue}
                      />
                    </td>

                    <td style={{ padding: 0 }}>
                      <input
                        className="Amount"
                        style={{
                          height: 40,
                          fontSize: `${fontSize}px`,
                          width: "100%",
                          boxSizing: "border-box",
                          border: "none",
                          padding: 5,
                          textAlign: "right",
                        }}
                        name="pcsReceipt"
                        value={item.pcsReceipt}
                        onChange={(e) => handleItemChange(index, "pcsReceipt", e.target.value)}
                        onFocus={(e) => e.target.select()}
                        onBlur={() => handleItemRateBlur(item.id, "pcsReceipt")}
                        readOnly={!isEditMode || isDisabled}
                        onKeyDown={(e) => handleKeyDown(e, index, "pcsReceipt")}
                        ref={(el) => (pcsreceiptRef.current[index] = el)}
                        disabled={disablePcsReceipt}
                      />
                    </td>

                    <td style={{ padding: 0 }}>
                      <input
                        className="Amount"
                        style={{
                          height: 40,
                          fontSize: `${fontSize}px`,
                          width: "100%",
                          boxSizing: "border-box",
                          border: "none",
                          padding: 5,
                          textAlign: "right",
                        }}
                        name="qtyIssue"
                        value={item.qtyIssue}
                        onChange={(e) => handleItemChange(index, "qtyIssue", e.target.value)}
                        onFocus={(e) => e.target.select()}
                        onBlur={() => handleItemRateBlur(item.id, "qtyIssue")}
                        readOnly={!isEditMode || isDisabled}
                        onKeyDown={(e) => handleKeyDown(e, index, "qtyIssue")}
                        ref={(el) => (qtyIssueRef.current[index] = el)}
                        disabled={disableQtyIssue}
                      />
                    </td>

                    <td style={{ padding: 0 }}>
                      <input
                        className="Disc"
                        style={{
                          height: 40,
                          fontSize: `${fontSize}px`,
                          width: "100%",
                          boxSizing: "border-box",
                          border: "none",
                          padding: 5,
                          textAlign: "right",
                        }}
                        name="qtyReceipt"
                        value={item.qtyReceipt}
                        onChange={(e) => handleItemChange(index, "qtyReceipt", e.target.value)}
                        onFocus={(e) => e.target.select()}
                        onBlur={() => handleItemRateBlur(item.id, "qtyReceipt")}
                        readOnly={!isEditMode || isDisabled}
                        onKeyDown={(e) => handleKeyDown(e, index, "qtyReceipt")}
                        ref={(el) => (qtyReceiptRef.current[index] = el)}
                        disabled={disableQtyReceipt}
                      />
                    </td>

                    <td style={{ padding: 0 }} className="text-center">
                      <BiTrash onClick={() => handleDeleteItem(index)} style={{ cursor: 'pointer' }} />
                    </td>
                  </tr>
                );
                })}
              </tbody>
              </Table>
            </div>
            {showModal && (
              <ProductModal
                allFields={allFields}
                products={products}
                onSelect={handleProductSelect}
                onClose={() => setShowModal(false)}
                initialKey={pressedKey} // Pass the pressed key to the modal
              />
            )}
      <div className="addbutton" style={{ marginTop: 10 }}>
        <Button className="fw-bold btn-secondary">
          Add Row
        </Button>
      </div>
      <div className="Belowcontent">
      <div style={{display:'flex',flexDirection:'row'}}>
       <text style={{marginLeft:"25%"}}>Balance Qty</text>
       <input disabled style={{height:30,width:160,marginLeft:"2%",fontWeight: "bold",fontSize: `${fontSize}px`,border: "1px solid black",padding: 5,color: "black"}}/>
       <input disabled style={{height:30,width:300,marginLeft:5,fontWeight: "bold",fontSize: `${fontSize}px`,border: "1px solid black",padding: 5,color: "black"}}/>
       <input disabled value={formData.totalIssue} style={{height:30,width:182,marginLeft:"12.2%",fontWeight: "bold",fontSize: `${fontSize}px`,border: "1px solid black",padding: 5,color: "black"}}/>
       <input disabled value={formData.totalReceipt} style={{height:30,width:182,marginLeft:5,fontWeight: "bold",fontSize: `${fontSize}px`,border: "1px solid black",padding: 5,color: "black"}}/>
      </div>
        <div className="Buttonsgroupz">
          <Button
            disabled={!isAddEnabled}
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[0] }}
            onClick={handleAdd}
          >
            Add
          </Button>
          <Button
            disabled={!isAddEnabled}
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[1] }}
            onClick={handleEditClick}
          >
            Edit
          </Button>
          <Button
            disabled={!isPreviousEnabled}
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[2] }}
            onClick={handlePrevious}
          >
            Previous
          </Button>
          <Button
            disabled={!isNextEnabled}
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[3] }}
            onClick={handleNext}
          >
            Next
          </Button>
          <Button
            disabled={!isFirstEnabled}
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[4] }}
            onClick={handleFirst}
          >
            First
          </Button>
          <Button
            disabled={!isLastEnabled}
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[5] }}
            onClick={handleLast}
          >
            Last
          </Button>
          <Button
            disabled={!isSearchEnabled}
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[6] }}
          >
            Search
          </Button>
          <Button
             onClick={handleOpen}
            disabled={!isPrintEnabled}
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[7] }}
          >
            Print
          </Button>
          <ProductionPDF
            formData={formData}
            items={items}
            isOpen={open}
            handleClose={handleClose}
            GSTIN={GSTIN}
            PAN={PAN}
            shopName={shopName}
            description={description}
            address={address}
          />   
          <Button
            onClick={handleOpenModalReport}
            disabled={!isPrintEnabled}
            className="Buttonz"
            style={{ color: "black", backgroundColor: "lightcoral" }}
          >
            Report
          </Button>
         {/* Modal for selecting Report Type, Ahead, and Transaction Type */}
         <Modal show={showModalReport} onHide={handleCloseModalReport}>
                <Modal.Header closeButton>
                    <Modal.Title>Select Report Options</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form>
                        {/* Report Type Dropdown */}
                        <Form.Group>
                            <Form.Label>Report By</Form.Label>
                            <Form.Select 
                            className="Report"
                                value={reportType} 
                                onChange={(e) => setReportType(e.target.value)}
                            >
                                <option value="Date-wise">Date-wise</option>
                                <option value="Month-wise">Month-wise</option>
                            </Form.Select>
                        </Form.Group>

                            {/* Transaction Type Dropdown */}
                            <Form.Group >
                            <Form.Label>Filter</Form.Label>
                            <Form.Select 
                            className="Filter"
                                value={transactionType} 
                                onChange={(e) => setTransactionType(e.target.value)}
                            >
                                <option value="All">All</option>
                                <option value="Issue">Issue</option>
                                <option value="Receipt">Receipt</option>
                            </Form.Select>
                        </Form.Group>

                        {/* Aheads Dropdown */}
                        <Form.Group >
                            <Form.Label>Product Name</Form.Label>
                            <Form.Select 
                            className="ProductName"
                                value={ahead} 
                                onChange={(e) => setAhead(e.target.value)}
                            >
                                {aheadOptions.map((option, index) => (
                                    <option key={index} value={option}>
                                        {option}
                                    </option>
                                ))}
                            </Form.Select>
                        </Form.Group>
                    </Form>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleCloseModalReport}>Cancel</Button>
                    <Button variant="primary" onClick={handleOpenPDF}>Confirm</Button>
                </Modal.Footer>
            </Modal>

            <ProductionReport 
                isOpen={openReport} 
                handleClose={handleClosePDF} 
                reportType={reportType}
                selectedAhead={ahead}
                transactionType={transactionType}  // Passing the selected transaction type
            />
          <Button
            disabled={!isDeleteEnabled}
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[8] }}
            onClick={handleDeleteClick}
          >
            Delete
          </Button>
          <Button
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[9] }}
            onClick={handleExit}
          >
            Exit
          </Button>
          <Button
            ref={SaveButtonRef}
            disabled={!isSubmitEnabled}
            className="Buttonz"
            style={{ color: "black", backgroundColor: buttonColors[10] }}
            onClick={handleSaveClick}
          >
            Save
          </Button>
        </div>
      </div>
    </div>
  );
};

const styles2 = {
  days: {
    display: "block",
    fontSize: "22px",
    fontWeight: "bold",
  },
  dates: {
    display: "block",
    fontSize: "20px",
    fontWeight: "bold",
  },
};

export default ProductionCard;
