// import React, { useEffect, useState, useRef } from "react";
// import axios from "axios";
// import { useReactToPrint } from "react-to-print";
// import { Modal, Box, Button } from "@mui/material";
// import CloseIcon from "@mui/icons-material/Close";

// const ProductionReport = ({ isOpen, handleClose, reportType, selectedAhead }) => {
//   const [data, setData] = useState([]);
//   const [filteredData, setFilteredData] = useState([]);

//   useEffect(() => {
//     if (isOpen) {
//       fetchProductionData();
//     }
//   }, [isOpen]);

//   const fetchProductionData = async () => {
//     try {
//       const response = await axios.get("http://103.154.233.29:3007/auth/api/ProductionCard");
//       setData(response.data);
//       updateFilteredData(response.data);
//     } catch (error) {
//       console.error("Error fetching production data:", error);
//     }
//   };

//   useEffect(() => {
//     updateFilteredData(data);
//   }, [reportType, selectedAhead]);

//   const updateFilteredData = (data) => {
//     if (!data || data.length === 0) {
//       setFilteredData([]);
//       return;
//     }

//     let flatList = [];

//     if (reportType === "Date-wise") {
//       flatList = data.flatMap((entry) =>
//         entry.items.map((item) => ({
//           ...item,
//           date: entry.formData.date,
//           totalIssue: entry.formData.totalIssue,
//           totalReceipt: entry.formData.totalReceipt,
//         }))
//       );
//     } else if (reportType === "Month-wise") {
//       const groupedData = {};
//       data.forEach((entry) => {
//         const [day, month, year] = entry.formData.date.split("/");
//         const monthYear = `${month}-${year}`;
//         if (!groupedData[monthYear]) {
//           groupedData[monthYear] = [];
//         }
//         entry.items.forEach((item) => {
//           groupedData[monthYear].push({
//             ...item,
//             monthYear,
//             totalIssue: entry.formData.totalIssue,
//             totalReceipt: entry.formData.totalReceipt,
//           });
//         });
//       });
//       flatList = Object.values(groupedData).flat();
//     }

//     // Filter by selected Ahead
//     if (selectedAhead !== "All") {
//       flatList = flatList.filter((item) => item.Aheads === selectedAhead);
//     }

//     setFilteredData(flatList);
//   };

//   const componentRef = useRef();
//   const handlePrint = useReactToPrint({ content: () => componentRef.current });

//   return (
//     <Modal open={isOpen} onClose={handleClose}>
//       <Box sx={{ bgcolor: "white", p: 4, boxShadow: 24 }}>
//         <button onClick={handleClose}>
//           <CloseIcon />
//         </button>
//         <Button onClick={handlePrint} style={{ backgroundColor: "lightcoral", color: "black" }}>
//           Print
//         </Button>

//         <div ref={componentRef} style={{ marginTop: "20px" }}>
//           <h3>{`${reportType} Report - ${selectedAhead}`}</h3>
//           <table style={{ width: "100%", borderCollapse: "collapse", border: "1px solid black" }}>
//             <thead style={{backgroundColor:'gray'}}>
//               <tr>
//                 {reportType === "Date-wise" && <th style={{ border: "1px solid black", padding: "8px", textAlign: "center" }}>Date</th>}
//                 <th style={{ border: "1px solid black", padding: "8px", textAlign: "center" }}>Account Name</th>
//                 <th style={{ border: "1px solid black", padding: "8px", textAlign: "center" }}>Issue</th>
//                 <th style={{ border: "1px solid black", padding: "8px", textAlign: "center" }}>Receipt</th>
//               </tr>
//             </thead>
//             <tbody>
//               {filteredData.map((item, index) => (
//                 <tr key={index}>
//                   {reportType === "Date-wise" && <td style={{ border: "1px solid black", padding: "8px" }}>{item.date}</td>}
//                   <td style={{ border: "1px solid black", padding: "8px" }}>{item.Aheads}</td>
//                 <td style={{ border: "1px solid black", padding: "8px", textAlign: "right" }}>{item.Issue}</td>
//                 <td style={{ border: "1px solid black", padding: "8px", textAlign: "right" }}>{item.Receipt}</td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//       </Box>
//     </Modal>
//   );
// };

// export default ProductionReport;

import React, { useRef, useEffect, useState } from "react";
import axios from "axios";
import { Modal, Box, Button } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import { useReactToPrint } from "react-to-print";

const ProductionReport = ({ isOpen, handleClose, reportType, selectedAhead, transactionType }) => {
    const [data, setData] = useState([]);
    const [filteredData, setFilteredData] = useState([]);

    const componentRef = useRef();
    const handlePrint = useReactToPrint({ content: () => componentRef.current });

    useEffect(() => {
        if (isOpen) fetchProductionData();
    }, [isOpen]);

    const fetchProductionData = async () => {
        try {
            const response = await axios.get(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/ProductionCard`);
            setData(response.data);
            filterData(response.data);
        } catch (error) {
            console.error("Error fetching production data:", error);
        }
    };

    const filterData = (data) => {
        // Step 1: Filter based on Report Type (Date-wise or Month-wise)
        let filtered = [];
        if (reportType === "Date-wise") {
            filtered = data.flatMap(entry =>
                entry.items.map(item => ({
                    ...item,
                    date: entry.formData.date,
                    totalIssue: entry.formData.totalIssue,
                    totalReceipt: entry.formData.totalReceipt,
                }))
            );
        } else if (reportType === "Month-wise") {
            const groupedData = {};
            data.forEach(entry => {
                const [day, month, year] = entry.formData.date.split("/");
                const monthYear = `${month}-${year}`;

                if (!groupedData[monthYear]) groupedData[monthYear] = [];

                entry.items.forEach(item => {
                    groupedData[monthYear].push({
                        ...item,
                        monthYear,
                        totalIssue: entry.formData.totalIssue,
                        totalReceipt: entry.formData.totalReceipt,
                    });
                });
            });

            filtered = Object.values(groupedData).flat();
        }

        // Step 2: Filter by Selected Ahead (if not "All")
        if (selectedAhead !== "All") {
            filtered = filtered.filter(item => item.Aheads === selectedAhead);
        }

        // Step 3: Filter by Transaction Type (Issue/Receipt/All)
        if (transactionType !== "All") {
            filtered = filtered.filter(item => item[transactionType] > 0);
        }

        setFilteredData(filtered);
    };

    useEffect(() => {
        if (data.length > 0) {
            filterData(data);
        }
    }, [reportType, selectedAhead, transactionType]);

    const modalStyle = {
        bgcolor: "white",
        boxShadow: 24,
        p: 4,
        overflowY: "auto",
    };

    return (
        <Modal
            open={isOpen}
            onClose={handleClose}
            style={{ overflow: "auto" }}
            aria-labelledby="modal-title"
            aria-describedby="modal-description"
        >
            <Box sx={modalStyle}>
                <button className="close-button" onClick={handleClose}>
                    <CloseIcon />
                </button>
                <Button
                    style={{ color: "black", backgroundColor: "lightcoral" }}
                    onClick={handlePrint}
                >
                    Print
                </Button>

                {/* Render Filtered Data */}
                <div ref={componentRef} style={{ marginTop: 20 }}>
                    <h3 style={{ textAlign: "center" }}>
                        {reportType} Report - {selectedAhead} - {transactionType}
                    </h3>

                    <table
                        style={{
                            width: "100%",
                            borderCollapse: "collapse",
                            border: "1px solid black",
                        }}
                    >
                        <thead style={{ backgroundColor: "lightgrey" }}>
                            <tr>
                                {reportType === "Date-wise" && <th style={{ border: "1px solid black", padding: "8px", textAlign: "center" }}>Date</th>}
                                <th style={{ border: "1px solid black", padding: "8px", textAlign: "center" }}>Account Name</th>
                                <th style={{ border: "1px solid black", padding: "8px", textAlign: "center" }}>Issue</th>
                                <th style={{ border: "1px solid black", padding: "8px", textAlign: "center" }}>Receipt</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredData.map((item, index) => (
                                <tr key={index}>
                                    {reportType === "Date-wise" && (
                                        <td style={{ border: "1px solid black", textAlign: "center",padding:"8px"}}>
                                            {item.date}
                                        </td>
                                    )}
                                    <td style={{ border: "1px solid black", textAlign: "center",padding:"8px" }}>{item.Aheads}</td>
                                    <td style={{ border: "1px solid black", textAlign: "center",padding:"8px" }}>{item.Issue}</td>
                                    <td style={{ border: "1px solid black", textAlign: "center",padding:"8px" }}>{item.Receipt}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </Box>
        </Modal>
    );
};

export default ProductionReport;


