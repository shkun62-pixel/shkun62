import React from "react";
import { Table } from "react-bootstrap";

const CustomerList = ({selectedCustomer, customers, selectedRow, onCustomerClick }) => {
  return (
    <div className="TableDiv">
      <Table className="custom-table">
        <thead style={{backgroundColor:'skyblue'}}>
          <tr>
            <th>NAME</th>
            <th>CITY</th>
            <th>QTY</th>
            <th>DEBIT</th>
            <th>CREDIT</th>
          </tr>
        </thead>
        <tbody>
          {customers.map((customer, index) => (
            <tr
              key={index}
              onClick={() => onCustomerClick(customer.vacode)}
              style={{
                backgroundColor: selectedRow === index ? "#D3D3D3" : "transparent", // Highlight selected row
                cursor: "pointer",
              }}
            >
              <td>{customer.vacode.trim()}</td>
              <td>{customer.city}</td>
              <td></td>
              <td>{customer.grandtotal || "N/A"}</td>
              <td></td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default CustomerList;
