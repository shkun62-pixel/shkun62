import React, { useEffect, useState, useRef } from "react";
import "./TrailBalance.css";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Button from "react-bootstrap/Button";
import { useNavigate } from "react-router-dom";
import CustomerList from "./CustomerList ";
import OptionModal from "./TrailBalance/OptionModal";
import { CompanyContext } from "./Context/CompanyContext";
import { useContext } from "react";

const TrailBalance = () => {

  const { company } = useContext(CompanyContext);
    const tenant = company?.databaseName;
  
    if (!tenant) {
      // you may want to guard here or show an error state,
      // since without a tenant you can’t hit the right API
      console.error("No tenant selected!");
    }

  let a = "";
   const [isOptionOpen, setIsOptionOpen] = useState(false);
  const initialColors = ["#E9967A","#F0E68C","#FFDEAD","#ADD8E6","#87CEFA","#FFF0F5","#FFC0CB","#D8BFD8","#DC143C","#DCDCDC","#8FBC8F"];
  const [buttonColors, setButtonColors] = useState(initialColors); // Initial colors
  const [selectedDateFrom, setSelectedDateFrom] = useState(null);
  const [selectedDateUpto, setSelectedDateUpto] = useState(null);
 
  const openOptionModal = () => {
    setIsOptionOpen(true);
};
const closeOptionModal = () => {
    setIsOptionOpen(false);
};
   const [data, setData] = useState([]);
    const [customers, setCustomers] = useState([]);
    const [selectedRow, setSelectedRow] = useState(0);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    const printRef = useRef(); 
    useEffect(() => {
      const fetchData = async () => {
        try {
          const response = await fetch(`http://103.168.19.65:3012/08ABCDE9911F1Z2_25042025_25042026/tenant/api/sale`);
          if (!response.ok) {
            throw new Error("Failed to fetch data");
          }
          const result = await response.json();
          setData(result);
  
          const uniqueCustomers = Array.from(
            new Map(
              result.map((entry) => [
                entry.customerDetails[0].vacode.trim(),
                {
                  ...entry.customerDetails[0], // Include customer details
                  grandtotal: entry.formData.grandtotal, // Add grandtotal from formData
                },
              ])
            ).values()
          );
  
          setCustomers(uniqueCustomers);
          setLoading(false);
        } catch (err) {
          setError(err.message);
          setLoading(false);
        }
      };
  
      fetchData();
    }, []);
  
    useEffect(() => {
      const handleKeyDown = (event) => {
        if (customers.length === 0) return;
  
        if (event.key === "ArrowDown") {
          setSelectedRow((prev) => Math.min(prev + 1, customers.length - 1));
        } else if (event.key === "ArrowUp") {
          setSelectedRow((prev) => Math.max(prev - 1, 0));
        } else if (event.key === "Enter") {
          const selectedCustomer = customers[selectedRow];
          const customerData = data.filter(
            (entry) =>
              entry.customerDetails[0].vacode.trim() ===
              selectedCustomer.vacode.trim()
          );
          navigate("/Traildetails", {
            state: { vacode: selectedCustomer.vacode, details: customerData },
          });
        }
      };
  
      window.addEventListener("keydown", handleKeyDown);
      return () => {
        window.removeEventListener("keydown", handleKeyDown);
      };
    }, [customers, selectedRow, navigate, data]);
  
    const handleCustomerClick = (vacode) => {
      const customerData = data.filter(
        (entry) => entry.customerDetails[0].vacode.trim() === vacode.trim()
      );
      navigate("/Traildetails", { state: { vacode, details: customerData } });
    };
    const handlePrint = () => {
      const printContents = printRef.current.innerHTML;
      const printLayout = `
        <div style="text-align: center;">
          <h2>SHKUNSOFT INNOVATIONS</h2>
            <h2>Motia Khan</h2>
              <h2>Mandi Gobindgarh</h2>
        </div>
         <div">
          <h2>TRAIL BALANCE</h2>
        </div>
        ${printContents}
      `;
      
      const originalContents = document.body.innerHTML;
  
      document.body.innerHTML = printLayout;
      window.print();
      document.body.innerHTML = originalContents;
  
      window.location.reload(); // Reload to restore the original page
    };
    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;

  return (
    <div>
      <div
        style={{
          display: "flex",
          flexDirection: "row",
          marginLeft: 20,
        }}
      >
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ display: "flex", flexDirection: "row" }}>
            <text style={{ marginTop: 5,fontSize:20}} className="textform">
              Period From:
            </text>
            <div style={{ marginLeft: 10 }}>
              <DatePicker
                className="custom-datepickerzz"
                id="date"
                selected={selectedDateFrom}
                onChange={(date) => setSelectedDateFrom(date)}
                dateFormat="dd-MM-yyyy"
              />
            </div>
            <text className="headerTrail">TRAIL BALANCE</text>
          </div>
          <div style={{ display: "flex", flexDirection: "row"}}>
            <text style={{fontSize:20}} className="textform">
              Period Upto:
            </text>
            <div style={{ marginLeft: 5,marginLeft: 14}}>
              <DatePicker
                className="custom-datepickerzz"
                id="date"
                selected={selectedDateUpto}
                onChange={(date) => setSelectedDateUpto(date)}
                dateFormat="dd-MM-yyyy"
              />
            </div>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", marginLeft: 200 }}>
          <div style={{ display: "flex", flexDirection: "row" }}>
            <text style={{ fontSize:20}} className="textform">
              Selected Debit:
            </text>
            <input style={{ marginLeft: 15}} className="custom-datepickerzz" />
          </div>
          <div style={{ display: "flex", flexDirection: "row",marginTop:10}}>
            <text style={{fontSize:20}} className="textform">
              Selected Credit:
            </text>
            <input
              style={{ marginLeft: 7}}
              className="custom-datepickerzz"
            />
          </div>
        </div>
      </div>
      <div style={{ marginTop: 8 }}>
        <Button
          className="Button"
          style={{ color: "black", backgroundColor: buttonColors[0],width:120}}
          onClick={openOptionModal}
        >
          Option
        </Button>
        <OptionModal isOpen={isOptionOpen} onClose={closeOptionModal}/>
        <Button
          className="Button"
          style={{ color: "black", backgroundColor: buttonColors[1],width:120}}
          onClick={handlePrint}
        >
          Print
        </Button>
        <Button
          className="Button"
          style={{ color: "black", backgroundColor: buttonColors[3],width:120}}
        >
          Export
        </Button>
        <Button
          className="Button"
          style={{ color: "black", backgroundColor: buttonColors[4],width:120}}
        >
          Exit
        </Button>
        <Button
          className="Button"
          style={{ color: "black", backgroundColor: buttonColors[6],width:120}}
        >
          Selected
        </Button>
        {/* <text style={{ marginLeft: 100, fontSize: 20, color: "blue" }}>
          DR.Excess Rs: {a}
        </text> */}
      </div>
      <div ref={printRef}>
      <CustomerList
        customers={customers}
        selectedRow={selectedRow}
        onCustomerClick={handleCustomerClick}
      />
    </div>
      <div
        className="bottomDiv"
        style={{ display: "flex", flexDirection: "row", marginTop: 18 }}
      >
        <div style={{display:'flex',flexDirection:'row'}}>
          <text style={{fontSize:20}}>Search:</text>
          <input
          className="Search"
          />
          <text style={{color:'red',marginLeft:5}}>Press[+]Select/Unselect</text>
        </div>
        <select className="serachSelect"/>
        <input
          className="TotalQty"
        />
         <input
          className="TotalDebit"
        />
         <input
          className="TotalCredit"
        />

      </div>
    </div>
  );
};

export default TrailBalance;
