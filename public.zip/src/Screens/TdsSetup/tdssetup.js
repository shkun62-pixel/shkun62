import React, { useState } from 'react';
import { TextField, Select, MenuItem, Typography, FormControl, InputLabel, Box } from '@mui/material';
import './TDSTypes.css'; // Import the custom CSS

// Example TDS data
const tdsData = [
  {
    _id: "66f66f6c60ac514e0d2e554b",
    section: "192",
    name: "Salary",
    rate: "",
    no_pan_rate: "",
    sp_rate: "",
    ledger_ac: "",
    code: "temp-code-1",
  },
  {
    _id: "66f66f6c60ac514e0d2e554c",
    section: "192A",
    name: "Accumulated PF Balance",
    rate: "10%",
    no_pan_rate: "10%",
    sp_rate: "30%",
    ledger_ac: "",
    code: "temp-code-2",
  },
  {
    _id: "66f66f6c60ac514e0d2e554d",
    section: "193",
    name: "Securities",
    rate: "10%",
    no_pan_rate: "10%",
    sp_rate: "20%",
    ledger_ac: "",
    code: "temp-code-3",
  },
];

const TdsSetup = () => {
  const [selectedTDS, setSelectedTDS] = useState(null);
  const [ledgerAc, setLedgerAc] = useState('');
  const [code, setCode] = useState('');

  // Handle when a new TDS type is selected from the dropdown
  const handleTDSChange = (e) => {
    const selected = tdsData.find(tds => tds.name === e.target.value);
    setSelectedTDS(selected);
    setLedgerAc(selected.ledger_ac); // Populate the ledger_ac field
    setCode(selected.code);          // Populate the code field
  };

  // Handle ledger_ac and code changes
  const handleLedgerAcChange = (e) => setLedgerAc(e.target.value);
  const handleCodeChange = (e) => setCode(e.target.value);

  return (
    <div className="tds-container">
      <Box className="tds-card">
        <Typography variant="h5" className="tds-title">
          Select TDS Type
        </Typography>

        <FormControl fullWidth className="tds-form-control">
          <InputLabel>TDS Type</InputLabel>
          <Select
            value={selectedTDS ? selectedTDS.name : ''}
            onChange={handleTDSChange}
            label="TDS Type"
          >
            {tdsData.map(tds => (
              <MenuItem key={tds._id} value={tds.name}>
                {tds.name}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        {selectedTDS && (
          <Box>
            <Typography variant="subtitle1" className="tds-section">
              Section: {selectedTDS.section}
            </Typography>

            <TextField
              label="Ledger Account"
              fullWidth
              variant="outlined"
              value={ledgerAc}
              onChange={handleLedgerAcChange}
              margin="normal"
              className="tds-textfield"
            />

            <TextField
              label="Code"
              fullWidth
              variant="outlined"
              value={code}
              onChange={handleCodeChange}
              margin="normal"
              className="tds-textfield"
            />
          </Box>
        )}
      </Box>
    </div>
  );
};

export default TdsSetup;
