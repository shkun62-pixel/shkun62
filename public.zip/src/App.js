import './App.css';
import React, { useState, useEffect } from 'react';
import { Routes, Route } from "react-router-dom";
import SignIn from './Screens/SignIn/SignIn';
import Companies from './Screens/CompanySelect/Companies';
import LedgerAcc from './Screens/LedgerAcc/LedgerAcc';
import NewStockAcc from './Screens/NewStockAcc/NewStockAcc';
import Sale from './Screens/Sale/Sale'
import SaleService from './Screens/SaleService/SaleService';
import Purchase from './Screens/Purchase/Purchase';
import PurchaseService from './Screens/PurchaseService/PurchaseService';
import CashVoucher from './Screens/CashVoucher/CashVoucher';
import JournalVoucher from './Screens/JournalVoucher/JournalVoucher';
import BankVoucher from './Screens/BankVoucher/BankVoucher';
import TdsVoucher from './Screens/TdsVoucher/TdsVoucher';
import TdsSetup from './Screens/TdsSetup/tdssetup';
import DebitNote from './Screens/DebitNote//DebitNote';
import CreditNote from './Screens/CreditNote/CreditNote';
import CustomerDetails from './Screens/CustomerDetails ';
import SaleBook from './Screens/Books/SaleBook/SaleBook';
import PurchaseBook from './Screens/Books/PurchaseBook/PurchaseBook';
import StockTransfer from './Screens/StockTransfer/StockTransfer';
import TrailBalance from './Screens/TrailBalance';
import Setup from './Screens/Setup/Setup';
import TrailDetails from './Screens/TrailDetails';
import SideDrawer from './Screens/SideDrawer/SideDrawer';
import Example from './Screens/Example';
import SplashScreen from './Screens/SplashScreen/SplashScreen';
import LedgerSetup from './Screens/LedgerAcc/LedgerSetup';
import ProductionCard from './Screens/ProductionCard/ProductionCard';
import SalesReturn from './Screens/GoodsReturn/SalesReturn';
import PurchasesReturn from './Screens/GoodsReturn/PurchasesReturn';

function App() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]); // Initialize with an empty array

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 3000); // Set your desired loading time

    return () => clearTimeout(timer); // Cleanup the timer on component unmount
  }, []);
  return (
    <div>
      {/* <Navbar /> */}
      <SideDrawer />
      <Routes>
        <Route path="/" element={loading ? <SplashScreen /> : <SignIn />} />
        <Route path='/Companies' element={<Companies />}></Route>
        {/* <Route path="/" element={loading ? <SplashScreen /> : <SignInForm />} /> */}
        <Route path='/LedgerAcc' element={<LedgerAcc />}></Route>
        <Route path='/Example' element={<Example></Example>}></Route>
        <Route path='/NewStockAcc' element={<NewStockAcc />}></Route>
        <Route path='/Sale' element={<Sale />}></Route>
        <Route path='/SaleService' element={<SaleService />}></Route>
        <Route path='/Purchase' element={<Purchase />}></Route>
        <Route path='/PurchaseService' element={<PurchaseService />}></Route>
        <Route path='/CashVoucher' element={<CashVoucher />}></Route>
        <Route path='/JournalVoucher' element={<JournalVoucher />}></Route>
        <Route path='/BankVoucher' element={<BankVoucher />}></Route>
        <Route path='/TdsVoucher' element={<TdsVoucher />}></Route>
        <Route path='/DebitNote' element={<DebitNote />}></Route>
        <Route path='/CreditNote' element={<CreditNote />}></Route>
        <Route path='/SaleBook' element={<SaleBook />}></Route>
        <Route path='/PurchaseBook' element={<PurchaseBook />}></Route>
        <Route path="/CustomerDetails" element={<CustomerDetails data={data} />} />
        <Route path='/tdssetup' element={<TdsSetup />}></Route>
        <Route path='/StockTransfer' element={<StockTransfer />}></Route>
        <Route path='/TrailBalance' element={<TrailBalance />}></Route>
        <Route path='/TrailDetails' element={<TrailDetails />}></Route>
        <Route path='/Setup' element={<Setup />}></Route>
        <Route path='/SideDrawer' element={<SideDrawer />}></Route>
        <Route path='/LedgerSetup' element={<LedgerSetup />}></Route>
        <Route path='/ProductionCard' element={<ProductionCard />}></Route>
        <Route path='/SalesReturn' element={<SalesReturn />}></Route>
        <Route path='/PurchasesReturn' element={<PurchasesReturn />}></Route>
      </Routes>


    </div>
  );
}

export default App;


